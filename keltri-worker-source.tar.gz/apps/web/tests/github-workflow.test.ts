import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import test from "node:test";
import { githubActionsYaml } from "../src/lib/github-workflow.js";

const config = { projectId: "project", serviceId: "web", buildCommand: 'npm run build -- --mode="preview"', outputDir: "site output", apiUrl: "https://api.example.test" };

test("every branch produces a preview without automatic production promotion", () => {
  const workflow = githubActionsYaml(config);
  assert.ok(workflow.includes("branches: ['**']"));
  assert.ok(workflow.includes("${{ github.ref }}"));
  assert.ok(workflow.includes("${{ secrets.KELTRI_API_KEY }}"));
  assert.ok(workflow.includes("env/resolved?target=preview"));
  assert.ok(workflow.includes("${GITHUB_SHA:0:8}"));
  assert.ok(!workflow.includes("/promote"));
  assert.ok(!workflow.includes("pull_request_target"));
});

test("build settings are quoted YAML values, not interpolated shell commands", () => {
  const workflow = githubActionsYaml(config);
  for (const [key, value] of [["BUILD_COMMAND", config.buildCommand], ["OUTPUT_DIR", config.outputDir]]) {
    const line = workflow.split("\n").find(line => line.trim().startsWith(`${key}:`))!;
    assert.equal(JSON.parse(line.slice(line.indexOf(":") + 1).trim()), value);
  }
  assert.ok(workflow.includes('cd -- "$OUTPUT_DIR"'));
  assert.ok(workflow.includes('test -f "$OUTPUT_DIR/index.html"'));
});

test("generated build script is executable JavaScript and does not pass the deployment credential to the build", () => {
  const workflow = githubActionsYaml(config);
  const script = workflow.split("<<'NODE'\n")[1].split("          NODE")[0].split("\n").map(line => line.slice(10)).join("\n");
  const result = spawnSync(process.execPath, ["--input-type=module", "--check"], { input: script, encoding: "utf8" });
  assert.equal(result.status, 0, result.stderr);
  assert.ok(script.includes("delete buildEnv.KELTRI_API_KEY"));
  assert.ok(script.includes("unlinkSync(file)"));
});
