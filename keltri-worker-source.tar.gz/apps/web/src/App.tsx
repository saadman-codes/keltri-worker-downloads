import { Navigate, Route, Routes } from "react-router-dom";
import { Shell } from "./components/shell";
import { isAuthed } from "./lib/session";
import { AddServicePage } from "./pages/add-service";
import { AuditLogPage } from "./pages/audit-log";
import { AuthCallbackPage } from "./pages/auth-callback";
import { BlobsPage } from "./pages/blobs";
import { DistributionPage } from "./pages/distribution";
import { GetAppPage } from "./pages/get";
import { HomePage } from "./pages/home";
import { InstallHelpPage } from "./pages/install-help";
import { PrivacyPage, TermsPage } from "./pages/legal";
import { LoginPage } from "./pages/login";
import { NewOrganizationPage } from "./pages/new-organization";
import { NewProjectPage } from "./pages/new-project";
import { NotFoundPage } from "./pages/not-found";
import { OrganizationMembersPage } from "./pages/organization-members";
import { ProjectOverviewPage } from "./pages/project-overview";
import { ProjectsPage } from "./pages/projects";
import { RegisterPage } from "./pages/register";
import { ServiceDetailPage } from "./pages/service-detail";
import { SettingsPage } from "./pages/settings";
import { StatusPage } from "./pages/status";
import { StorePage } from "./pages/store";
import { StoreAppPage } from "./pages/store-app";
import { DeveloperProfilePage } from "./pages/store-developer";
import { TryPage } from "./pages/try";
import { WorkspaceOverviewPage } from "./pages/workspace-overview";
import { DeploymentsPage } from "./pages/deployments";
import { DeploymentDetailPage } from "./pages/deployment-detail";
import { DomainsPage } from "./pages/domains";
import { GitCallbackPage } from "./pages/git-callback";

// Console (formerly apps/portal, merged in here) lives under /console so it
// never collides with the public store's own routes, the same way a
// dashboard subdomain would in the split-up version of this monorepo.
function RequireAuth() {
  if (!isAuthed()) return <Navigate to="/console/login" replace />;
  return <Shell />;
}

function GuestOnly({ children }: { children: React.ReactNode }) {
  if (isAuthed()) return <Navigate to="/console" replace />;
  return children;
}


export default function App() {
  return (
    <Routes>
      {/* Platform landing */}
      <Route path="/" element={<HomePage />} />

      {/* Store */}
      <Route path="/store" element={<StorePage />} />
      <Route path="/store/apps/:slug" element={<StoreAppPage />} />
      <Route path="/store/apps/:slug/try" element={<TryPage />} />
      <Route path="/store/developer/:slug" element={<DeveloperProfilePage />} />
      <Route path="/get/:slug" element={<GetAppPage />} />
      <Route path="/terms" element={<TermsPage />} />
      <Route path="/privacy" element={<PrivacyPage />} />
      <Route path="/install-help" element={<InstallHelpPage />} />
      <Route path="/developers" element={<Navigate to="/console" replace />} />
      <Route path="/status" element={<StatusPage />} />

      {/* Console — Projects (web/backend/mobile hosting) is the entire
          authenticated product now. Android app publishing/review/payouts
          used to have console pages here; they're gone (see git history if
          they need to come back). The public Store above and the API/CLI
          are unaffected — only this console's management UI for them was
          removed. */}
      <Route
        path="/console/login"
        element={
          <GuestOnly>
            <LoginPage />
          </GuestOnly>
        }
      />
      <Route
        path="/console/register"
        element={
          <GuestOnly>
            <RegisterPage />
          </GuestOnly>
        }
      />
      <Route path="/console/auth/callback" element={<AuthCallbackPage />} />
      <Route element={<RequireAuth />}>
        <Route path="/console" element={<WorkspaceOverviewPage />} />
        <Route path="/console/git/callback" element={<GitCallbackPage />} />
        <Route path="/console/projects" element={<ProjectsPage />} />
        <Route path="/console/projects/new" element={<NewProjectPage />} />
        <Route path="/console/projects/:id" element={<ProjectOverviewPage />} />
        <Route path="/console/projects/:id/:section" element={<ProjectOverviewPage />} />
        <Route path="/console/deployments" element={<DeploymentsPage />} />
        <Route path="/console/domains" element={<DomainsPage />} />
        <Route path="/console/projects/:id/services/:serviceId/deployments/:deploymentId" element={<DeploymentDetailPage />} />
        <Route path="/console/projects/:id/services/new" element={<AddServicePage />} />
        <Route
          path="/console/projects/:id/services/:serviceId"
          element={<ServiceDetailPage />}
        />
        <Route path="/console/blobs" element={<BlobsPage />} />
        <Route path="/console/store" element={<DistributionPage />} />
        <Route path="/console/audit-log" element={<AuditLogPage />} />
        <Route path="/console/settings" element={<SettingsPage />} />
        <Route path="/console/organizations/new" element={<NewOrganizationPage />} />
        <Route
          path="/console/organizations/:id/members"
          element={<OrganizationMembersPage />}
        />
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
