import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import { type Project, useProjects } from "../lib/platform";

type Domain = { id: string; hostname: string; verified: boolean; projectId: string; serviceId: string; serviceName: string; projectName: string };
export function DomainList({ projects }: { projects: Project[] }) {
  const [domains, setDomains] = useState<Domain[] | null>(null);
  const [error, setError] = useState("");
  const key = JSON.stringify(projects.flatMap(p => p.services.filter(s => s.type === "web").map(s => ({ projectId: p.id, serviceId: s.id, projectName: p.name, serviceName: s.name }))));
  useEffect(() => {
    let active = true;
    setDomains(null); setError("");
    const sources = JSON.parse(key) as Pick<Domain, "projectId" | "serviceId" | "projectName" | "serviceName">[];
    Promise.all(sources.map(async source => ((await api.projects.services.domains.list(source.projectId, source.serviceId)) as Domain[]).map(d => ({ ...d, ...source })))).then(values => { if (active) setDomains(values.flat()); }).catch(err => { if (active) setError(err.message); });
    return () => { active = false; };
  }, [key]);
  return <section className="mt-6">{error && <p role="alert">{error}</p>}{!domains && !error && <p role="status">Loading domains…</p>}{domains && <div className="rounded-xl border border-line bg-ink-2">{domains.map(d => <Link key={d.id} to={`/console/projects/${d.projectId}/services/${d.serviceId}?tab=Domains`} className="flex flex-wrap items-center justify-between gap-3 border-b border-line p-5 last:border-0 hover:bg-ink-3"><div><p className="font-mono text-sm">{d.hostname}</p><p className="mt-1 text-xs text-mute">{d.projectName} / {d.serviceName}</p></div><span className="text-xs text-mute">{d.verified ? "Verified" : "Pending configuration"} →</span></Link>)}{!domains.length && <p className="p-6 text-sm text-mute">No custom domains. Open a web service’s Domains tab to add one.</p>}</div>}</section>;
}
export function DomainsPage() {
  const { projects, error } = useProjects();
  return <main className="px-8 py-10 lg:px-12"><h1 className="font-display text-3xl font-semibold">Domains</h1><p className="mt-2 text-sm text-mute">Custom domains across your workspace.</p>{error && <p role="alert">{error}</p>}{projects && <DomainList projects={projects} />}</main>;
}
