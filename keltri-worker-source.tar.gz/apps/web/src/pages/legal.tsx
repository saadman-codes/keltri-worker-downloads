import { Link } from "react-router-dom";
import { StoreShell } from "../components/chrome";
import { ABUSE_EMAIL, HELLO_EMAIL, abuseMailto, helloMailto } from "../lib/contacts";
import { useDocumentTitle } from "../lib/title";

const UPDATED = "18 September 2026";

function LegalLayout({
  kicker,
  title,
  children,
}: {
  kicker: string;
  title: string;
  children: React.ReactNode;
}) {
  useDocumentTitle(`${title} — Keltri`);
  return (
    <StoreShell>
      <main className="mx-auto max-w-3xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">
          {kicker}
        </p>
        <h1 className="font-display mt-3 text-4xl font-extrabold">{title}</h1>
        <p className="mt-4 rounded-xl border border-line bg-ink-2 p-4 text-sm text-mute">
          Draft for counsel review. This is not legal advice and is not a
          substitute for a reviewed contract. Last updated {UPDATED}.
        </p>
        <div className="mt-10 space-y-8 text-sm leading-7 text-paper/90">
          {children}
        </div>
        <LegalNav />
      </main>
    </StoreShell>
  );
}

function LegalNav() {
  return (
    <p className="mt-12 text-sm text-mute">
      <Link to="/terms" className="text-signal">
        Terms
      </Link>
      {" · "}
      <Link to="/privacy" className="text-signal">
        Privacy
      </Link>
      {" · "}
      <Link to="/install-help" className="text-signal">
        Install help
      </Link>
      {" · "}
      <a href={abuseMailto} className="text-signal">
        Report abuse
      </a>
    </p>
  );
}

function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <h2 className="font-display text-2xl">{title}</h2>
      <div className="mt-3 space-y-3 text-mute">{children}</div>
    </section>
  );
}

export function TermsPage() {
  return (
    <LegalLayout kicker="Legal" title="Terms of Service">
      <Section title="1. What this service is">
        <p>
          Keltri is an Android distribution catalog and publisher
          platform. Visitors can browse listings, try some apps in the
          browser, and download a small bootstrapper APK to install software
          outside Google Play.
        </p>
        <p>
          Keltri is not Google Play, an app store equivalent, a mobile
          operating system, or a substitute for Play Protect, OEM security
          updates, or your device manufacturer’s policies. Listings may be
          sparse. Availability is not a representation that an app is safe,
          reviewed to a consumer-store standard, or appropriate for your
          device.
        </p>
      </Section>
      <Section title="2. Sideloading and device risk">
        <p>
          Installing a bootstrapper or APK from this site is sideloading. You
          may have to allow “unknown sources” or “install unknown apps.” That
          setting weakens a platform protection. You are responsible for
          deciding whether to install, for reviewing permissions and the
          publisher, and for any harm to your device, data, or accounts.
        </p>
        <p>
          Work profiles, family accounts, and some manufacturers can block
          sideloading entirely. We do not guarantee that an APK will install
          or update on your hardware.
        </p>
      </Section>
      <Section title="3. Accounts (developers)">
        <p>
          Publisher accounts, the developer console, API keys, and CLI access
          are for people distributing Android software through Keltri.
          You must provide accurate information, keep credentials secret, and
          not share reviewer or admin access. We may suspend accounts that
          abuse the platform.
        </p>
      </Section>
      <Section title="4. Listings and publisher responsibility">
        <p>
          Developers are responsible for their APKs, listings, screenshots,
          descriptions, permissions, privacy practices, and legal rights
          (including IP, export, and privacy law). Submitting a listing is not
          a promise of public distribution. We may refuse, delay, unpublish,
          or take down a listing at any time.
        </p>
      </Section>
      <Section title="5. Acceptable use">
        <p>
          You may not use Keltri to distribute malware, fraud,
          unlicensed copyrighted material, child sexual abuse material,
          harassment tools, or other illegal content; to attack the service;
          or to impersonate another publisher. Automated scraping that degrades
          the service is not allowed.
        </p>
      </Section>
      <Section title="6. Takedown and abuse reports">
        <p>
          Report illegal content, malware, or IP claims to{" "}
          <a href={abuseMailto} className="text-signal">
            {ABUSE_EMAIL}
          </a>
          . Include the app slug or URL, what is wrong, and any evidence you
          can share. Operators can unpublish a live listing; see the public
          install-help and listing pages for how software is installed. We may
          notify the developer and keep records of the report.
        </p>
      </Section>
      <Section title="7. Disclaimers">
        <p>
          The service is provided “as is.” Catalog contents, install counts,
          ratings, and scan labels (when shown) can be incomplete or wrong. To
          the extent allowed by law we disclaim warranties and limit liability
          for sideloading, failed updates, lost data, and third-party apps.
        </p>
      </Section>
      <Section title="8. Contact">
        <p>
          General:{" "}
          <a href={helloMailto} className="text-signal">
            {HELLO_EMAIL}
          </a>
          . Abuse / takedown:{" "}
          <a href={abuseMailto} className="text-signal">
            {ABUSE_EMAIL}
          </a>
          . Related:{" "}
          <Link to="/privacy" className="text-signal">
            Privacy Policy
          </Link>
          .
        </p>
      </Section>
    </LegalLayout>
  );
}

export function PrivacyPage() {
  return (
    <LegalLayout kicker="Legal" title="Privacy Policy">
      <Section title="1. Scope">
        <p>
          This draft describes how the Keltri websites and API may
          handle information. It covers the public catalog, install pages,
          developer console, and API. It does not cover third-party apps you
          install through a bootstrapper — those publishers have their own
          practices.
        </p>
      </Section>
      <Section title="2. Information we may collect">
        <p>
          <strong className="text-paper">Visitors.</strong> Standard request
          logs (IP address, user agent, path, referrer) and whatever your
          browser sends when you load pages or download an APK.
        </p>
        <p>
          <strong className="text-paper">Developers.</strong> Email, name,
          password hash (not the password), optional GitHub id if OAuth is
          enabled, listing copy, uploaded APKs and assets, API key hashes, and
          billing-related fields if payouts are configured later.
        </p>
        <p>
          <strong className="text-paper">Install / OTA.</strong> App slug,
          version checks, and coarse device identifiers the bootstrapper
          sends so rollout buckets can stay stable. We do not need your Google
          account to sideload.
        </p>
      </Section>
      <Section title="3. How we use it">
        <p>
          To operate the catalog and API, authenticate publishers, host APKs,
          measure installs and crashes the publisher dashboard shows, prevent
          abuse, and respond to reports. We do not sell personal information.
        </p>
      </Section>
      <Section title="4. Sharing">
        <p>
          Infrastructure processors (hosting, database, object storage, email)
          see data as needed to run the service. We may disclose information
          if required by law or to handle an abuse or security incident.
          Public listings are public.
        </p>
      </Section>
      <Section title="5. Retention">
        <p>
          Account data lasts until the account is closed, then for a limited
          period as needed for security and legal records. Server logs are
          kept for a short operational window. Takedown records may be kept
          longer.
        </p>
      </Section>
      <Section title="6. Your choices">
        <p>
          Developers can update listing and account fields in the console.
          You can stop using the site and uninstall sideloaded software from
          Android settings. Abuse reports: {ABUSE_EMAIL}. Privacy questions:{" "}
          {HELLO_EMAIL}.
        </p>
      </Section>
      <Section title="7. Children">
        <p>
          The publisher console is not directed at children. The public
          catalog may include apps with various content ratings supplied by
          developers; we do not age-gate the website in this draft.
        </p>
      </Section>
      <Section title="8. Contact">
        <p>
          Privacy:{" "}
          <a href={helloMailto} className="text-signal">
            {HELLO_EMAIL}
          </a>
          . Abuse:{" "}
          <a href={abuseMailto} className="text-signal">
            {ABUSE_EMAIL}
          </a>
          .{" "}
          <Link to="/terms" className="text-signal">
            Terms of Service
          </Link>
          .
        </p>
      </Section>
    </LegalLayout>
  );
}
