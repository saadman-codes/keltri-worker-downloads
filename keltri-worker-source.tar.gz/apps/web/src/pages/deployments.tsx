import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";
import { deploymentPath, type Project, type ServiceDetail, useProjects } from "../lib/platform";
import { Status } from "../components/platform";

export function DeploymentList({ projects }: { projects: Project[] }) {
  const [services, setServices] = useState<ServiceDetail[] | null>(null);
  const [error, setError] = useState("");
  const [environment, setEnvironment] = useState("all");
  const [serviceId, setServiceId] = useState("all");
  const [query, setQuery] = useState("");
  // Stable key prevents refetches caused only by workspace filtering renders.
  const key = JSON.stringify(projects.flatMap(p => p.services.map(s => [p.id, s.id])));
  useEffect(() => {
    let active = true;
    setServices(null); setError(""); setServiceId("all");
    const pairs = JSON.parse(key) as [string, string][];
    Promise.all(pairs.map(([p, s]) => api.projects.services.get(p, s))).then(values => { if (active) setServices(values as ServiceDetail[]); }).catch(err => { if (active) setError(err instanceof Error ? err.message : "Could not load deployments"); });
    return () => { active = false; };
  }, [key]);
  const rows = (services ?? []).flatMap(service => service.deployments.map(deployment => ({ service, deployment }))).filter(({ service, deployment }) => (environment === "all" || deployment.environment === environment) && (serviceId === "all" || service.id === serviceId) && `${service.project.name} ${service.name} ${deployment.commitRef ?? ""} ${deployment.id}`.toLowerCase().includes(query.toLowerCase())).sort((a, b) => b.deployment.createdAt.localeCompare(a.deployment.createdAt));
  return <section className="mt-6">
    <div className="mb-5 flex flex-wrap gap-3"><input aria-label="Search deployments" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search project, service, or commit…" className="min-w-0 flex-1 rounded-lg border border-line bg-ink-2 px-3 py-2 text-sm" /><select aria-label="Environment" value={environment} onChange={e => setEnvironment(e.target.value)} className="rounded-lg border border-line bg-ink-2 px-3 py-2 text-sm"><option value="all">All environments</option><option value="production">Production</option><option value="preview">Preview</option></select><select aria-label="Service" value={serviceId} onChange={e => setServiceId(e.target.value)} className="rounded-lg border border-line bg-ink-2 px-3 py-2 text-sm"><option value="all">All services</option>{services?.map(s => <option key={s.id} value={s.id}>{s.project.name} / {s.name}</option>)}</select></div>
    {error && <p role="alert">{error}</p>}
    {!services && !error && <p role="status" className="text-sm text-mute">Loading deployment history…</p>}
    {services && <div className="rounded-xl border border-line bg-ink-2">{rows.map(({ service, deployment }) => <Link key={deployment.id} to={deploymentPath(service.project.id, service.id, deployment.id)} className="flex flex-wrap items-center justify-between gap-4 border-b border-line px-5 py-4 last:border-0 hover:bg-ink-3"><div><p className="text-sm font-medium">{service.project.name} / {service.name}</p><p className="mt-1 font-mono text-xs text-mute">{deployment.commitRef ?? deployment.id.slice(0, 8)}</p></div><Status value={deployment.status} /><span className="rounded-md border border-line px-2 py-1 text-xs capitalize">{deployment.environment}</span><time className="text-xs text-mute">{new Date(deployment.createdAt).toLocaleString()}</time></Link>)}{!rows.length && <p className="p-8 text-center text-sm text-mute">No deployments match these filters.</p>}</div>}
  </section>;
}

export function DeploymentsPage() {
  const { projects, error } = useProjects();
  return <main className="px-8 py-10 lg:px-12"><h1 className="font-display text-3xl font-semibold">Deployments</h1><p className="mt-2 text-sm text-mute">Every service. Every environment. One history.</p>{error && <p role="alert" className="mt-6">{error}</p>}{projects ? <DeploymentList projects={projects} /> : !error && <p role="status" className="mt-6">Loading projects…</p>}</main>;
}
