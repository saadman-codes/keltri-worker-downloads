import { Link } from "react-router-dom";
import { StoreShell } from "../components/chrome";
import { useDocumentTitle } from "../lib/title";

const surfaces = [
  {
    name: "Website",
    status: "Live",
    body: "Upload your build output, get a preview URL, promote to production with one click.",
  },
  {
    name: "Backend",
    status: "Preview only",
    body: "Create a project and record a deployment today. Actually running the process is next.",
  },
  {
    name: "Mobile (Android)",
    status: "Live",
    body: "Upload an APK, ship OTA updates to testers, list it on the Store when you're ready.",
  },
];

const steps = [
  ["1", "Push or upload", "Connect a repo (coming soon) or upload a build."],
  ["2", "Preview", "Every deployment gets its own URL before it's live."],
  ["3", "Promote", "One click moves a preview to production. Roll back just as fast."],
];

export function HomePage() {
  useDocumentTitle("Keltri — push web, backend, and mobile");

  return (
    <StoreShell>
      <main>
        <section className="mx-auto max-w-4xl px-6 pb-16 pt-20 text-center">
          <p className="font-mono text-xs uppercase tracking-widest text-signal">
            Keltri
          </p>
          <h1 className="font-display mt-4 text-4xl font-extrabold sm:text-5xl">
            Push your product. Preview it. Ship it.
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-mute">
            One platform for the website, the backend, and the mobile app.
            Every deployment gets a preview before it goes live.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/console/register"
              className="rounded-full bg-signal px-6 py-3 text-sm font-semibold text-signal-ink"
            >
              Start building
            </Link>
            <Link
              to="/store"
              className="rounded-full border border-line px-6 py-3 text-sm text-mute hover:text-paper"
            >
              Browse the Store
            </Link>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 pb-20">
          <div className="grid gap-4 sm:grid-cols-3">
            {surfaces.map((surface) => (
              <div
                key={surface.name}
                className="rounded-2xl border border-line bg-ink-2 p-6"
              >
                <div className="flex items-center justify-between">
                  <h2 className="font-display text-xl">{surface.name}</h2>
                  <span className="font-mono text-[10px] uppercase tracking-widest text-signal">
                    {surface.status}
                  </span>
                </div>
                <p className="mt-3 text-sm text-mute">{surface.body}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="border-t border-line bg-ink-2">
          <div className="mx-auto max-w-6xl px-6 py-16">
            <h2 className="font-display text-2xl">How it works</h2>
            <div className="mt-8 grid gap-6 sm:grid-cols-3">
              {steps.map(([n, title, body]) => (
                <div key={n}>
                  <span className="font-mono text-2xl text-signal">{n}</span>
                  <h3 className="font-display mt-2 text-lg">{title}</h3>
                  <p className="mt-2 text-sm text-mute">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-6 py-16">
          <div className="rounded-3xl border border-line bg-ink-2 p-8 sm:flex sm:items-center sm:justify-between">
            <div>
              <h2 className="font-display text-2xl">
                Selling an app? The Store is optional.
              </h2>
              <p className="mt-2 max-w-xl text-sm text-mute">
                List an Android app for shoppers to try in the browser, then
                install. Keltri takes 15% only if a sale actually clears
                through the Store — hosting is billed separately.
              </p>
            </div>
            <Link
              to="/store"
              className="mt-6 inline-block shrink-0 rounded-full bg-signal px-5 py-2.5 text-sm font-semibold text-signal-ink sm:mt-0"
            >
              Browse the Store
            </Link>
          </div>
        </section>
      </main>
    </StoreShell>
  );
}
