import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AppCard } from "../components/app-card";
import { StoreShell } from "../components/chrome";
import { fetchPublicDeveloper, type PublicDeveloper } from "../lib/catalog";
import { NotFoundPage } from "./not-found";

export function DeveloperProfilePage() {
  const { slug = "" } = useParams();
  const [developer, setDeveloper] = useState<
    PublicDeveloper | null | undefined
  >(undefined);

  useEffect(() => {
    fetchPublicDeveloper(slug).then(setDeveloper);
  }, [slug]);

  if (developer === undefined) {
    return (
      <StoreShell>
        <main className="mx-auto max-w-3xl px-6 py-16 text-mute">Loading…</main>
      </StoreShell>
    );
  }
  if (!developer) return <NotFoundPage />;

  return (
    <StoreShell>
      <main className="mx-auto max-w-3xl px-6 py-16">
        <h1 className="font-display text-4xl font-extrabold">{developer.name}</h1>
        <p className="mt-2 font-mono text-xs text-mute">/{developer.slug}</p>
        <p className="mt-4 max-w-xl text-mute">
          {developer.bio ?? "Independent Android developer on the Keltri Store."}
        </p>
        <p className="mt-3 text-sm">
          {developer.installs.toLocaleString()} installs · ★ {developer.rating}{" "}
          average
        </p>
        {developer.website ? (
          <a href={developer.website} className="mt-4 inline-block text-sm text-signal">
            {developer.website}
          </a>
        ) : null}
        <h2 className="mt-12 font-display text-2xl">Apps</h2>
        <div className="mt-4 flex flex-wrap gap-3">
          {developer.apps.map((app) => (
            <AppCard key={app.slug} app={app} />
          ))}
        </div>
      </main>
    </StoreShell>
  );
}
