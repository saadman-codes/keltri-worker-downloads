import { StoreShell } from "../components/chrome";

const services = [
  ["keltriapps.dev (store + console)", "Operational"],
  ["api.keltriapps.dev", "Operational"],
  ["docs.keltriapps.dev", "Operational"],
  ["OTA / CDN", "Operational"],
];

export function StatusPage() {
  return (
    <StoreShell>
      <main className="mx-auto max-w-3xl px-6 py-20">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">
          status.keltriapps.dev
        </p>
        <h1 className="font-display mt-3 text-4xl font-extrabold">
          All systems operational
        </h1>
        <ul className="mt-10 divide-y divide-line rounded-2xl border border-line">
          {services.map(([name, state]) => (
            <li key={name} className="flex items-center justify-between px-5 py-4">
              <span>{name}</span>
              <span className="font-mono text-xs text-signal">{state}</span>
            </li>
          ))}
        </ul>
        <p className="mt-8 text-sm text-mute">No incidents in the last 90 days.</p>
      </main>
    </StoreShell>
  );
}
