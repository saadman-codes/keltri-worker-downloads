import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../lib/api";

type App = { id: string; slug: string; name: string; status: string };

export function DistributionPage() {
  const [apps, setApps] = useState<App[] | null>(null);

  useEffect(() => {
    api.apps
      .list()
      .then((value) => setApps(value as App[]))
      .catch(() => setApps([]));
  }, []);

  return (
    <main className="px-8 py-8">
      <h1 className="font-display text-3xl font-semibold">Distribution</h1>
      <p className="mt-2 max-w-xl text-sm text-mute">
        Keltri started as an Android app store and still runs one — the public{" "}
        <a href="/store" className="text-signal">
          Store
        </a>
        . It isn't yet unified with Projects/Services: an Android app you publish here
        has no connection to a Project's services, and a Service can't (yet) be
        published to the Store directly from its own page. That's future work, not
        silently missing.
      </p>

      <section className="mt-8">
        <h2 className="font-display text-xl">Your Store listings</h2>
        {apps === null ? (
          <p className="mt-3 text-sm text-mute">Loading…</p>
        ) : apps.length === 0 ? (
          <p className="mt-3 rounded-2xl border border-dashed border-line bg-ink-2 p-6 text-sm text-mute">
            No apps published to the Store yet.
          </p>
        ) : (
          <div className="mt-4 overflow-hidden rounded-2xl border border-line">
            {apps.map((app) => (
              <a
                key={app.id}
                href={`/store/apps/${app.slug}`}
                className="flex items-center justify-between border-b border-line px-5 py-4 last:border-b-0 hover:bg-ink-2"
              >
                <span>{app.name}</span>
                <span className="text-xs uppercase text-mute">{app.status}</span>
              </a>
            ))}
          </div>
        )}
      </section>

      <p className="mt-8 text-xs text-mute">
        Looking to manage your Store listing in full?{" "}
        <Link to="/console/settings" className="text-signal">
          Settings
        </Link>{" "}
        and the public <a href="/store" className="text-signal">Store</a> pages cover
        what exists today.
      </p>
    </main>
  );
}
