import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../lib/api";
import { previewUrl, type ServiceDetail } from "../lib/platform";
import { Status } from "../components/platform";

export function DeploymentDetailPage() {
  const { id = "", serviceId = "", deploymentId = "" } = useParams();
  const [service, setService] = useState<ServiceDetail | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [version, setVersion] = useState(0);
  const [build, setBuild] = useState<{ status: string; logs: string } | null>(null);
  useEffect(() => {
    let active = true;
    setError("");
    api.projects.services.get(id, serviceId).then(value => { if (active) setService(value as ServiceDetail); }).catch(err => { if (active) setError(err.message); });
    return () => { active = false; };
  }, [id, serviceId, version]);
  const deployment = service?.deployments.find(d => d.id === deploymentId);
  useEffect(() => {
    let active = true;
    const load = () => api.projects.services.buildLog(id, serviceId, deploymentId)
      .then(value => { if (active) setBuild(value); })
      .catch(err => { if (active) setError(err instanceof Error ? err.message : "Could not load build logs"); });
    void load();
    if (build?.status === "ready" || build?.status === "failed") return () => { active = false; };
    const timer = setInterval(() => { void load(); setVersion(v => v + 1); }, 4000);
    return () => { active = false; clearInterval(timer); };
  }, [id, serviceId, deploymentId, build?.status]);
  async function promote() {
    setBusy(true); setError("");
    try { await api.projects.services.promote(id, serviceId, deploymentId); setNotice("Deployment promoted to production."); setVersion(v => v + 1); }
    catch (err) { setError(err instanceof Error ? err.message : "Promotion failed"); }
    finally { setBusy(false); }
  }
  return <main className="px-8 py-10 lg:px-12">
    <Link to={`/console/projects/${id}/deployments`} className="text-xs text-mute">← Project deployments</Link>
    {error && <p role="alert" className="mt-6">{error}</p>}
    {notice && <p role="status" className="mt-4 text-sm text-signal">{notice}</p>}
    {!service && !error && <p role="status" className="mt-6">Loading deployment…</p>}
    {service && !deployment && <p className="mt-6">Deployment not found.</p>}
    {service && deployment && <>
      <div className="mt-6 flex flex-wrap items-start justify-between gap-4"><div><Status value={deployment.status} /><h1 className="font-display mt-3 text-3xl font-semibold">{service.name} deployment</h1><p className="mt-2 font-mono text-sm text-mute">{deployment.commitRef ?? deployment.id}</p></div><div className="flex flex-wrap gap-2">{service.type === "web" && deployment.status === "ready" && <><a href={previewUrl(deployment.id)} target="_blank" rel="noreferrer" className="rounded-lg bg-signal px-4 py-2 text-sm text-signal-ink">Visit deployment ↗</a><button className="rounded-lg border border-line px-4 py-2 text-sm" onClick={async () => { try { await navigator.clipboard.writeText(new URL(previewUrl(deployment.id), location.origin).href); setNotice("Preview URL copied."); } catch { setError("Could not copy the URL. Open the deployment to copy it from your browser."); } }}>Copy URL</button></>}{service.isOwner && deployment.status === "ready" && deployment.environment !== "production" && <button disabled={busy} onClick={promote} className="rounded-lg border border-line px-4 py-2 text-sm">{busy ? "Promoting…" : "Promote to Production"}</button>}</div></div>
      <dl className="mt-8 grid gap-6 rounded-xl border border-line bg-ink-2 p-6 sm:grid-cols-2 lg:grid-cols-4">{[["Environment", deployment.environment], ["Created", new Date(deployment.createdAt).toLocaleString()], ["Files", String(deployment.fileCount)], ["Artifact size", `${(deployment.totalBytes / 1024).toLocaleString(undefined, { maximumFractionDigits: 1 })} KB`]].map(([label, value]) => <div key={label}><dt className="text-xs text-mute">{label}</dt><dd className="mt-2 text-sm capitalize">{value}</dd></div>)}</dl>
      <section className="mt-8 rounded-xl border border-line bg-ink-2 p-6"><h2 className="font-semibold">Deployment checks</h2><div className="mt-5 flex items-center justify-between border-b border-line pb-4 text-sm"><span>Artifact upload and extraction</span><Status value={deployment.status} /></div><div className="mt-4 flex items-center justify-between text-sm"><span>Secret scan</span><Status value={deployment.secretScanStatus} /></div><p className="mt-5 text-xs text-mute">Automatic Git builds stream their logs below. Uploaded artifacts have no build logs.</p></section>
      {build && <section className="mt-6 rounded-xl border border-line p-6"><h2 className="font-semibold">Build logs · {build.status}</h2><pre className="mt-4 max-h-96 overflow-auto whitespace-pre-wrap text-xs">{build.logs || "Waiting for a build worker…"}</pre></section>}
      <Link to={`/console/projects/${id}/services/${serviceId}?tab=Deployments`} className="mt-6 inline-block text-sm text-signal">Manage service and inspect scan findings →</Link>
    </>}
  </main>;
}
