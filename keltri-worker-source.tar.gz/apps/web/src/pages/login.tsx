import { Wordmark } from "@keltri/ui";
import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { apiMisconfigured } from "../lib/api-origin";
import { loginRequest } from "../lib/session";

// Real local dev (running on localhost), not just "VITE_API_URL happens to
// be unset" — a deployed build with no API configured is not local demo,
// it's broken, and must not silently autofill working-looking credentials.
const localDemo =
  typeof window !== "undefined" && window.location.hostname === "localhost";
const misconfigured = apiMisconfigured();

export function LoginPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [email, setEmail] = useState(localDemo ? "admin@admin.com" : "");
  const [password, setPassword] = useState(localDemo ? "12345678" : "");
  const [error, setError] = useState(
    params.get("error") ? "GitHub sign-in failed." : "",
  );
  const [pending, setPending] = useState(false);
  const api = import.meta.env.VITE_API_URL || "http://localhost:4000";

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setPending(true);
    setError("");
    try {
      await loginRequest(email, password);
      navigate("/console");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid email or password");
    } finally {
      setPending(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <Link to="/" aria-label="Keltri home">
        <Wordmark />
      </Link>
      <p className="mt-6 font-mono text-[11px] uppercase tracking-widest text-mute">
        Developer console
      </p>
      <h1 className="font-display mt-3 text-4xl font-extrabold">
        Sign in to ship apps.
      </h1>
      <p className="mt-3 text-sm text-mute">
        This console is for developers. The public store does not need an
        account.{" "}
        <Link to="/store" className="text-signal">
          Browse apps
        </Link>
        {localDemo ? (
          <>
            {" "}
            · Local demo{" "}
            <span className="font-mono text-paper">admin@admin.com</span> /{" "}
            <span className="font-mono text-paper">12345678</span>
          </>
        ) : null}
      </p>
      {misconfigured ? (
        <p className="mt-4 rounded-xl border border-ember/40 bg-ember/10 px-4 py-3 text-sm text-ember">
          This deployment has no API configured (<code className="font-mono">
            VITE_API_URL
          </code>{" "}
          isn't set), so sign-in can't work here yet.
        </p>
      ) : null}
      <form className="mt-8 space-y-4" onSubmit={submit}>
        <label className="block text-sm text-mute">
          Email
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 text-paper"
            required
          />
        </label>
        <label className="block text-sm text-mute">
          Password
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 text-paper"
            required
            minLength={8}
          />
        </label>
        {error ? <p className="text-sm text-ember">{error}</p> : null}
        <button
          type="submit"
          disabled={pending}
          className="w-full rounded-full bg-signal px-5 py-3 font-semibold text-signal-ink disabled:opacity-60"
        >
          {pending ? "Signing in…" : "Sign in"}
        </button>
      </form>
      {import.meta.env.VITE_GITHUB_AUTH === "true" ? (
        <a
          href={`${api}/v1/auth/github`}
          className="mt-4 inline-flex w-full justify-center rounded-full border border-line px-5 py-3 text-sm"
        >
          Continue with GitHub
        </a>
      ) : null}
      <p className="mt-6 text-sm text-mute">
        New here?{" "}
        <Link to="/console/register" className="text-signal">
          Create an account
        </Link>
      </p>
    </main>
  );
}
