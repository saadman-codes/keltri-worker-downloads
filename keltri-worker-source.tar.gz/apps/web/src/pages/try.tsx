import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { StoreShell } from "../components/chrome";
import { apiUrl, fetchPublicApp, type PublicApp } from "../lib/catalog";
import { useDocumentTitle } from "../lib/title";
import { NotFoundPage } from "./not-found";

export function TryPage() {
  const { slug = "" } = useParams();
  const [app, setApp] = useState<PublicApp | null | undefined>(undefined);

  useEffect(() => {
    fetchPublicApp(slug).then(setApp);
  }, [slug]);

  useDocumentTitle(app?.name ? `Try ${app.name} — Keltri` : "Keltri");

  if (app === undefined) {
    return (
      <StoreShell>
        <main className="mx-auto max-w-lg px-6 py-12 text-mute">Loading…</main>
      </StoreShell>
    );
  }
  if (!app?.miniAppEnabled) return <NotFoundPage />;

  return (
    <StoreShell>
      <main className="mx-auto max-w-lg px-6 py-12">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">
          Try before install
        </p>
        <h1 className="font-display mt-2 text-3xl font-extrabold">{app.name}</h1>
        <p className="mt-3 text-sm text-mute">
          This web preview uses the same mini-app bundle the Android store loads
          in a sandboxed WebView. Native APIs (camera, share, storage) are
          provided by the JS bridge on device.
        </p>
        <p className="mt-3 text-sm">
          Permissions: {app.permissions.join(", ") || "none declared"}
        </p>
        <iframe
          title={`${app.name} mini-app`}
          src={apiUrl(`/v1/public/apps/${app.slug}/miniapp`)}
          className="mt-6 h-[520px] w-full rounded-2xl border border-line bg-ink-2"
        />
        <div className="mt-6 flex gap-3">
          <Link
            to={`/store/apps/${app.slug}`}
            className="rounded-full border border-line px-4 py-2 text-sm"
          >
            Back to listing
          </Link>
          <Link
            to={`/get/${app.slug}`}
            className="rounded-full bg-signal px-4 py-2 text-sm font-semibold text-signal-ink"
          >
            Install
          </Link>
        </div>
      </main>
    </StoreShell>
  );
}
