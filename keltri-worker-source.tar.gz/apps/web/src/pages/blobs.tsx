import { useEffect, useState } from "react";
import { api } from "../lib/api";

type Blob = {
  key: string;
  contentType: string;
  sizeBytes: number;
  updatedAt: string;
};

export function BlobsPage() {
  const [list, setList] = useState<Blob[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const [key, setKey] = useState("");
  const [error, setError] = useState("");

  function reload() {
    api.blobs
      .list()
      .then((value) => setList(value as Blob[]))
      .catch((err: Error) => setError(err.message));
  }

  useEffect(() => {
    reload();
  }, []);

  async function upload(event: React.FormEvent) {
    event.preventDefault();
    if (!file) {
      setError("Choose a file first.");
      return;
    }
    setError("");
    try {
      const body = new Uint8Array(await file.arrayBuffer());
      await api.blobs.put(
        key || file.name,
        body,
        file.type || "application/octet-stream",
      );
      setFile(null);
      setKey("");
      reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Upload failed");
    }
  }

  async function remove(blobKey: string) {
    await api.blobs.delete(blobKey);
    reload();
  }

  return (
    <main className="px-8 py-8">
      <h1 className="font-display text-3xl font-semibold">Blobs</h1>
      <p className="mt-2 max-w-xl text-sm text-mute">
        Authenticated key/value storage for small files and data — not
        public URLs. Reading a blob requires your API key, unlike a
        deployment's static assets.
      </p>
      <form
        className="mt-8 flex flex-wrap items-end gap-3"
        onSubmit={upload}
      >
        <label className="text-sm text-mute">
          Key (optional — defaults to filename)
          <input
            value={key}
            onChange={(event) => setKey(event.target.value)}
            placeholder="my-file.json"
            className="mt-2 block rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono text-sm"
          />
        </label>
        <input
          type="file"
          className="text-sm"
          onChange={(event) => setFile(event.target.files?.[0] ?? null)}
        />
        <button
          type="submit"
          className="rounded-full bg-signal px-4 py-2 text-sm font-semibold text-signal-ink"
        >
          Upload
        </button>
      </form>
      {error ? <p className="mt-4 text-sm text-ember">{error}</p> : null}
      <table className="mt-10 w-full text-left text-sm">
        <thead className="font-mono text-[11px] uppercase tracking-widest text-mute">
          <tr>
            <th className="py-2">Key</th>
            <th>Content type</th>
            <th>Size</th>
            <th>Updated</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {list.map((blob) => (
            <tr key={blob.key} className="border-t border-line">
              <td className="py-3 font-mono text-xs">{blob.key}</td>
              <td className="font-mono text-xs text-mute">
                {blob.contentType}
              </td>
              <td>{blob.sizeBytes.toLocaleString()} B</td>
              <td>{new Date(blob.updatedAt).toLocaleString()}</td>
              <td className="text-right">
                <button
                  type="button"
                  className="text-xs text-ember"
                  onClick={() => remove(blob.key)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </main>
  );
}
