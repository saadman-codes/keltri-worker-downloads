import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { useOrg } from "../lib/org-context";

export function NewOrganizationPage() {
  const navigate = useNavigate();
  const { setCurrent, reload } = useOrg();
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  return (
    <main className="mx-auto max-w-lg px-8 py-12">
      <h1 className="font-display text-3xl font-semibold">
        Create workspace
      </h1>
      <p className="mt-2 text-sm text-mute">
        A shared workspace. Any member can create and deploy projects under
        it; only owners manage env vars, flags, domains, and membership.
      </p>
      <form
        className="mt-8 space-y-4"
        onSubmit={async (event) => {
          event.preventDefault();
          setError("");
          try {
            const org = (await api.organizations.create({ name })) as {
              id: string;
              name: string;
              slug: string;
              plan: string;
            };
            reload();
            setCurrent({ ...org, role: "owner", createdAt: "" });
            navigate(`/console/organizations/${org.id}/members`);
          } catch (err) {
            setError(
              err instanceof Error ? err.message : "Could not create organization",
            );
          }
        }}
      >
        <label className="block text-sm text-mute">
          Name
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
            required
            minLength={2}
            placeholder="Acme Inc"
          />
        </label>
        {error ? <p className="text-sm text-ember">{error}</p> : null}
        <button
          type="submit"
          className="rounded-full bg-signal px-5 py-3 font-semibold text-signal-ink"
        >
          Create workspace
        </button>
      </form>
    </main>
  );
}
