import { Wordmark } from "@keltri/ui";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { apiMisconfigured } from "../lib/api-origin";
import { registerRequest } from "../lib/session";

const misconfigured = apiMisconfigured();

export function RegisterPage() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <Link to="/" aria-label="Keltri home">
        <Wordmark />
      </Link>
      <p className="mt-6 font-mono text-[11px] uppercase tracking-widest text-mute">
        Developer console
      </p>
      <h1 className="font-display mt-3 text-4xl font-extrabold">Create your account.</h1>
      <p className="mt-3 text-sm text-mute">
        Push a website, a backend, or an Android app — preview it, then
        promote to production. Shoppers can{" "}
        <Link to="/store" className="text-signal">
          browse the store
        </Link>{" "}
        without an account.
      </p>
      {misconfigured ? (
        <p className="mt-4 rounded-xl border border-ember/40 bg-ember/10 px-4 py-3 text-sm text-ember">
          This deployment has no API configured (<code className="font-mono">
            VITE_API_URL
          </code>{" "}
          isn't set), so sign-up can't work here yet.
        </p>
      ) : null}
      <form
        className="mt-8 space-y-4"
        onSubmit={async (event) => {
          event.preventDefault();
          setPending(true);
          setError("");
          try {
            await registerRequest({ name, email, password });
            navigate("/console");
          } catch (err) {
            setError(
              err instanceof Error ? err.message : "Could not create account",
            );
          } finally {
            setPending(false);
          }
        }}
      >
        <label className="block text-sm text-mute">
          Name
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
            required
            minLength={2}
          />
        </label>
        <label className="block text-sm text-mute">
          Email
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
            required
          />
        </label>
        <label className="block text-sm text-mute">
          Password
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
            required
            minLength={8}
          />
        </label>
        {error ? <p className="text-sm text-ember">{error}</p> : null}
        <button
          type="submit"
          disabled={pending}
          className="w-full rounded-full bg-signal px-5 py-3 font-semibold text-signal-ink"
        >
          {pending ? "Creating…" : "Create account"}
        </button>
      </form>
      <p className="mt-6 text-sm text-mute">
        Already have an account?{" "}
        <Link to="/console/login" className="text-signal">
          Sign in
        </Link>
      </p>
    </main>
  );
}
