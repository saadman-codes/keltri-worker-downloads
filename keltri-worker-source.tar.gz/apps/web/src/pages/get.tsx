import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AppIcon } from "../components/app-card";
import { StoreShell } from "../components/chrome";
import { apiUrl, fetchPublicApp, type PublicApp } from "../lib/catalog";
import { ABUSE_EMAIL, abuseMailto } from "../lib/contacts";
import { useDocumentTitle } from "../lib/title";

export function GetAppPage() {
  const { slug = "" } = useParams();
  const [app, setApp] = useState<PublicApp | null | undefined>(undefined);
  const download = apiUrl(`/v1/public/apps/${slug}/bootstrapper`);

  useEffect(() => {
    setApp(undefined);
    fetchPublicApp(slug).then(setApp);
  }, [slug]);

  const name = app?.name ?? slug;
  useDocumentTitle(
    app ? `Install ${name} — Keltri` : "Install — Keltri",
  );

  return (
    <StoreShell>
      <main className="mx-auto max-w-lg px-6 py-24 text-center">
        {app === undefined ? (
          <p className="text-sm text-mute">Loading…</p>
        ) : app ? (
          <>
            <div className="flex justify-center">
              <AppIcon app={app} size="lg" />
            </div>
            <p className="mt-6 font-mono text-xs uppercase tracking-widest text-signal">
              Sideload
            </p>
            <h1 className="font-display mt-4 text-4xl font-extrabold">
              Get {name} on your phone
            </h1>
            <p className="mt-4 text-mute">
              Download a small bootstrapper APK. This is not a Google Play
              install. You will likely need to allow this browser or file app
              to install unknown sources. After that, later versions can arrive
              over OTA from this catalog.
            </p>
            <a
              href={download}
              className="mt-8 inline-flex rounded-full bg-signal px-6 py-3 font-semibold text-signal-ink"
            >
              Download APK
            </a>
            <p className="mt-6 text-sm text-mute">
              <Link to="/install-help" className="text-signal">
                How to allow unknown sources
              </Link>
              {" · "}
              <Link to="/terms" className="text-signal">
                Terms
              </Link>
              {" · "}
              <Link to="/privacy" className="text-signal">
                Privacy
              </Link>
            </p>
            {app.miniAppEnabled ? (
              <p className="mt-6 text-sm text-mute">
                Want to try it first?{" "}
                <Link to={`/store/apps/${slug}/try`} className="text-signal">
                  Open the web preview
                </Link>
              </p>
            ) : null}
          </>
        ) : (
          <>
            <p className="font-mono text-xs uppercase tracking-widest text-signal">
              Unavailable
            </p>
            <h1 className="font-display mt-4 text-4xl font-extrabold">
              This listing is not available
            </h1>
            <p className="mt-4 text-mute">
              It may be unpublished, private, or never existed. We do not
              offer a download unless the listing is public.
            </p>
            <p className="mt-6 text-sm text-mute">
              <Link to="/store" className="text-signal">
                Back to the catalog
              </Link>
              {" · "}
              <Link to="/install-help" className="text-signal">
                Install help
              </Link>
              {" · "}
              <a href={abuseMailto} className="text-signal">
                Report abuse ({ABUSE_EMAIL})
              </a>
            </p>
          </>
        )}
      </main>
    </StoreShell>
  );
}
