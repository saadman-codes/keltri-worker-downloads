import { sites } from "@keltri/ui";
import { Fragment, useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { api } from "../lib/api";

import { previewUrl, productionUrl } from "../lib/platform";

type SecretFinding = { file: string; rule: string; line: number; preview: string };

type Deployment = {
  id: string;
  environment: "preview" | "production";
  status: "queued" | "building" | "uploading" | "ready" | "stub" | "failed";
  commitRef: string | null;
  fileCount: number;
  totalBytes: number;
  promotedAt: string | null;
  createdAt: string;
  secretScanStatus: "pending" | "clean" | "flagged";
  secretFindings: SecretFinding[] | null;
};

type EnvVar = { id: string; key: string; target: "all" | "production" | "preview" };
type FeatureFlag = {
  id: string;
  key: string;
  enabled: boolean;
  rolloutPercent: number;
  target: "all" | "production" | "preview";
};
type DailyStat = { date: string; views: number };
type Analytics = { series: DailyStat[]; totalViews: number };
type Domain = { id: string; hostname: string; verified: boolean };
type GitLink = { repoFullName: string; defaultBranch: string } | null;

type Service = {
  id: string;
  projectId: string;
  slug: string;
  name: string;
  type: "web" | "backend" | "android" | "worker" | "desktop";
  buildCommand: string | null;
  startCommand: string | null;
  outputDir: string | null;
  isOwner: boolean;
  automaticBuildsEnabled: boolean;
  deployments: Deployment[];
  gitLink: GitLink;
  project: { id: string; slug: string; name: string };
};

const TABS = [
  "Overview",
  "Deployments",
  "Environment Variables",
  "Domains",
  "Feature Flags",
  "Analytics",
] as const;
type Tab = (typeof TABS)[number];

export function ServiceDetailPage() {
  const { id = "", serviceId = "" } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [service, setService] = useState<Service | null>(null);
  const requestedTab = searchParams.get("tab");
  const tab: Tab = TABS.includes(requestedTab as Tab) ? requestedTab as Tab : "Overview";
  const setTab = (value: Tab) => setSearchParams({ tab: value });
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [buildBusy, setBuildBusy] = useState(false);

  const [file, setFile] = useState<File | null>(null);
  const [commitRef, setCommitRef] = useState("");
  const [progress, setProgress] = useState(0);

  const [expandedFindings, setExpandedFindings] = useState<string | null>(null);

  const [envList, setEnvList] = useState<EnvVar[]>([]);
  const [envKey, setEnvKey] = useState("");
  const [envValue, setEnvValue] = useState("");
  const [envTarget, setEnvTarget] = useState<EnvVar["target"]>("all");

  const [flagList, setFlagList] = useState<FeatureFlag[]>([]);
  const [flagKey, setFlagKey] = useState("");
  const [flagRollout, setFlagRollout] = useState(100);
  const [flagTarget, setFlagTarget] = useState<FeatureFlag["target"]>("all");

  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [hoveredDay, setHoveredDay] = useState<string | null>(null);

  const [domainList, setDomainList] = useState<Domain[]>([]);
  const [hostname, setHostname] = useState("");
  const [domainError, setDomainError] = useState("");

  function reload() {
    api.projects.services
      .get(id, serviceId)
      .then((value) => setService(value as Service))
      .catch((err: Error) => setError(err.message));
  }

  function reloadEnv() {
    api.projects.services
      .envList(id, serviceId)
      .then((value) => setEnvList(value as EnvVar[]))
      .catch(() => {});
  }

  function reloadFlags() {
    api.projects.services.flags
      .list(id, serviceId)
      .then((value) => setFlagList(value as FeatureFlag[]))
      .catch(() => {});
  }

  function reloadAnalytics() {
    api.projects
      .analytics(id)
      .then((value) => setAnalytics(value as Analytics))
      .catch(() => {});
  }

  function reloadDomains() {
    api.projects.services.domains
      .list(id, serviceId)
      .then((value) => setDomainList(value as Domain[]))
      .catch(() => {});
  }

  useEffect(() => {
    reload();
    reloadEnv();
    reloadFlags();
    reloadAnalytics();
    reloadDomains();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, serviceId]);

  useEffect(() => {
    if (!service?.deployments.some(d => d.status === "queued" || d.status === "building")) return;
    const timer = setInterval(reload, 4000);
    return () => clearInterval(timer);
  }, [id, serviceId, service?.deployments]);

  async function deployFromGit() {
    setBuildBusy(true); setError("");
    try {
      await api.projects.services.build(id, serviceId);
      setMessage("Build queued. Open the deployment to follow its logs.");
      reload();
    } catch (err) { setError(err instanceof Error ? err.message : "Could not queue build"); }
    finally { setBuildBusy(false); }
  }

  if (!service) {
    return (
      <main className="px-8 py-8">
        {error ? <p className="text-sm text-ember">{error}</p> : null}
      </main>
    );
  }

  async function deployWeb(event: React.FormEvent) {
    event.preventDefault();
    if (!file) {
      setError("Choose a build output .zip first.");
      return;
    }
    setError("");
    setMessage("");
    setProgress(5);
    const created = await api.projects.services.uploadUrl(id, serviceId, { commitRef });
    setProgress(15);
    await new Promise<void>((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("PUT", created.uploadUrl);
      xhr.setRequestHeader("Content-Type", file.type || "application/zip");
      xhr.upload.onprogress = (evt) => {
        if (evt.lengthComputable) {
          setProgress(15 + Math.round((evt.loaded / evt.total) * 70));
        }
      };
      xhr.onload = () =>
        xhr.status >= 200 && xhr.status < 300 ? resolve() : reject(new Error("Upload failed"));
      xhr.onerror = () => reject(new Error("Upload failed"));
      xhr.send(file);
    });
    setProgress(90);
    await api.projects.services.finalize(id, serviceId, created.deploymentId);
    setProgress(100);
    setMessage("Build deployed. Open the preview link below.");
    setFile(null);
    reload();
  }

  async function recordBackendDeployment(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    await api.projects.services.recordDeployment(id, serviceId, { commitRef });
    setMessage("Deployment recorded. Process execution isn't implemented yet — nothing is actually running.");
    reload();
  }

  async function promote(deploymentId: string) {
    setError("");
    await api.projects.services.promote(id, serviceId, deploymentId);
    setMessage("Promoted to production.");
    reload();
  }

  async function rollback() {
    setError("");
    try {
      await api.projects.services.rollback(id, serviceId);
      setMessage("Rolled back to the previous production deployment.");
      reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not roll back");
    }
  }

  async function addEnvVar(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    try {
      await api.projects.services.envSet(id, serviceId, { key: envKey, value: envValue, target: envTarget });
      setEnvKey("");
      setEnvValue("");
      reloadEnv();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save variable");
    }
  }

  async function removeEnvVar(envId: string) {
    await api.projects.services.envDelete(id, serviceId, envId);
    reloadEnv();
  }

  async function addFlag(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    try {
      await api.projects.services.flags.set(id, serviceId, {
        key: flagKey,
        enabled: true,
        rolloutPercent: flagRollout,
        target: flagTarget,
      });
      setFlagKey("");
      setFlagRollout(100);
      reloadFlags();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save flag");
    }
  }

  async function toggleFlag(flag: FeatureFlag) {
    await api.projects.services.flags.set(id, serviceId, {
      key: flag.key,
      enabled: !flag.enabled,
      rolloutPercent: flag.rolloutPercent,
      target: flag.target,
    });
    reloadFlags();
  }

  async function removeFlag(flagId: string) {
    await api.projects.services.flags.remove(id, serviceId, flagId);
    reloadFlags();
  }

  async function addDomain(event: React.FormEvent) {
    event.preventDefault();
    setDomainError("");
    try {
      await api.projects.services.domains.create(id, serviceId, { hostname });
      setHostname("");
      reloadDomains();
    } catch (err) {
      setDomainError(err instanceof Error ? err.message : "Could not add domain");
    }
  }

  async function removeDomain(domainId: string) {
    await api.projects.services.domains.remove(id, serviceId, domainId);
    reloadDomains();
  }

  const canRollback = service.deployments.filter((d) => d.promotedAt).length > 1;
  const prodUrl = productionUrl(service.project.slug, service.slug);

  return (
    <main className="px-8 py-8">
      <Link to={`/console/projects/${id}`} className="text-xs text-mute hover:text-paper">
        ← {service.project.name}
      </Link>
      <div className="mt-2 flex items-start justify-between">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-widest text-mute">{service.type}</p>
          <h1 className="font-display mt-1 text-3xl font-semibold">{service.name}</h1>
          {service.type === "web" ? (
            <p className="mt-1 text-sm text-mute">
              Production:{" "}
              <a href={prodUrl} target="_blank" rel="noreferrer" className="text-signal">
                {prodUrl}
              </a>
            </p>
          ) : (
            <p className="mt-1 text-sm text-mute">
              Start command: <span className="font-mono">{service.startCommand}</span>
            </p>
          )}
          {service.gitLink ? (
            <p className="mt-1 text-xs text-mute">
              Imported from{" "}
              <span className="font-mono text-paper">{service.gitLink.repoFullName}</span> (
              {service.gitLink.defaultBranch})
            </p>
          ) : null}
        </div>
        {canRollback && service.isOwner ? (
          <button
            type="button"
            onClick={rollback}
            className="rounded-full border border-line px-4 py-2 text-sm"
          >
            One-click rollback
          </button>
        ) : null}
      </div>

      {!service.isOwner ? (
        <p className="mt-4 rounded-xl border border-line bg-ink-2 p-3 text-sm text-mute">
          You have view access to this service. Only the project owner can deploy, edit
          settings, or manage rollbacks.
        </p>
      ) : null}

      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-line text-sm">
        {TABS.filter((t) => service.type === "web" || (t !== "Domains" && t !== "Analytics")).map(
          (t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={`shrink-0 border-b-2 px-3 py-2 ${
                tab === t ? "border-signal text-signal" : "border-transparent text-mute hover:text-paper"
              }`}
            >
              {t}
            </button>
          ),
        )}
      </div>

      {message ? <p className="mt-4 text-sm text-signal">{message}</p> : null}
      {error ? <p className="mt-4 text-sm text-ember">{error}</p> : null}

      {tab === "Overview" ? (
        <div className="mt-6 space-y-8">
          {service.isOwner && !service.gitLink ? (
            <form
              className="rounded-2xl border border-line p-5"
              onSubmit={service.type === "web" ? deployWeb : recordBackendDeployment}
            >
              <h2 className="font-display text-xl">
                {service.type === "web" ? "Deploy a build" : "Record a deployment"}
              </h2>
              {service.type === "web" ? (
                <p className="mt-1 text-sm text-mute">
                  Zip your build output ({service.buildCommand ?? "your build command"}
                  's result — e.g. `{service.outputDir ?? "dist"}/`) and upload it here.
                </p>
              ) : (
                <p className="mt-1 text-sm text-mute">
                  Backend hosting doesn't run anything yet. This records the deployment's
                  metadata so the flow exists end to end.
                </p>
              )}
              {service.type === "web" ? (
                <input
                  type="file"
                  accept=".zip,application/zip"
                  className="mt-4 block w-full text-sm"
                  onChange={(event) => setFile(event.target.files?.[0] ?? null)}
                />
              ) : null}
              <input
                value={commitRef}
                onChange={(event) => setCommitRef(event.target.value)}
                placeholder="Commit ref or note (optional)"
                className="mt-4 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
              />
              {progress > 0 ? (
                <div className="mt-4 h-2 overflow-hidden rounded-full bg-ink-3">
                  <div className="h-full bg-signal" style={{ width: `${progress}%` }} />
                </div>
              ) : null}
              <button
                type="submit"
                className="mt-4 rounded-full bg-signal px-4 py-2 text-sm font-semibold text-signal-ink"
              >
                {service.type === "web" ? "Upload & deploy" : "Record deployment"}
              </button>
            </form>
          ) : null}

          {service.gitLink && service.type === "web" ? (
            <section className="rounded-2xl border border-line p-5">
              <h2 className="font-display text-xl">Automatic deployments</h2>
              <p className="mt-2 text-sm text-mute">
                {service.automaticBuildsEnabled
                  ? `Pushes to ${service.gitLink.defaultBranch} build and publish production. Other branches create previews.`
                  : "Your repository is connected. Automatic builds are awaiting platform setup."}
              </p>
              {service.isOwner && service.automaticBuildsEnabled && <button type="button" disabled={buildBusy} onClick={deployFromGit} className="mt-4 rounded-full bg-signal px-4 py-2 text-sm text-signal-ink">{buildBusy ? "Queuing…" : "Deploy latest commit"}</button>}
              {service.deployments[0] && <Link className="mt-4 block text-sm text-signal" to={`/console/projects/${id}/services/${serviceId}/deployments/${service.deployments[0].id}`}>Latest deployment: {service.deployments[0].status} — view logs →</Link>}
            </section>
          ) : null}
        </div>
      ) : null}

      {tab === "Deployments" ? (
        <table className="mt-6 w-full text-left text-sm">
          <thead className="font-mono text-[11px] uppercase tracking-widest text-mute">
            <tr>
              <th className="py-2">Deployment</th>
              <th>Environment</th>
              <th>Status</th>
              <th>Files</th>
              <th>Secrets</th>
              <th>Date</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {service.deployments.map((deployment) => (
              <Fragment key={deployment.id}>
                <tr className="border-t border-line">
                  <td className="py-3 font-mono text-xs">
                    <Link to={`/console/projects/${id}/services/${serviceId}/deployments/${deployment.id}`} className="text-signal">{deployment.commitRef ?? deployment.id.slice(0, 8)}</Link>
                  </td>
                  <td className="uppercase">{deployment.environment}</td>
                  <td className="uppercase">{deployment.status}</td>
                  <td>
                    {deployment.status === "ready"
                      ? `${deployment.fileCount} file${deployment.fileCount === 1 ? "" : "s"}`
                      : "—"}
                  </td>
                  <td>
                    {deployment.secretScanStatus === "flagged" ? (
                      <button
                        type="button"
                        className="rounded-full bg-ember/20 px-2 py-0.5 text-xs text-ember"
                        onClick={() =>
                          setExpandedFindings(expandedFindings === deployment.id ? null : deployment.id)
                        }
                      >
                        ⚠ Flagged ({deployment.secretFindings?.length ?? 0})
                      </button>
                    ) : deployment.secretScanStatus === "clean" ? (
                      <span className="text-xs text-mute">Clean</span>
                    ) : (
                      <span className="text-xs text-mute">—</span>
                    )}
                  </td>
                  <td>{new Date(deployment.createdAt).toLocaleString()}</td>
                  <td className="space-x-3 py-3 text-right">
                    {deployment.status === "ready" ? (
                      <a
                        href={previewUrl(deployment.id)}
                        target="_blank"
                        rel="noreferrer"
                        className="text-signal"
                      >
                        Preview
                      </a>
                    ) : null}
                    {(deployment.status === "ready" || deployment.status === "stub") &&
                    deployment.environment !== "production" &&
                    service.isOwner ? (
                      <button
                        type="button"
                        onClick={() => promote(deployment.id)}
                        className="text-mute hover:text-paper"
                      >
                        Promote
                      </button>
                    ) : null}
                  </td>
                </tr>
                {expandedFindings === deployment.id && deployment.secretFindings ? (
                  <tr className="border-t border-line bg-ink-2">
                    <td colSpan={7} className="p-3">
                      <table className="w-full text-left text-xs">
                        <tbody>
                          {deployment.secretFindings.map((finding, index) => (
                            <tr key={index}>
                              <td className="py-1 font-mono">{finding.file}</td>
                              <td className="py-1 font-mono text-mute">line {finding.line}</td>
                              <td className="py-1 font-mono text-mute">{finding.rule}</td>
                              <td className="py-1 font-mono text-ember">{finding.preview}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                ) : null}
              </Fragment>
            ))}
          </tbody>
        </table>
      ) : null}

      {tab === "Environment Variables" ? (
        <section className="mt-6 rounded-2xl border border-line p-5">
          <p className="text-sm text-mute">
            Values are hidden after saving. Builds use variables for their production
            or preview target. Redeploy after changes. Promoting an artifact does not rebuild it.
          </p>
          {envList.length > 0 ? (
            <table className="mt-4 w-full text-left text-sm">
              <tbody>
                {envList.map((envVar) => (
                  <tr key={envVar.id} className="border-t border-line">
                    <td className="py-2 font-mono text-xs">{envVar.key}</td>
                    <td className="font-mono text-xs text-mute" aria-label="Value hidden">••••••••</td>
                    <td className="font-mono text-[11px] uppercase text-mute">{envVar.target}</td>
                    <td className="text-right">
                      {service.isOwner ? (
                        <button
                          type="button"
                          onClick={() => removeEnvVar(envVar.id)}
                          className="text-mute hover:text-paper"
                        >
                          Remove
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}
          {service.isOwner ? (
            <form className="mt-4 flex flex-wrap items-center gap-2" onSubmit={addEnvVar}>
              <input
                value={envKey}
                onChange={(event) => setEnvKey(event.target.value.toUpperCase())}
                placeholder="DATABASE_URL"
                className="min-w-0 flex-1 rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono text-sm"
                required
              />
              <input
                value={envValue}
                type="password"
                autoComplete="new-password"
                onChange={(event) => setEnvValue(event.target.value)}
                placeholder="value"
                className="min-w-0 flex-1 rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono text-sm"
                required
              />
              <select
                value={envTarget}
                onChange={(event) => setEnvTarget(event.target.value as EnvVar["target"])}
                className="rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
              >
                <option value="all">All</option>
                <option value="production">Production</option>
                <option value="preview">Preview</option>
              </select>
              <button type="submit" className="rounded-full border border-line px-4 py-2 text-sm">
                Add
              </button>
            </form>
          ) : null}
        </section>
      ) : null}

      {tab === "Domains" && service.type === "web" ? (
        <section className="mt-6 rounded-2xl border border-line p-5">
          <p className="text-sm text-mute">
            Recorded for real, but not functional yet — no DNS verification, no SSL, and
            no request routing by this hostname happens. Requests still only resolve at
            the production address above.
          </p>
          {domainList.length > 0 ? (
            <table className="mt-4 w-full text-left text-sm">
              <tbody>
                {domainList.map((domain) => (
                  <tr key={domain.id} className="border-t border-line">
                    <td className="py-2 font-mono text-xs">{domain.hostname}</td>
                    <td>
                      <span className="rounded-full bg-ink-3 px-2 py-0.5 text-xs text-mute">
                        Not verified
                      </span>
                    </td>
                    <td className="text-right">
                      {service.isOwner ? (
                        <button
                          type="button"
                          onClick={() => removeDomain(domain.id)}
                          className="text-mute hover:text-paper"
                        >
                          Remove
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}
          {service.isOwner ? (
            <form className="mt-4 flex flex-wrap gap-2" onSubmit={addDomain}>
              <input
                value={hostname}
                onChange={(event) => setHostname(event.target.value)}
                placeholder="app.example.com"
                className="min-w-0 flex-1 rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono text-sm"
                required
              />
              <button type="submit" className="rounded-full border border-line px-4 py-2 text-sm">
                Add
              </button>
            </form>
          ) : null}
          {domainError ? <p className="mt-3 text-sm text-ember">{domainError}</p> : null}
        </section>
      ) : null}

      {tab === "Feature Flags" ? (
        <section className="mt-6 rounded-2xl border border-line p-5">
          <p className="text-sm text-mute">
            Read from your own code with a plain fetch — no SDK required:{" "}
            <code className="font-mono text-xs">
              {sites.api}/v1/public/flags/{service.project.slug}/{service.slug}
            </code>
          </p>
          {flagList.length > 0 ? (
            <table className="mt-4 w-full text-left text-sm">
              <tbody>
                {flagList.map((flag) => (
                  <tr key={flag.id} className="border-t border-line">
                    <td className="py-2 font-mono text-xs">{flag.key}</td>
                    <td>
                      <button
                        type="button"
                        onClick={() => toggleFlag(flag)}
                        className={flag.enabled ? "text-signal" : "text-mute"}
                      >
                        {flag.enabled ? "Enabled" : "Disabled"}
                      </button>
                    </td>
                    <td className="text-xs text-mute">{flag.rolloutPercent}%</td>
                    <td className="font-mono text-[11px] uppercase text-mute">{flag.target}</td>
                    <td className="text-right">
                      {service.isOwner ? (
                        <button
                          type="button"
                          onClick={() => removeFlag(flag.id)}
                          className="text-mute hover:text-paper"
                        >
                          Remove
                        </button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}
          {service.isOwner ? (
            <form className="mt-4 flex flex-wrap items-center gap-2" onSubmit={addFlag}>
              <input
                value={flagKey}
                onChange={(event) => setFlagKey(event.target.value)}
                placeholder="new-checkout"
                className="min-w-0 flex-1 rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono text-sm"
                required
              />
              <input
                type="number"
                min={0}
                max={100}
                value={flagRollout}
                onChange={(event) => setFlagRollout(Number(event.target.value))}
                className="w-20 rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
              />
              <select
                value={flagTarget}
                onChange={(event) => setFlagTarget(event.target.value as FeatureFlag["target"])}
                className="rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
              >
                <option value="all">All</option>
                <option value="production">Production</option>
                <option value="preview">Preview</option>
              </select>
              <button type="submit" className="rounded-full border border-line px-4 py-2 text-sm">
                Add
              </button>
            </form>
          ) : null}
        </section>
      ) : null}

      {tab === "Analytics" && service.type === "web" && analytics ? (
        <section className="mt-6 rounded-2xl border border-line p-5">
          <p className="text-sm text-mute">
            Page views on the production URL only — preview traffic and sub-resource
            requests (JS/CSS/images) aren't counted. Rolls up at the project level, not
            per-service.
          </p>
          <p className="font-display mt-3 text-3xl font-semibold">
            {analytics.totalViews.toLocaleString()}
            <span className="ml-2 text-sm font-normal text-mute">views, last 30 days</span>
          </p>
          {analytics.series.length > 0 ? (
            <div className="relative mt-4 flex h-24 items-end gap-1">
              {analytics.series.map((day) => {
                const max = Math.max(...analytics.series.map((d) => d.views), 1);
                const heightPct = Math.max(4, (day.views / max) * 100);
                return (
                  <div
                    key={day.date}
                    className="group relative flex h-full flex-1 items-end"
                    onMouseEnter={() => setHoveredDay(day.date)}
                    onMouseLeave={() => setHoveredDay(null)}
                  >
                    <div className="w-full rounded-t bg-signal" style={{ height: `${heightPct}%` }} />
                    {hoveredDay === day.date ? (
                      <div className="pointer-events-none absolute bottom-full left-1/2 mb-1 -translate-x-1/2 whitespace-nowrap rounded-lg border border-line bg-ink-3 px-2 py-1 text-xs">
                        {new Date(day.date).toLocaleDateString()}: {day.views} view
                        {day.views === 1 ? "" : "s"}
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="mt-4 text-sm text-mute">No traffic recorded yet.</p>
          )}
        </section>
      ) : null}
    </main>
  );
}
