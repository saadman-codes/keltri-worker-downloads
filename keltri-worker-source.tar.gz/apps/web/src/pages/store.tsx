import { FormEvent, useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { AppCard, AppIcon, AppRail, StoreActions } from "../components/app-card";
import { StoreShell } from "../components/chrome";
import {
  allowSampleCatalogFallback,
  emptyCatalog,
  fetchCatalog,
  sampleCatalog,
  uniqueApps,
  type Catalog,
  type CatalogApp,
} from "../lib/catalog";
import { useDocumentTitle } from "../lib/title";

const fallbackCategories = [
  "games",
  "tools",
  "productivity",
  "finance",
  "social",
];

export function StorePage() {
  const [params] = useSearchParams();
  const query = (params.get("q") ?? "").trim().toLowerCase();
  const category = params.get("category") ?? "";
  const [catalog, setCatalog] = useState<Catalog | undefined>(undefined);
  const [live, setLive] = useState(true);
  const [loadError, setLoadError] = useState(false);

  useDocumentTitle(
    category === "games" ? "Games — Keltri Store" : "Apps — Keltri Store",
  );

  useEffect(() => {
    fetchCatalog().then((data) => {
      if (data) {
        setCatalog(data);
        setLive(true);
        setLoadError(false);
        return;
      }
      if (allowSampleCatalogFallback()) {
        setCatalog(sampleCatalog);
        setLive(false);
        setLoadError(false);
        return;
      }
      setCatalog(emptyCatalog);
      setLive(true);
      setLoadError(true);
    });
  }, []);

  const apps = useMemo(() => (catalog ? uniqueApps(catalog) : []), [catalog]);
  const categories = catalog?.categories?.length
    ? catalog.categories
    : live
      ? []
      : fallbackCategories;

  const filtered = useMemo(() => {
    return apps.filter((app) => {
      if (category && app.category !== category) return false;
      if (!query) return true;
      const haystack =
        `${app.name} ${app.shortDescription ?? ""} ${app.developer.name} ${app.category ?? ""}`.toLowerCase();
      return haystack.includes(query);
    });
  }, [apps, category, query]);

  const featured =
    catalog?.featured.find((app) => filtered.some((item) => item.slug === app.slug)) ??
    filtered[0];
  const games = filtered.filter((app) => app.category === "games");
  const charts = (category ? filtered : catalog?.top ?? filtered).slice(0, 10);

  return (
    <StoreShell>
      <main className="mx-auto max-w-6xl px-6 py-8">
        <h1 className="sr-only">
          {category === "games" ? "Games" : "Android apps"} on the Keltri Store
        </h1>
        <StoreSearch />
        <div className="mt-6 flex flex-wrap gap-2">
          <CategoryChip
            label="All"
            active={!category}
            to={query ? `/store?q=${encodeURIComponent(query)}` : "/store"}
          />
          {categories.map((item) => (
            <CategoryChip
              key={item}
              label={item}
              active={category === item}
              to={
                query
                  ? `/store?category=${item}&q=${encodeURIComponent(query)}`
                  : `/store?category=${item}`
              }
            />
          ))}
        </div>
        {live ? null : (
          <p className="mt-4 text-xs text-mute">
            Local demo catalog (fictional install counts). Live apps appear
            when the API is reachable.
          </p>
        )}
        {loadError ? (
          <p className="mt-4 text-xs text-mute">
            The catalog is unavailable right now. No sample listings are shown
            on this host.
          </p>
        ) : null}

        {catalog === undefined ? (
          <p className="mt-10 text-sm text-mute">Loading apps…</p>
        ) : filtered.length === 0 ? (
          <p className="mt-10 text-sm text-mute">
            {query || category
              ? "No apps match that search."
              : loadError
                ? "The catalog could not be loaded."
                : "No live public apps yet."}
          </p>
        ) : query ? (
          <section className="mt-10">
            <h2 className="font-display text-2xl">Results for “{query}”</h2>
            <div className="mt-4 flex flex-wrap gap-3">
              {filtered.map((app) => (
                <AppCard key={app.slug} app={app} />
              ))}
            </div>
          </section>
        ) : (
          <>
            {featured ? <FeaturedApp app={featured} /> : null}
            <AppRail
              title={category ? capitalize(category) : "New this week"}
              apps={
                category
                  ? filtered
                  : catalog.newThisWeek.length
                    ? catalog.newThisWeek
                    : filtered
              }
            />
            {category ? null : <AppRail title="Games" apps={games} />}
            <section className="mt-12">
              <h2 className="font-display text-2xl">Top charts</h2>
              <ol className="mt-4 divide-y divide-line overflow-hidden rounded-2xl border border-line">
                {charts.map((app, index) => (
                  <li
                    key={app.slug}
                    className="flex items-center gap-4 px-4 py-3"
                  >
                    <span className="w-6 font-mono text-sm text-mute">
                      {index + 1}
                    </span>
                    <Link
                      to={`/store/apps/${app.slug}`}
                      className="flex min-w-0 flex-1 items-center gap-4 hover:text-signal"
                    >
                      <AppIcon app={app} size="sm" />
                      <span className="min-w-0">
                        <span className="block truncate">{app.name}</span>
                        <span className="block truncate text-xs text-mute">
                          {app.developer.name} · ★ {app.rating} ·{" "}
                          {app.installs.toLocaleString()} installs
                        </span>
                      </span>
                    </Link>
                    <StoreActions app={app} />
                  </li>
                ))}
              </ol>
            </section>
          </>
        )}
      </main>
    </StoreShell>
  );
}

function StoreSearch() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const [query, setQuery] = useState(params.get("q") ?? "");

  function submit(event: FormEvent) {
    event.preventDefault();
    const next = new URLSearchParams();
    if (query.trim()) next.set("q", query.trim());
    const category = params.get("category");
    if (category) next.set("category", category);
    navigate(`/store${next.toString() ? `?${next}` : ""}`);
  }

  return (
    <form onSubmit={submit} className="max-w-md">
      <label className="sr-only" htmlFor="store-search">
        Search apps
      </label>
      <input
        id="store-search"
        value={query}
        onChange={(event) => setQuery(event.target.value)}
        placeholder="Search apps and games"
        className="w-full rounded-full border border-line bg-ink-2 px-4 py-2 text-sm text-paper placeholder:text-mute"
      />
    </form>
  );
}

function FeaturedApp({ app }: { app: CatalogApp }) {
  return (
    <section className="mt-8 overflow-hidden rounded-3xl border border-line bg-ink-2">
      <div className="flex flex-col gap-6 p-6 md:flex-row md:items-center md:p-8">
        <AppIcon app={app} size="lg" />
        <div className="min-w-0 flex-1">
          <p className="font-mono text-xs uppercase tracking-widest text-mute">
            Featured
          </p>
          <h2 className="font-display mt-2 text-3xl md:text-4xl">{app.name}</h2>
          <p className="mt-2 text-sm text-mute">
            {app.developer.name} · {app.category} · ★ {app.rating} ·{" "}
            {app.installs.toLocaleString()} installs
          </p>
          <p className="mt-3 max-w-xl text-paper/90">{app.shortDescription}</p>
          <div className="mt-6">
            <StoreActions app={app} size="md" />
          </div>
        </div>
        <div className="hidden gap-2 lg:flex">
          {[0, 1, 2].map((index) => (
            <div
              key={index}
              className="h-44 w-24 rounded-2xl bg-ink-3 p-3"
            >
              <p className="font-display text-sm text-paper/80">{app.name}</p>
              <p className="mt-2 text-[10px] uppercase tracking-widest text-mute">
                Preview {index + 1}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CategoryChip({
  label,
  to,
  active,
}: {
  label: string;
  to: string;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      className={`rounded-full px-3 py-1 text-sm capitalize ${
        active
          ? "bg-signal font-semibold text-signal-ink"
          : "border border-line text-mute hover:text-paper"
      }`}
    >
      {label}
    </Link>
  );
}

function capitalize(value: string) {
  return value.slice(0, 1).toUpperCase() + value.slice(1);
}
