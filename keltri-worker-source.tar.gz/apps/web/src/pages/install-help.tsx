import { Link } from "react-router-dom";
import { StoreShell } from "../components/chrome";
import { ABUSE_EMAIL, abuseMailto } from "../lib/contacts";
import { useDocumentTitle } from "../lib/title";

export function InstallHelpPage() {
  useDocumentTitle("Install help — Keltri");

  return (
    <StoreShell>
      <main className="mx-auto max-w-3xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">
          Sideloading
        </p>
        <h1 className="font-display mt-3 text-4xl font-extrabold">
          Install the bootstrapper on Android
        </h1>
        <p className="mt-4 text-mute">
          Keltri listings install with a small APK you sideload — not
          through Google Play. Wording differs by manufacturer and Android
          version; use search in Settings if a label below does not match.
        </p>

        <ol className="mt-10 space-y-8">
          <Step n="1" title="Download the APK on the phone">
            Open the app’s{" "}
            <span className="font-mono text-paper">/get/&lt;slug&gt;</span>{" "}
            page in Chrome or another browser on the Android device. Tap
            Download APK. You can also move the file from a computer via USB
            or Files, then open it on the phone.
          </Step>
          <Step n="2" title="Allow this source to install unknown apps">
            Android will often block the first install from a browser or file
            manager. When prompted, open the settings screen for that app
            (Chrome, Files, Drive, etc.) and enable{" "}
            <strong className="text-paper">Allow from this source</strong> /
            Install unknown apps.
            <p className="mt-3">
              If you dismissed the prompt: Settings → search{" "}
              <strong className="text-paper">unknown</strong> or{" "}
              <strong className="text-paper">special app access</strong> →
              Install unknown apps → choose the app that downloaded the APK →
              allow. Some OEMs nest this under Security, Privacy, or Biometrics
              and security.
            </p>
          </Step>
          <Step n="3" title="Open the APK and confirm">
            Return to Downloads or the notification and open the file. Review
            the app name and requested permissions, then Install. The
            bootstrapper is a small wrapper; the listed app may download after
            first launch if an update is available.
          </Step>
          <Step n="4" title="If install is still blocked">
            Play Protect, a work profile, a family/guardian account, or a
            company MDM policy can forbid sideloading. Those restrictions are
            outside this site. We cannot bypass them, and you should not try
            to disable security tools you do not control.
          </Step>
        </ol>

        <section className="mt-12 rounded-2xl border border-line bg-ink-2 p-5 text-sm leading-7 text-mute">
          <h2 className="font-display text-xl text-paper">Risks</h2>
          <p className="mt-3">
            Allowing unknown sources lets that browser or file app install
            software Google Play did not distribute. Keltri is not a
            Play Store replacement and does not provide Play Protect. Only
            install listings you trust; read the publisher name, description,
            and permissions. Report malware or illegal listings to{" "}
            <a href={abuseMailto} className="text-signal">
              {ABUSE_EMAIL}
            </a>
            .
          </p>
        </section>

        <p className="mt-10 text-sm text-mute">
          <Link to="/terms" className="text-signal">
            Terms
          </Link>
          {" · "}
          <Link to="/privacy" className="text-signal">
            Privacy
          </Link>
          {" · "}
          <a href={abuseMailto} className="text-signal">
            Abuse / report
          </a>
        </p>
      </main>
    </StoreShell>
  );
}

function Step({
  n,
  title,
  children,
}: {
  n: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <li className="flex gap-4">
      <span className="font-mono text-sm text-signal">{n}</span>
      <div>
        <h2 className="font-display text-xl">{title}</h2>
        <div className="mt-2 text-sm leading-7 text-mute">{children}</div>
      </div>
    </li>
  );
}
