import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { AppIcon, AppRail, StoreActions } from "../components/app-card";
import { StoreShell } from "../components/chrome";
import {
  fetchCatalog,
  fetchPublicApp,
  uniqueApps,
  type CatalogApp,
  type PublicApp,
} from "../lib/catalog";
import { useDocumentTitle } from "../lib/title";
import { NotFoundPage } from "./not-found";

export function StoreAppPage() {
  const { slug = "" } = useParams();
  const [app, setApp] = useState<PublicApp | null | undefined>(undefined);
  const [related, setRelated] = useState<CatalogApp[]>([]);

  useEffect(() => {
    setApp(undefined);
    Promise.all([fetchPublicApp(slug), fetchCatalog()]).then(
      ([listing, catalog]) => {
        setApp(listing);
        if (!catalog || !listing) {
          setRelated([]);
          return;
        }
        setRelated(
          uniqueApps(catalog).filter(
            (item) =>
              item.slug !== listing.slug &&
              (item.category === listing.category ||
                item.developer.slug === listing.developer.slug),
          ),
        );
      },
    );
  }, [slug]);

  useDocumentTitle(app ? `${app.name} — Keltri` : "Keltri");

  const similar = useMemo(
    () => related.filter((item) => item.category === app?.category),
    [related, app],
  );

  if (app === undefined) {
    return (
      <StoreShell>
        <main className="mx-auto max-w-3xl px-6 py-16 text-mute">Loading…</main>
      </StoreShell>
    );
  }
  if (!app) return <NotFoundPage />;

  return (
    <StoreShell>
      <main className="mx-auto max-w-3xl px-6 py-12">
        <div className="flex items-start gap-4">
          <AppIcon app={app} size="lg" />
          <div className="min-w-0 flex-1">
            <h1 className="font-display text-3xl">{app.name}</h1>
            <p className="mt-1 text-sm text-mute">
              <Link
                to={`/store/developer/${app.developer.slug}`}
                className="text-signal"
              >
                {app.developer.name}
              </Link>
              {app.category ? ` · ${app.category}` : null}
              {app.contentRating ? ` · ${app.contentRating}` : null}
            </p>
            <p className="mt-2 text-sm">
              ★ {app.rating} ({app.reviewCount.toLocaleString()}) ·{" "}
              {app.installs.toLocaleString()} installs
            </p>
            <div className="mt-5">
              <StoreActions app={app} size="md" />
            </div>
          </div>
        </div>

        <ScreenshotStrip app={app} />

        <p className="mt-8 text-lg">{app.shortDescription}</p>
        <p className="mt-3 text-sm leading-6 text-mute">{app.description}</p>

        {app.permissions.length ? (
          <p className="mt-4 text-xs text-mute">
            Try permissions: {app.permissions.join(", ")}
          </p>
        ) : null}

        <p className="mt-10 font-mono text-xs uppercase tracking-widest text-mute">
          What&apos;s new in v{app.versionName}
        </p>
        <pre className="mt-2 whitespace-pre-wrap font-sans text-sm text-mute">
          {app.releaseNotes ?? "No release notes."}
        </pre>

        <p className="mt-10 font-mono text-xs uppercase tracking-widest text-mute">
          Reviews
        </p>
        <ul className="mt-2 space-y-3 text-sm">
          {app.reviews.length ? (
            app.reviews.map((review) => (
              <li key={review.id} className="rounded-2xl border border-line bg-ink-2 p-4">
                {"★".repeat(review.rating)} {review.author}: {review.body}
              </li>
            ))
          ) : (
            <li className="text-mute">No reviews yet.</li>
          )}
        </ul>

        <AppRail title="Similar apps" apps={similar} />
      </main>
    </StoreShell>
  );
}

function ScreenshotStrip({ app }: { app: PublicApp }) {
  const shots = app.screenshots.length
    ? app.screenshots
    : [0, 1, 2].map((index) => ({ id: String(index), url: "" }));
  return (
    <div className="mt-8 flex gap-3 overflow-x-auto pb-2">
      {shots.map((shot, index) =>
        shot.url && /^https?:\/\//.test(shot.url) ? (
          <img
            key={shot.id}
            src={shot.url}
            alt=""
            className="h-64 w-36 shrink-0 rounded-2xl object-cover"
          />
        ) : (
          <div
            key={shot.id}
            className="flex h-64 w-36 shrink-0 flex-col justify-between rounded-2xl bg-ink-3 p-4"
          >
            <p className="font-display text-lg">{app.name}</p>
            <p className="text-xs uppercase tracking-widest text-mute">
              Screenshot {index + 1}
            </p>
          </div>
        ),
      )}
    </div>
  );
}
