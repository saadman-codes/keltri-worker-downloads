import { Link } from "react-router-dom";
import { useOrg } from "../lib/org-context";
import { deploymentPath, useProjects } from "../lib/platform";
import { GettingStarted, ProjectCard, Status } from "../components/platform";

export function WorkspaceOverviewPage() {
  const { developer, current } = useOrg();
  const { projects, error, reload } = useProjects();
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const recent = (projects ?? []).flatMap(project => project.services.flatMap(service => service.latestDeployment ? [{ project, service, deployment: service.latestDeployment }] : [])).sort((a, b) => b.deployment.createdAt.localeCompare(a.deployment.createdAt)).slice(0, 8);
  return <main className="px-8 py-10 lg:px-12">
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div><p className="mb-2 text-xs text-mute">{current?.name ?? "Personal workspace"}</p><h1 className="font-display text-3xl font-semibold">{greeting}{developer ? `, ${developer.name.split(" ")[0]}` : ""}</h1><p className="mt-2 text-sm text-mute">One place for everything you ship.</p></div>
      <Link to="/console/projects/new" className="rounded-lg bg-signal px-4 py-2.5 text-sm font-medium text-signal-ink">+ New Project</Link>
    </div>
    {error && <p role="alert" className="mt-6">{error} <button onClick={reload} className="underline">Retry</button></p>}
    {!projects && !error && <p role="status" className="mt-10 text-sm text-mute">Loading workspace…</p>}
    {projects?.length === 0 && <GettingStarted />}
    {!!projects?.length && <>
      <section className="mt-10"><div className="mb-4 flex items-center justify-between"><h2 className="font-semibold">Recent projects</h2><Link className="text-xs text-mute" to="/console/projects">View all →</Link></div><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{projects.slice(0, 6).map(p => <ProjectCard key={p.id} project={p} />)}</div></section>
      <section className="mt-10"><div className="mb-4 flex items-center justify-between"><h2 className="font-semibold">Latest deployment per service</h2><Link className="text-xs text-mute" to="/console/deployments">Full history →</Link></div><div className="rounded-xl border border-line bg-ink-2">{recent.map(({ project, service, deployment }) => <Link key={deployment.id} to={deploymentPath(project.id, service.id, deployment.id)} className="flex flex-wrap items-center justify-between gap-3 border-b border-line px-5 py-4 last:border-0 hover:bg-ink-3"><div><p className="text-sm font-medium">{project.name} <span className="text-mute">/ {service.name}</span></p><p className="mt-1 font-mono text-xs text-mute">{deployment.commitRef ?? deployment.id.slice(0, 8)}</p></div><Status value={deployment.status} /><span className="rounded-md border border-line px-2 py-1 text-xs capitalize">{deployment.environment}</span><time className="text-xs text-mute">{new Date(deployment.createdAt).toLocaleString()}</time></Link>)}{!recent.length && <p className="p-5 text-sm text-mute">Your first deployment will appear here.</p>}</div></section>
      <section className="mt-8 grid grid-cols-2 gap-4"><div className="rounded-xl border border-line bg-ink-2 p-5"><p className="text-xs text-mute">Projects</p><p className="mt-2 text-2xl font-semibold">{projects.length}</p></div><div className="rounded-xl border border-line bg-ink-2 p-5"><p className="text-xs text-mute">Services</p><p className="mt-2 text-2xl font-semibold">{projects.reduce((n, p) => n + p.services.length, 0)}</p></div></section>
    </>}
  </main>;
}
