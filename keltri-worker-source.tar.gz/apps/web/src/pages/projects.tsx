import { useState } from "react";
import { Link } from "react-router-dom";
import { useProjects } from "../lib/platform";
import { GettingStarted, ProjectCard } from "../components/platform";

export function ProjectsPage() {
  const { projects, error, reload } = useProjects();
  const [query, setQuery] = useState("");
  const [environment, setEnvironment] = useState("all");
  const filtered = projects?.filter(p => `${p.name} ${p.slug}`.toLowerCase().includes(query.toLowerCase()) && (environment === "all" || p.services.some(s => environment === "production" ? !!s.productionDeployment : s.latestDeployment?.environment === "preview")));
  return <main className="px-8 py-10 lg:px-12">
    <div className="flex items-center justify-between gap-4"><div><h1 className="font-display text-3xl font-semibold">Projects</h1><p className="mt-2 text-sm text-mute">Web, API, and mobile. One project for your whole product.</p></div><Link to="/console/projects/new" className="shrink-0 rounded-lg bg-signal px-4 py-2.5 text-sm font-medium text-signal-ink">+ New Project</Link></div>
    <div className="mt-8 flex flex-wrap gap-3"><input aria-label="Search projects" placeholder="Search projects…" value={query} onChange={e => setQuery(e.target.value)} className="min-w-0 flex-1 rounded-lg border border-line bg-ink-2 px-4 py-2.5 text-sm" /><select aria-label="Filter by environment" value={environment} onChange={e => setEnvironment(e.target.value)} className="rounded-lg border border-line bg-ink-2 px-3 py-2 text-sm"><option value="all">All environments</option><option value="production">Production</option><option value="preview">Preview</option></select></div>
    {error && <p role="alert" className="mt-6">{error} <button onClick={reload} className="underline">Retry</button></p>}
    {!projects && !error && <p role="status" className="mt-8 text-sm text-mute">Loading projects…</p>}
    {projects?.length === 0 ? <GettingStarted /> : <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{filtered?.map(p => <ProjectCard key={p.id} project={p} />)}</div>}
    {!!projects?.length && filtered?.length === 0 && <p className="mt-10 text-center text-sm text-mute">No projects match your search and environment.</p>}
  </main>;
}
