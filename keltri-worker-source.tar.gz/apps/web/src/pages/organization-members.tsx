import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../lib/api";

type Member = {
  id: string;
  role: "owner" | "member";
  developer: { id: string; name: string; email: string; slug: string };
};

type Organization = {
  id: string;
  name: string;
  slug: string;
  plan: string;
  role: "owner" | "member";
};

export function OrganizationMembersPage() {
  const { id = "" } = useParams();
  const [org, setOrg] = useState<Organization | null>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  function reload() {
    api.organizations
      .get(id)
      .then((value) => setOrg(value as Organization))
      .catch((err: Error) => setError(err.message));
    api.organizations.members
      .list(id)
      .then((value) => setMembers(value as Member[]))
      .catch(() => {});
  }

  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  if (!org) {
    return (
      <main className="px-8 py-8">
        {error ? <p className="text-sm text-ember">{error}</p> : null}
      </main>
    );
  }

  const isOwner = org.role === "owner";

  return (
    <main className="px-8 py-8">
      <p className="font-mono text-[11px] uppercase tracking-widest text-mute">
        organization
      </p>
      <h1 className="font-display mt-1 text-3xl font-semibold">{org.name}</h1>

      {!isOwner ? (
        <p className="mt-4 rounded-xl border border-line bg-ink-2 p-3 text-sm text-mute">
          You're a member of this organization. Only owners can invite or
          remove members.
        </p>
      ) : null}

      <table className="mt-8 w-full text-left text-sm">
        <thead className="font-mono text-[11px] uppercase tracking-widest text-mute">
          <tr>
            <th className="py-2">Name</th>
            <th>Email</th>
            <th>Role</th>
            {isOwner ? <th /> : null}
          </tr>
        </thead>
        <tbody>
          {members.map((member) => (
            <tr key={member.id} className="border-t border-line">
              <td className="py-3">{member.developer.name}</td>
              <td className="text-xs text-mute">{member.developer.email}</td>
              <td className="font-mono text-[11px] uppercase text-mute">
                {member.role}
              </td>
              {isOwner ? (
                <td className="text-right">
                  <button
                    type="button"
                    onClick={async () => {
                      await api.organizations.members.remove(id, member.id);
                      reload();
                    }}
                    className="text-mute hover:text-paper"
                  >
                    Remove
                  </button>
                </td>
              ) : null}
            </tr>
          ))}
        </tbody>
      </table>

      {isOwner ? (
        <form
          className="mt-6 flex flex-wrap gap-2"
          onSubmit={async (event) => {
            event.preventDefault();
            setError("");
            try {
              await api.organizations.members.invite(id, { email });
              setEmail("");
              reload();
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not invite");
            }
          }}
        >
          <input
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="teammate@example.com"
            className="min-w-0 flex-1 rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
            required
          />
          <button
            type="submit"
            className="rounded-full border border-line px-4 py-2 text-sm"
          >
            Invite
          </button>
        </form>
      ) : null}
      {error ? <p className="mt-3 text-sm text-ember">{error}</p> : null}
    </main>
  );
}
