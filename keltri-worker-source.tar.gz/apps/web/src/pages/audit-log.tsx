import { useEffect, useState } from "react";
import { api } from "../lib/api";

type AuditEntry = {
  id: string;
  action: string;
  targetType: string;
  targetId: string | null;
  metadata: Record<string, unknown> | null;
  createdAt: string;
};

type AuditPage = {
  items: AuditEntry[];
  page: number;
  pageSize: number;
  total: number;
};

export function AuditLogPage() {
  const [data, setData] = useState<AuditPage | null>(null);
  const [page, setPage] = useState(1);
  const [error, setError] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    api.auditLog
      .list({ page })
      .then((value) => setData(value as AuditPage))
      .catch((err: Error) => setError(err.message));
  }, [page]);

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.pageSize)) : 1;

  return (
    <main className="px-8 py-8">
      <h1 className="font-display text-3xl font-semibold">Audit log</h1>
      <p className="mt-2 max-w-xl text-sm text-mute">
        Deploys, promotes, rollbacks, env var changes, API key and webhook
        management, and project creation. Read-only, append-only — covers
        this hosting surface, not the Android surface yet.
      </p>
      {error ? <p className="mt-4 text-sm text-ember">{error}</p> : null}
      <table className="mt-8 w-full text-left text-sm">
        <thead className="font-mono text-[11px] uppercase tracking-widest text-mute">
          <tr>
            <th className="py-2">Action</th>
            <th>Target</th>
            <th>When</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {(data?.items ?? []).map((entry) => (
            <tr key={entry.id} className="border-t border-line align-top">
              <td className="py-3 font-mono text-xs">{entry.action}</td>
              <td className="font-mono text-xs text-mute">
                {entry.targetType}
                {entry.targetId ? `:${entry.targetId.slice(0, 8)}` : ""}
              </td>
              <td className="text-xs text-mute">
                {new Date(entry.createdAt).toLocaleString()}
              </td>
              <td className="text-right">
                {entry.metadata ? (
                  <button
                    type="button"
                    className="text-xs text-signal"
                    onClick={() =>
                      setExpanded(expanded === entry.id ? null : entry.id)
                    }
                  >
                    {expanded === entry.id ? "Hide" : "Details"}
                  </button>
                ) : null}
                {expanded === entry.id ? (
                  <pre className="mt-2 max-w-xs overflow-auto rounded-lg bg-ink-2 p-2 text-left font-mono text-[11px]">
                    {JSON.stringify(entry.metadata, null, 2)}
                  </pre>
                ) : null}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {data ? (
        <div className="mt-6 flex items-center gap-4 text-sm text-mute">
          <button
            type="button"
            disabled={page <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="disabled:opacity-40"
          >
            Previous
          </button>
          <span>
            Page {data.page} of {totalPages}
          </span>
          <button
            type="button"
            disabled={page >= totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="disabled:opacity-40"
          >
            Next
          </button>
        </div>
      ) : null}
    </main>
  );
}
