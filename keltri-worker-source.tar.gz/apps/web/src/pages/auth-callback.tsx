import { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { setSession } from "../lib/session";

export function AuthCallbackPage() {
  const navigate = useNavigate();
  const [params] = useSearchParams();

  useEffect(() => {
    const token = params.get("token");
    if (!token) {
      navigate("/console/login?error=github", { replace: true });
      return;
    }
    setSession(token);
    navigate("/console", { replace: true });
  }, [params, navigate]);

  return (
    <main className="grid min-h-screen place-items-center text-mute">
      Signing you in…
    </main>
  );
}
