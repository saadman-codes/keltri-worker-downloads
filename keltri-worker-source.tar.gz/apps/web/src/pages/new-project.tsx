import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { useOrg } from "../lib/org-context";
import { GitRepositoryPicker, type ImportRepository } from "../components/git-repository-picker";

export function NewProjectPage() {
  const navigate = useNavigate();
  const { developer, organizations, current } = useOrg();
  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [ownerScope, setOwnerScope] = useState<string | null | undefined>(undefined);
  const selectedOwner = ownerScope === undefined ? current?.id ?? null : ownerScope;
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [repository, setRepository] = useState<{ owner: string | null; repo: ImportRepository } | null>(null);
  const selectedRepository = repository?.owner === selectedOwner ? repository.repo : null;
  const nameInput = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (selectedRepository) nameInput.current?.focus();
  }, [selectedRepository]);

  return (
    <main className="mx-auto max-w-2xl px-8 py-12">
      <Link to="/console/projects" className="mb-5 inline-block text-xs text-mute">← Projects</Link>
      <h1 className="font-display text-3xl font-semibold">Create a project</h1>
      <p className="mt-2 text-sm text-mute">
        Import a GitHub repository to create your project, then configure its service.
      </p>
      <form
        className="mt-8 space-y-4"
        onSubmit={async (event) => {
          event.preventDefault();
          if (busy) return;
          if (!selectedRepository) return;
          setBusy(true);
          setError("");
          try {
            const project = (await api.projects.create({
              name,
              slug,
              organizationId: selectedOwner ?? undefined,
            })) as { id: string };
            const query = new URLSearchParams({ method: "git" });
            if (selectedRepository) {
              query.set("repository", String(selectedRepository.id));
              query.set("installation", selectedRepository.installationId);
            }
            navigate(`/console/projects/${project.id}/services/new?${query}`);
          } catch (err) {
            setError(err instanceof Error ? err.message : "Could not create project");
          } finally {
            setBusy(false);
          }
        }}
      >
        {organizations.length > 0 ? (
          <fieldset className="block text-sm text-mute">
            Workspace
            <div className="mt-2 grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setOwnerScope(null)}
                className={`rounded-xl border px-3 py-3 text-left text-sm ${
                  selectedOwner === null ? "border-signal text-signal" : "border-line text-paper"
                }`}
              >
                <span className="font-display block">Personal</span>
                <span className="text-xs text-mute">
                  {developer ? `${developer.name}'s projects` : "Just you"}
                </span>
              </button>
              {organizations.map((org) => (
                <button
                  key={org.id}
                  type="button"
                  onClick={() => setOwnerScope(org.id)}
                  className={`rounded-xl border px-3 py-3 text-left text-sm ${
                    selectedOwner === org.id ? "border-signal text-signal" : "border-line text-paper"
                  }`}
                >
                  <span className="font-display block">{org.name}</span>
                  <span className="text-xs text-mute">Workspace</span>
                </button>
              ))}
            </div>
          </fieldset>
        ) : null}
        {!selectedRepository && <GitRepositoryPicker key={selectedOwner ?? "personal"} target={selectedOwner ? { organizationId: selectedOwner } : {}} onSelect={repo => {
          setError("");
          setRepository({ owner: selectedOwner, repo });
          setName(repo.name);
          setSlug(repo.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""));
        }} />}
        {selectedRepository && <div className="rounded-xl border border-line p-4 text-sm"><span className="font-medium">{selectedRepository.fullName}</span><button type="button" className="ml-4 text-signal" onClick={() => setRepository(null)}>Change repository</button></div>}
        {selectedRepository && <>
        <h2 className="text-lg font-semibold">Configure your project</h2>
        <label className="block text-sm text-mute">
          Name
          <input
            ref={nameInput}
            value={name}
            onChange={(event) => {
              setName(event.target.value);
              setSlug(event.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""));
            }}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
            required
            minLength={2}
          />
        </label>
        <label className="block text-sm text-mute">
          Slug
          <input
            value={slug}
            pattern="[a-z0-9-]+"
            onChange={(event) => setSlug(event.target.value)}
            className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono"
            required
            minLength={2}
          />
        </label>
        {error ? <p className="text-sm text-ember">{error}</p> : null}
        <button
          type="submit"
          disabled={busy}
          className="rounded-full bg-signal px-5 py-3 font-semibold text-signal-ink"
        >
          {busy ? "Creating…" : "Continue to service"}
        </button>
        </>}
      </form>
    </main>
  );
}
