import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { api } from "../lib/api";
import { GitHubConnection } from "../components/github-connection";
import type { GitStatus } from "@quantum/api-client";

type ServiceType = "web" | "backend" | "android" | "worker" | "desktop";
type Card = "git";

type Repo = {
  id: number;
  name: string;
  fullName: string;
  defaultBranch: string;
  private: boolean;
  updatedAt: string;
  installationId: string;
};

const SERVICE_TYPES: Array<{ value: ServiceType; label: string; note: string; available: boolean }> = [
  { value: "web", label: "Web", note: "Frontend / static site — push a build, get a preview", available: true },
  { value: "backend", label: "Backend", note: "API / server — records deployments only, for now", available: true },
  { value: "android", label: "Android", note: "Coming soon", available: false },
  { value: "worker", label: "Worker", note: "Coming soon", available: false },
  { value: "desktop", label: "Desktop", note: "Coming soon", available: false },
];

export function AddServicePage() {
  const { id = "" } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();

  const initialMethod = params.get("method");
  const [card, setCard] = useState<Card | null>(initialMethod === "git" ? "git" : null);
  const [githubStatus, setGithubStatus] = useState<GitStatus | null>(null);
  const githubConnected = !!githubStatus?.installations.some(i => !i.suspended);
  const [connectionVersion, setConnectionVersion] = useState(0);
  const [repos, setRepos] = useState<Repo[] | null>(null);
  const [repoQuery, setRepoQuery] = useState("");
  const [selectedRepo, setSelectedRepo] = useState<Repo | null>(null);
  const [gitLink, setGitLink] = useState<{ repoFullName: string; defaultBranch: string; installationId: string; repositoryId: string } | null>(null);

  const [name, setName] = useState("");
  const [slug, setSlug] = useState("");
  const [type, setType] = useState<ServiceType>("web");
  const [buildCommand, setBuildCommand] = useState("npm run build");
  const [outputDir, setOutputDir] = useState("dist");
  const [rootDir, setRootDir] = useState(".");
  const [startCommand, setStartCommand] = useState("npm start");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [framework, setFramework] = useState("");
  const [createdServiceId, setCreatedServiceId] = useState<string | null>(null);
  const imported = useRef(false);

  useEffect(() => {
    if (imported.current || !repos) return;
    const repositoryId = params.get("repository");
    const installationId = params.get("installation");
    if (!repositoryId || !installationId) return;
    imported.current = true;
    const repo = repos.find(value => String(value.id) === repositoryId && value.installationId === installationId);
    if (repo) void selectRepo(repo);
    else setError("That repository is no longer available. Choose another repository or refresh GitHub access.");
  }, [repos, params]);

  useEffect(() => {
    if (params.get("git") === "connected") {
      // Connection status is verified by the API, not the query string.
      setCard("git");
    }
    if (params.get("git") === "error") {
      setCard("git");
      setError("GitHub connection did not complete. Please try connecting again.");
    }
  }, [params]);

  useEffect(() => {
    if (card === "git" && githubConnected) loadRepos();
  }, [card, githubConnected, connectionVersion, githubStatus]);

  function loadRepos() {
    setRepos(null);
    api.git
      .repos({ projectId: id })
      .then((value) => setRepos(value as Repo[]))
      .catch((err: Error) => { setRepos([]); setError(err.message); });
  }

  async function selectRepo(repo: Repo) {
    setDetecting(true);
    setSelectedRepo(null);
    setGitLink(null);
    setError("");
    try {
      const detected = await api.git.detect(repo.installationId, String(repo.id), { projectId: id });
      setName(repo.name);
      setSlug(repo.name.toLowerCase().replace(/[^a-z0-9]+/g, "-"));
      setType("web");
      setBuildCommand(detected.buildCommand ?? "npm run build");
      setOutputDir(detected.outputDir ?? "dist");
      if (detected.startCommand) setStartCommand(detected.startCommand);
      setGitLink({ repoFullName: repo.fullName, defaultBranch: detected.defaultBranch, installationId: repo.installationId, repositoryId: String(repo.id) });
      setFramework(detected.detectedFramework);
      setSelectedRepo(repo);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not read that repository");
    } finally {
      setDetecting(false);
    }
  }

  function pickCard(next: Card) {
    setCard(next);
    setError("");
  }

  const filteredRepos = (repos ?? []).filter((repo) =>
    repo.fullName.toLowerCase().includes(repoQuery.toLowerCase()),
  );

  async function createService(event: React.FormEvent) {
    event.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const service = createdServiceId ? { id: createdServiceId } : (await api.projects.services.create(id, {
        slug,
        name,
        type,
        rootDir,
        buildCommand: type === "web" ? buildCommand : undefined,
        startCommand: type === "backend" ? startCommand : undefined,
        outputDir: type === "web" ? outputDir : undefined,
      })) as { id: string };
      setCreatedServiceId(service.id);
      if (gitLink) {
        await api.projects.services.gitLink(id, service.id, gitLink);
      }
      navigate(`/console/projects/${id}/services/${service.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create service");
    } finally {
      setBusy(false);
    }
  }

  const showConfig = card === "git" && selectedRepo;

  return (
    <main className="mx-auto max-w-lg px-8 py-12">
      <h1 className="font-display text-3xl font-semibold">Add a service</h1>
      <p className="mt-2 text-sm text-mute">
        A service is one deployable surface inside this project — a website, an API, or
        (soon) a mobile or desktop app.
      </p>

      {!card ? (
        <div className="mt-8 grid grid-cols-1 gap-3">
          <button
            type="button"
            onClick={() => pickCard("git")}
            className="rounded-xl border border-line p-4 text-left hover:bg-ink-2"
          >
            <span className="font-display block">◇ Import Git Repository</span>
            <span className="text-xs text-mute">GitHub — real repo browsing + framework detection</span>
          </button>
        </div>
      ) : null}

      {card === "git" && !selectedRepo ? (
        <div className="mt-8">
          <button type="button" onClick={() => setCard(null)} className="text-xs text-mute hover:text-paper">
            ← Back
          </button>
          <GitHubConnection compact target={{ projectId: id }} returnTo={`/console/projects/${id}/services/new`} onStatus={setGithubStatus} onDisconnect={() => { setGithubStatus(null); setSelectedRepo(null); setGitLink(null); setRepos(null); setConnectionVersion(v => v + 1); }} />
          {!githubConnected ? null : (
            <div className="mt-4">
              <input
                value={repoQuery}
                onChange={(event) => setRepoQuery(event.target.value)}
                placeholder="Find a repository…"
                className="w-full rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
              />
              <div className="mt-3 max-h-80 space-y-1 overflow-auto">
                {repos === null ? (
                  <p className="text-sm text-mute">Loading repositories…</p>
                ) : filteredRepos.length === 0 ? (
                  <p className="text-sm text-mute">No repositories found.</p>
                ) : (
                  filteredRepos.map((repo) => (
                    <button
                      key={repo.id}
                      type="button"
                      disabled={detecting}
                      onClick={() => selectRepo(repo)}
                      className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm hover:bg-ink-2"
                    >
                      <span className="font-mono">{repo.fullName}</span>
                      <span className="text-xs text-mute">{repo.private ? "Private" : "Public"}</span>
                    </button>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      ) : null}

      {detecting && <p role="status" className="mt-4 text-sm text-mute">Detecting framework…</p>}
      {error && <p role="alert" className="mt-4 text-sm text-ember">{error}</p>}

      {showConfig ? (
        <form className="mt-8 space-y-4" onSubmit={createService}>
          {framework && <div className="rounded-xl border border-line bg-ink-2 p-4 text-sm"><p className="font-medium">{framework === "unknown" ? "Custom framework" : `${framework} detected`}</p><p className="mt-1 text-xs text-mute">Keltri builds and hosts static websites. Server-rendered frameworks require a static export. Detection uses the repository root; review settings for monorepos.</p></div>}
          {createdServiceId && <p className="text-sm text-mute">Service created. Retry to finish linking the repository.</p>}
          {card === "git" && selectedRepo ? (
            <p className="text-xs text-mute">
              Detected from <span className="font-mono text-paper">{selectedRepo.fullName}</span> — all
              fields below are editable before you create the service.
            </p>
          ) : null}
          <label className="block text-sm text-mute">
            Name
            <input
              value={name}
              onChange={(event) => {
                setName(event.target.value);
                setSlug(event.target.value.toLowerCase().replace(/[^a-z0-9]+/g, "-"));
              }}
              className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
              required
              minLength={2}
            />
          </label>
          <label className="block text-sm text-mute">
            Slug
            <input
              value={slug}
              onChange={(event) => setSlug(event.target.value)}
              className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono"
              required
              minLength={2}
            />
          </label>
          <fieldset className="block text-sm text-mute">
            Type
            <div className="mt-2 grid grid-cols-2 gap-3">
              {SERVICE_TYPES.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  disabled={!option.available}
                  onClick={() => option.available && setType(option.value)}
                  className={`rounded-xl border px-3 py-3 text-left text-sm ${
                    !option.available
                      ? "cursor-not-allowed border-line text-mute opacity-50"
                      : type === option.value
                        ? "border-signal text-signal"
                        : "border-line text-paper"
                  }`}
                >
                  <span className="font-display block">{option.label}</span>
                  <span className="text-xs text-mute">{option.note}</span>
                </button>
              ))}
            </div>
          </fieldset>
          {type === "web" ? (
            <>
              <label className="block text-sm text-mute">Root directory
                <input required value={rootDir} onChange={event => setRootDir(event.target.value)} className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono" />
                <span className="mt-1 block text-xs">Use . for the repository root, or a folder such as apps/web. Build and output paths are relative to this directory.</span>
              </label>
              <label className="block text-sm text-mute">
                Build command
                <input
                  value={buildCommand}
                  onChange={(event) => setBuildCommand(event.target.value)}
                  className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono"
                />
              </label>
              <label className="block text-sm text-mute">
                Output directory
                <input
                  value={outputDir}
                  onChange={(event) => setOutputDir(event.target.value)}
                  className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono"
                />
              </label>
            </>
          ) : (
            <label className="block text-sm text-mute">
              Start command
              <input
                value={startCommand}
                onChange={(event) => setStartCommand(event.target.value)}
                className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2 font-mono"
              />
            </label>
          )}
          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={busy}
              className="rounded-full bg-signal px-5 py-3 font-semibold text-signal-ink"
            >
              {busy ? "Creating…" : createdServiceId ? "Retry repository link" : "Create service"}
            </button>
            <button
              type="button"
              disabled={busy || !!createdServiceId}
              onClick={() => {
                setCard(null);
                setSelectedRepo(null);
                setGitLink(null);
              }}
              className="text-sm text-mute hover:text-paper"
            >
              Start over
            </button>
          </div>
        </form>
      ) : null}
    </main>
  );
}
