import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api } from "../lib/api";
import { DeploymentList } from "./deployments";
import { DomainList } from "./domains";
import { productionUrl, type Project, type Service } from "../lib/platform";
import { Status } from "../components/platform";
import { NotFoundPage } from "./not-found";

type TeamMember = {
  id: string;
  role: string;
  developer: { id: string; name: string; email: string; slug: string };
};

const SERVICE_ICON: Record<Service["type"], string> = {
  web: "◇",
  backend: "<>",
  android: "◉",
  worker: "⚙",
  desktop: "🖥",
};

export function ProjectOverviewPage() {
  const { id = "", section = "overview" } = useParams();
  const [project, setProject] = useState<Project | null>(null);
  const [error, setError] = useState("");
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [inviteEmail, setInviteEmail] = useState("");
  const [teamError, setTeamError] = useState("");

  function reload() {
    api.projects
      .get(id)
      .then((value) => setProject(value as Project))
      .catch((err: Error) => setError(err.message));
  }

  function reloadTeam() {
    api.projects.team
      .list(id)
      .then((value) => setTeam(value as TeamMember[]))
      .catch(() => {});
  }

  useEffect(() => {
    setProject(null);
    setError("");
    reload();
    reloadTeam();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function invite(event: React.FormEvent) {
    event.preventDefault();
    setTeamError("");
    try {
      await api.projects.team.invite(id, { email: inviteEmail });
      setInviteEmail("");
      reloadTeam();
    } catch (err) {
      setTeamError(err instanceof Error ? err.message : "Could not invite");
    }
  }

  async function removeMember(memberId: string) {
    try {
      await api.projects.team.remove(id, memberId);
      reloadTeam();
    } catch (err) {
      setTeamError(err instanceof Error ? err.message : "Could not remove member");
    }
  }

  if (!project) {
    return (
      <main className="px-8 py-8">
        {error ? <p role="alert" className="text-sm text-ember">{error}</p> : <p role="status">Loading project…</p>}
      </main>
    );
  }

  if (!["overview", "services", "deployments", "domains", "settings"].includes(section)) return <NotFoundPage />;
  return (
    <main className="px-8 py-8">
      <Link to="/console/projects" className="text-xs text-mute hover:text-paper">
        ← Projects
      </Link>
      <div className="mt-2 flex items-start justify-between">
        <h1 className="font-display text-3xl font-semibold">{project.name}</h1>
        <Link
          to={`/console/projects/${id}/services/new`}
          className="rounded-full border border-line px-4 py-2 text-sm"
        >
          + Add service
        </Link>
      </div>

      <nav aria-label="Project" className="mt-7 flex gap-5 overflow-auto border-b border-line text-sm">
        {["overview", "deployments", "services", "domains", "settings"].map(tab => <Link key={tab} to={`/console/projects/${id}${tab === "overview" ? "" : `/${tab}`}`} aria-current={section === tab ? "page" : undefined} className={`border-b-2 pb-3 capitalize ${section === tab ? "border-signal text-signal" : "border-transparent text-mute"}`}>{tab}</Link>)}
      </nav>
      {section === "deployments" && <DeploymentList projects={[project]} />}
      {section === "domains" && <DomainList projects={[project]} />}
      {section === "overview" && <section className="mt-8 rounded-xl border border-line bg-ink-2 p-6"><h2 className="font-semibold">Production</h2><p className="mt-1 text-sm text-mute">Live deployments across this project’s services.</p>{project.services.filter(s => s.productionDeployment).map(s => <div key={s.id} className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-line pt-4"><div><p className="text-sm font-medium">{s.name}</p><p className="mt-1 font-mono text-xs text-mute">{s.productionDeployment?.commitRef ?? s.productionDeployment?.id.slice(0, 8)}</p></div><Status value={s.productionDeployment!.status} />{s.type === "web" && <a href={productionUrl(project.slug, s.slug)} target="_blank" rel="noreferrer" className="text-sm text-signal">Visit ↗</a>}</div>)}{!project.services.some(s => s.productionDeployment) && <p className="mt-5 text-sm text-mute">No production deployment yet. Deploy a preview, then promote it when you’re ready.</p>}</section>}
      {(section === "overview" || section === "services") && <section className="mt-8">
        <h2 className="font-display text-xl">Services</h2>
        {project.services.length === 0 ? (
          <p className="mt-3 rounded-2xl border border-dashed border-line bg-ink-2 p-6 text-sm text-mute">
            No services yet.{" "}
            <Link to={`/console/projects/${id}/services/new`} className="text-signal">
              Add one
            </Link>{" "}
            to start deploying.
          </p>
        ) : (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {project.services.map((service) => (
              <Link
                key={service.id}
                to={`/console/projects/${id}/services/${service.id}`}
                className="block rounded-2xl border border-line p-5 hover:bg-ink-2"
              >
                <p className="text-lg">{SERVICE_ICON[service.type as Service["type"]] ?? "◇"}</p>
                <p className="font-display mt-2 font-semibold">{service.name}</p>
                <p className="mt-1 font-mono text-[11px] uppercase tracking-widest text-mute">
                  {service.type}
                </p>
                {service.latestDeployment ? (
                  <p className="mt-2 text-xs text-mute">
                    {service.latestDeployment.environment} ·{" "}
                    {service.latestDeployment.status}
                  </p>
                ) : (
                  <p className="mt-2 text-xs text-mute">No deployments yet</p>
                )}
              </Link>
            ))}
          </div>
        )}
      </section>}

      {section === "settings" && project.isOwner ? (
        <section className="mt-8 rounded-2xl border border-line p-5">
          <h2 className="font-display text-xl">Team</h2>
          <p className="mt-1 text-sm text-mute">
            Invite an already-registered developer to view this project across all its
            services. They aren't notified — share the link yourself. They can see
            deployments but can't deploy, edit settings, or roll back.
          </p>
          {team.length > 0 ? (
            <table className="mt-4 w-full text-left text-sm">
              <tbody>
                {team.map((member) => (
                  <tr key={member.id} className="border-t border-line">
                    <td className="py-2">{member.developer.name}</td>
                    <td className="text-xs text-mute">{member.developer.email}</td>
                    <td className="text-right">
                      <button
                        type="button"
                        onClick={() => removeMember(member.id)}
                        className="text-mute hover:text-paper"
                      >
                        Remove
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}
          <form className="mt-4 flex flex-wrap gap-2" onSubmit={invite}>
            <input
              type="email"
              value={inviteEmail}
              onChange={(event) => setInviteEmail(event.target.value)}
              placeholder="teammate@example.com"
              className="min-w-0 flex-1 rounded-xl border border-line bg-ink-2 px-3 py-2 text-sm"
              required
            />
            <button type="submit" className="rounded-full border border-line px-4 py-2 text-sm">
              Invite
            </button>
          </form>
          {teamError ? <p className="mt-3 text-sm text-ember">{teamError}</p> : null}
        </section>
      ) : null}
      {section === "settings" && !project.isOwner && <p className="mt-6 text-sm text-mute">Project settings are managed by the owner.</p>}
    </main>
  );
}
