import { StoreShell } from "../components/chrome";

export function NotFoundPage() {
  return (
    <StoreShell>
      <main className="mx-auto max-w-lg px-6 py-24 text-center">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">
          404
        </p>
        <h1 className="font-display mt-3 text-4xl font-extrabold">
          Page not found
        </h1>
        <p className="mt-4 text-mute">That route is not in this React app.</p>
        <a
          href="/"
          className="mt-8 inline-flex rounded-full bg-signal px-5 py-3 text-sm font-semibold text-signal-ink"
        >
          Back home
        </a>
      </main>
    </StoreShell>
  );
}
