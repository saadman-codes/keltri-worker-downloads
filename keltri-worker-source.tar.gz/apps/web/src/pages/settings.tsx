import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { useOrg } from "../lib/org-context";
import { GitHubConnection } from "../components/github-connection";

type Key = {
  id: string;
  name: string;
  prefix: string;
  lastUsedAt: string | null;
  createdAt: string;
  token?: string;
};

type Webhook = {
  id: string;
  url: string;
  events: string[];
  secret: string;
  createdAt: string;
};

const WEBHOOK_EVENTS = [
  "deployment.created",
  "deployment.failed",
  "deployment.promoted",
  "version.published",
  "version.rolled_back",
  "review.approved",
  "review.rejected",
  "listing.unpublished",
];

export function SettingsPage() {
  const [keys, setKeys] = useState<Key[]>([]);
  const [name, setName] = useState("CLI");
  const [secret, setSecret] = useState("");
  const [error, setError] = useState("");

  const [webhooksList, setWebhooksList] = useState<Webhook[]>([]);
  const [hookUrl, setHookUrl] = useState("");
  const [hookEvents, setHookEvents] = useState<string[]>([]);
  const [hookError, setHookError] = useState("");

  const { current } = useOrg();

  function reload() {
    api.apiKeys
      .list()
      .then((value) => setKeys(value as Key[]))
      .catch((err: Error) => setError(err.message));
  }

  function reloadWebhooks() {
    api.webhooks
      .list()
      .then((value) => setWebhooksList(value as Webhook[]))
      .catch((err: Error) => setHookError(err.message));
  }

  useEffect(() => {
    reload();
    reloadWebhooks();

  }, []);

  function toggleEvent(event: string) {
    setHookEvents((current) =>
      current.includes(event)
        ? current.filter((item) => item !== event)
        : [...current, event],
    );
  }

  return (
    <main className="px-8 py-8">
      <h1 className="font-display text-3xl font-semibold">API keys</h1>
      <p className="mt-2 max-w-xl text-sm text-mute">
        Session cookies sign you into the portal. CLI and CI use API keys:
        export <span className="font-mono text-paper">KELTRI_API_KEY</span> and
        run <span className="font-mono text-paper">keltri login</span>.
      </p>
      <form
        className="mt-8 flex flex-wrap items-end gap-3"
        onSubmit={async (event) => {
          event.preventDefault();
          const created = (await api.apiKeys.create(name)) as Key;
          setSecret(created.token ?? "");
          reload();
        }}
      >
        <label className="text-sm text-mute">
          Name
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            className="mt-2 block rounded-xl border border-line bg-ink-2 px-3 py-2"
          />
        </label>
        <button
          type="submit"
          className="rounded-full bg-signal px-4 py-2 text-sm font-semibold text-signal-ink"
        >
          Create key
        </button>
      </form>
      {secret ? (
        <p className="mt-4 rounded-xl border border-signal/40 bg-ink-2 p-4 font-mono text-sm">
          Copy now — shown once: {secret}
        </p>
      ) : null}
      {error ? <p className="mt-4 text-sm text-ember">{error}</p> : null}
      <table className="mt-10 w-full text-left text-sm">
        <thead className="font-mono text-[11px] uppercase tracking-widest text-mute">
          <tr>
            <th className="py-2">Name</th>
            <th>Prefix</th>
            <th>Last used</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {keys.map((key) => (
            <tr key={key.id} className="border-t border-line">
              <td className="py-3">{key.name}</td>
              <td className="font-mono">{key.prefix}…</td>
              <td>
                {key.lastUsedAt
                  ? new Date(key.lastUsedAt).toLocaleString()
                  : "Never"}
              </td>
              <td>
                <button
                  type="button"
                  className="text-xs text-ember"
                  onClick={async () => {
                    await api.apiKeys.revoke(key.id);
                    reload();
                  }}
                >
                  Revoke
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 className="font-display mt-14 text-2xl font-semibold">Webhooks</h2>
      <p className="mt-2 max-w-xl text-sm text-mute">
        Get a signed POST when things happen on your account. Leave events
        unchecked to subscribe to everything. Verify deliveries with{" "}
        <span className="font-mono text-paper">X-Keltri-Signature</span>, an
        HMAC-SHA256 of the body using the secret shown below.
      </p>
      <form
        className="mt-6 max-w-xl"
        onSubmit={async (event) => {
          event.preventDefault();
          setHookError("");
          try {
            await api.webhooks.create({ url: hookUrl, events: hookEvents });
            setHookUrl("");
            setHookEvents([]);
            reloadWebhooks();
          } catch (err) {
            setHookError(
              err instanceof Error ? err.message : "Could not add webhook",
            );
          }
        }}
      >
        <label className="block text-sm text-mute">
          URL
          <input
            value={hookUrl}
            onChange={(event) => setHookUrl(event.target.value)}
            placeholder="https://example.com/webhooks/keltri"
            className="mt-2 block w-full rounded-xl border border-line bg-ink-2 px-3 py-2"
            required
          />
        </label>
        <div className="mt-3 flex flex-wrap gap-3 text-xs text-mute">
          {WEBHOOK_EVENTS.map((event) => (
            <label key={event} className="flex items-center gap-1.5">
              <input
                type="checkbox"
                checked={hookEvents.includes(event)}
                onChange={() => toggleEvent(event)}
              />
              <span className="font-mono">{event}</span>
            </label>
          ))}
        </div>
        <button
          type="submit"
          className="mt-4 rounded-full bg-signal px-4 py-2 text-sm font-semibold text-signal-ink"
        >
          Add webhook
        </button>
      </form>
      {hookError ? (
        <p className="mt-4 text-sm text-ember">{hookError}</p>
      ) : null}
      <table className="mt-8 w-full text-left text-sm">
        <thead className="font-mono text-[11px] uppercase tracking-widest text-mute">
          <tr>
            <th className="py-2">URL</th>
            <th>Events</th>
            <th>Secret</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {webhooksList.map((hook) => (
            <tr key={hook.id} className="border-t border-line">
              <td className="py-3 font-mono text-xs">{hook.url}</td>
              <td className="font-mono text-xs text-mute">
                {hook.events.length > 0 ? hook.events.join(", ") : "all"}
              </td>
              <td className="font-mono text-xs text-mute">{hook.secret}</td>
              <td>
                <button
                  type="button"
                  className="text-xs text-ember"
                  onClick={async () => {
                    await api.webhooks.delete(hook.id);
                    reloadWebhooks();
                  }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 className="font-display mt-14 text-2xl font-semibold">Workspace Git connection</h2>
      <GitHubConnection target={current ? { organizationId: current.id } : {}} returnTo="/console/settings" />
    </main>
  );
}
