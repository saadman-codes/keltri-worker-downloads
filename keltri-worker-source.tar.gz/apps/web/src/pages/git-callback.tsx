import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { api } from "../lib/api";
import { githubFlowKey, gitErrorMessage, startGitHubConnection } from "../lib/github-connect";
import { useOrg } from "../lib/org-context";

export function GitCallbackPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { selectWorkspace } = useOrg();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [choices, setChoices] = useState<Array<{ installationId: string; accountLogin: string; accountType: string }>>([]);
  const [returnTo, setReturnTo] = useState("/console/projects/new");
  const [organizationId, setOrganizationId] = useState<string | null>(null);
  const started = useRef(false);
  const completed = useRef<Awaited<ReturnType<typeof api.git.complete>> | null>(null);

  async function complete(installationId?: string) {
    setBusy(true); setError("");
    try {
      const flowId = params.get("flow");
      const code = params.get("code");
      const clientProof = flowId ? sessionStorage.getItem(githubFlowKey(flowId)) : null;
      if (!flowId || !code || !clientProof) throw new Error(gitErrorMessage("expired"));
      const result = completed.current ?? await api.git.complete({ flowId, code, clientProof, installationId });
      setReturnTo(result.returnTo);
      setOrganizationId(result.organizationId);
      if (result.installations) { setChoices(result.installations); return; }
      completed.current = result;
      await selectWorkspace(result.organizationId);
      sessionStorage.removeItem(githubFlowKey(flowId));
      navigate(`${result.returnTo}?git=connected&method=git`, { replace: true });
    } catch (err) { setError(err instanceof Error ? err.message : "Could not finish connecting GitHub."); }
    finally { setBusy(false); }
  }

  useEffect(() => {
    if (started.current) return;
    started.current = true;
    let previous = params.get("returnTo");
    try { previous = sessionStorage.getItem("qa_github_return") || previous; } catch { /* Show a safe return destination without storage. */ }
    if (previous && (/^\/console\/projects\/[a-zA-Z0-9_-]+\/services\/new$/.test(previous) || previous === "/console/settings" || previous === "/console/projects/new")) setReturnTo(previous);
    if (params.get("error")) { setError(gitErrorMessage(params.get("error"))); return; }
    void complete();
  }, []);

  return <main className="mx-auto max-w-xl px-8 py-12">
    <h1 className="text-2xl font-semibold">{choices.length ? "Choose a GitHub account" : "Connect GitHub"}</h1>
    {!!choices.length && <><p className="mt-3 text-sm text-mute">Choose which account to connect to this workspace.</p><div className="mt-5 space-y-3">{choices.map(choice => <button key={choice.installationId} type="button" disabled={busy} onClick={() => void complete(choice.installationId)} className="flex w-full justify-between rounded-xl border border-line p-4 text-left hover:bg-ink-2"><span>{choice.accountLogin} <span className="text-xs text-mute">{choice.accountType}</span></span><span className="text-signal">Connect →</span></button>)}</div><button type="button" disabled={busy} className="mt-4 text-sm text-signal" onClick={async () => { setBusy(true); try { await startGitHubConnection(organizationId ? { organizationId } : {}, returnTo, undefined, "install"); } catch (err) { setError(err instanceof Error ? err.message : "Could not open GitHub."); setBusy(false); } }}>Install on another account →</button></>}
    {error && <p role="alert" className="mt-4 text-sm text-ember">{error}</p>}
    {error && completed.current && <button type="button" disabled={busy} onClick={() => void complete()} className="mt-4 text-sm text-signal">Retry opening connected workspace</button>}
    {!error && !choices.length && <p role="status" className="mt-4 text-sm text-mute">Verifying GitHub access and preparing your repositories…</p>}
    {(error || choices.length > 0) && <Link to={`${returnTo}?method=git`} className="mt-6 inline-block text-sm text-signal">← Return to {returnTo === "/console/settings" ? "workspace settings" : "repository import"}</Link>}
  </main>;
}
