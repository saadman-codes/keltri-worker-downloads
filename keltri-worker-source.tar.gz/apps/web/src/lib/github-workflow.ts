type WorkflowConfig = {
  projectId: string;
  serviceId: string;
  buildCommand: string | null;
  outputDir: string | null;
  apiUrl: string;
};

/** Builds run on the repository's CI runners; every push produces a preview. */
export function githubActionsYaml(config: WorkflowConfig) {
  return `name: Keltri Preview
on:
  push:
    branches: ['**']
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: keltri-preview-\${{ github.ref }}
  cancel-in-progress: true

jobs:
  deploy:
    runs-on: ubuntu-latest
    env:
      KELTRI_API_URL: ${JSON.stringify(config.apiUrl)}
      PROJECT_ID: ${JSON.stringify(config.projectId)}
      SERVICE_ID: ${JSON.stringify(config.serviceId)}
      BUILD_COMMAND: ${JSON.stringify(config.buildCommand || "npm run build")}
      OUTPUT_DIR: ${JSON.stringify(config.outputDir || "dist")}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '22'
      - name: Install dependencies
        run: npm install
      - name: Build with preview environment variables
        env:
          KELTRI_API_KEY: \${{ secrets.KELTRI_API_KEY }}
        run: |
          set -euo pipefail
          curl --fail-with-body -sS "$KELTRI_API_URL/v1/projects/$PROJECT_ID/services/$SERVICE_ID/env/resolved?target=preview" \\
            -H "Authorization: Bearer $KELTRI_API_KEY" > "$RUNNER_TEMP/keltri-env.json"
          node --input-type=module <<'NODE'
          import { readFileSync, unlinkSync } from 'node:fs';
          import { execFileSync } from 'node:child_process';
          const file = process.env.RUNNER_TEMP + '/keltri-env.json';
          const { data } = JSON.parse(readFileSync(file, 'utf8'));
          unlinkSync(file);
          const escape = value => value.replaceAll('%', '%25').replaceAll('\\r', '%0D').replaceAll('\\n', '%0A');
          for (const value of Object.values(data)) {
            if (value) console.log('::add-mask::' + escape(value));
          }
          const buildEnv = { ...process.env, ...data };
          delete buildEnv.KELTRI_API_KEY;
          execFileSync('bash', ['-e', '-o', 'pipefail', '-c', process.env.BUILD_COMMAND], { env: buildEnv, stdio: 'inherit' });
          NODE
      - name: Package static output
        run: |
          set -euo pipefail
          test -f "$OUTPUT_DIR/index.html" || { echo 'Static output must contain index.html. SSR builds need a static export.'; exit 1; }
          cd -- "$OUTPUT_DIR"
          zip -qr "$RUNNER_TEMP/keltri-build.zip" .
      - name: Deploy preview
        env:
          KELTRI_API_KEY: \${{ secrets.KELTRI_API_KEY }}
        run: |
          set -euo pipefail
          BASE="$KELTRI_API_URL/v1/projects/$PROJECT_ID/services/$SERVICE_ID/deployments"
          BODY=$(jq -n --arg ref "$GITHUB_REF_NAME@\${GITHUB_SHA:0:8}" '{commitRef: $ref}')
          RESPONSE=$(curl --fail-with-body -sS -X POST "$BASE/upload-url" \\
            -H "Authorization: Bearer $KELTRI_API_KEY" -H 'Content-Type: application/json' -d "$BODY")
          UPLOAD_URL=$(echo "$RESPONSE" | jq -er '.data.uploadUrl')
          DEPLOYMENT_ID=$(echo "$RESPONSE" | jq -er '.data.deploymentId')
          curl --fail-with-body -sS -X PUT "$UPLOAD_URL" --data-binary @"$RUNNER_TEMP/keltri-build.zip" -H 'Content-Type: application/zip'
          curl --fail-with-body -sS -X POST "$BASE/$DEPLOYMENT_ID/finalize" -H "Authorization: Bearer $KELTRI_API_KEY"
          echo "Preview: $KELTRI_API_URL/v1/public/deploy/d/$DEPLOYMENT_ID/" >> "$GITHUB_STEP_SUMMARY"
          echo 'Review your preview in Keltri, then promote it to production.' >> "$GITHUB_STEP_SUMMARY"
`;
}
