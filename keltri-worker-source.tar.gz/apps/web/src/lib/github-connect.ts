import { api } from "./api";
import type { GitTarget } from "@keltri/api-client";

export const githubFlowKey = (id: string) => `qa_github_flow:${id}`;
export async function startGitHubConnection(target: GitTarget, returnTo: string, installationId?: string, mode: "connect" | "install" = "connect") {
  const clientProof = Array.from(crypto.getRandomValues(new Uint8Array(32)), b => b.toString(16).padStart(2, "0")).join("");
  // Ensure sessionStorage is usable before beginning a redirect flow.
  sessionStorage.setItem("qa_github_storage_check", "1");
  sessionStorage.removeItem("qa_github_storage_check");
  const flow = await api.git.start({ ...target, returnTo, clientProof, installationId, mode });
  sessionStorage.setItem(githubFlowKey(flow.flowId), clientProof);
  sessionStorage.setItem("qa_github_return", returnTo);
  window.location.assign(flow.url);
}

export function gitErrorMessage(reason: string | null) {
  switch (reason) {
    case "private_key": return "The API cannot read its GitHub App private key. Set GITHUB_APP_PRIVATE_KEY to the full PEM contents in the API hosting environment, then redeploy the API.";
    case "client_credentials": return "GitHub rejected the App client credentials. Check GITHUB_APP_CLIENT_ID and GITHUB_APP_CLIENT_SECRET in the API hosting environment, then redeploy.";
    case "app_credentials": return "GitHub rejected the App’s signed credentials. Check that the private key and client ID belong to the same GitHub App, then redeploy the API.";
    case "callback_mismatch": return "GitHub rejected the callback URL. The App callback must match API_ORIGIN followed by /v1/git/connect/callback.";
    case "authorization_code": return "GitHub rejected the authorization code or verification proof. Start a fresh connection; if it repeats, check the API deployment logs.";
    case "github_permissions": return "GitHub denied the request. Check App permissions, organization approval, and GitHub API rate limits.";
    case "user_token": return "GitHub rejected the temporary user authorization. Start a fresh connection.";
    case "installation_unavailable": return "GitHub could not find the installation or repository with this App’s access. Check whether it was removed or access changed.";
    case "github_unavailable": return "GitHub could not complete the API request. Try again shortly.";
    case "connection_storage": return "GitHub authorization finished, but the API could not save the connection. Check the API database and migration logs.";
    case "configuration": return "The API could not load its GitHub App configuration. Check the API environment variables and redeploy.";
    case "token_exchange": return "The API could not exchange GitHub’s authorization code. Check the API deployment logs for the token_exchange stage.";
    case "installation_discovery": return "The API could not retrieve your GitHub installations. Check the API deployment logs for the installation_discovery stage.";
    case "installation_verification": return "The API could not verify installation access. Check the API deployment logs for the installation_verification stage.";
    case "approval_pending": return "Your GitHub organization must approve the installation. Once approved, connect again from this dashboard.";
    case "cancelled": return "GitHub authorization was cancelled. You can connect again when you’re ready.";
    case "expired": return "This GitHub connection expired or was opened in a different browser. Start again from the dashboard.";
    case "installation": return "GitHub did not return a valid installation. Start the connection again.";
    case "verification": return "GitHub access could not be verified. Return to import and reconnect to recover an existing installation.";
    default: return "The GitHub connection could not be completed. Check the app configuration or try again.";
  }
}
