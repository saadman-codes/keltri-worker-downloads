export const HELLO_EMAIL = "hello@keltriapps.dev";
export const ABUSE_EMAIL = "abuse@keltriapps.dev";

export const helloMailto = `mailto:${HELLO_EMAIL}`;
export const abuseMailto = `mailto:${ABUSE_EMAIL}`;
