import { useEffect, useState } from "react";
import { api } from "./api";
import { useOrg } from "./org-context";
import { apiBase } from "./api-origin";

export type Deployment = {
  id: string; environment: string; status: string; createdAt: string;
  commitRef: string | null; fileCount: number; totalBytes: number;
  promotedAt: string | null; secretScanStatus: string;
};
export type Service = {
  id: string; name: string; slug: string; type: string;
  latestDeployment: Deployment | null;
  productionDeployment?: Deployment | null;
};
export type Project = {
  id: string; name: string; slug: string; organizationId: string | null;
  isOwner: boolean; services: Service[];
};
export type ServiceDetail = Service & {
  project: { id: string; name: string; slug: string }; isOwner: boolean;
  deployments: Deployment[]; buildCommand: string | null; outputDir: string | null;
};
export const serviceLabel = (type: string) => ({ web: "Web", backend: "API", android: "Android", worker: "Worker", desktop: "Desktop" })[type] ?? type;
export const deploymentPath = (projectId: string, serviceId: string, deploymentId: string) => `/console/projects/${projectId}/services/${serviceId}/deployments/${deploymentId}`;
export const previewUrl = (id: string) => `${apiBase()}/v1/public/deploy/d/${encodeURIComponent(id)}/`;
export const productionUrl = (project: string, service: string) => `${apiBase()}/v1/public/deploy/p/${encodeURIComponent(project)}/${encodeURIComponent(service)}/`;

export function useProjects() {
  const { current } = useOrg();
  const [all, setAll] = useState<Project[] | null>(null);
  const [error, setError] = useState("");
  const [version, setVersion] = useState(0);
  useEffect(() => {
    let active = true;
    setError("");
    api.projects.list().then(value => { if (active) setAll(value as Project[]); })
      .catch(err => { if (active) setError(err instanceof Error ? err.message : "Could not load projects"); });
    return () => { active = false; };
  }, [version]);
  return { projects: all?.filter(p => current ? p.organizationId === current.id : !p.organizationId) ?? null, error, reload: () => setVersion(v => v + 1) };
}
