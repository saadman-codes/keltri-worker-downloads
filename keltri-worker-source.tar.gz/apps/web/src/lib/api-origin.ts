import { sites } from "@keltri/ui";

function isLocalhost() {
  return typeof window !== "undefined" && window.location.hostname === "localhost";
}

/** Same-origin `/v1` via the Vite proxy locally; absolute API URL in production. */
export function apiBase() {
  if (isLocalhost()) return "";
  return sites.api;
}

// True only on a real deployment (not localhost) where VITE_API_URL was never
// set, so sites.api is still the http://localhost:4000 dev default — a
// browser on someone else's machine can never reach that. Distinct from
// "we're running locally in dev", which is the normal, working case.
export function apiMisconfigured() {
  return !isLocalhost() && sites.api.includes("localhost");
}
