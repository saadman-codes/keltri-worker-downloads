import { apiBase } from "./api-origin";

const TOKEN_KEY = "qa_session";
const FLAG = "qa_portal=1";

export function getSessionToken() {
  if (typeof window === "undefined") return "";
  return window.localStorage.getItem(TOKEN_KEY) ?? "";
}

export function isAuthed() {
  if (typeof window === "undefined") return false;
  return Boolean(getSessionToken()) || document.cookie.includes("qa_portal=");
}

export function setSession(token: string) {
  window.localStorage.setItem(TOKEN_KEY, token);
  document.cookie = `${FLAG}; path=/; samesite=lax`;
}

export function clearSession() {
  window.localStorage.removeItem(TOKEN_KEY);
  document.cookie = "qa_portal=; path=/; max-age=0";
}

export async function loginRequest(email: string, password: string) {
  const res = await fetch(`${apiBase()}/v1/auth/login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify({ email, password }),
  });
  const json = (await res.json()) as {
    data?: { token?: string };
    error?: unknown;
  };
  if (!res.ok || !json.data?.token) {
    throw new Error(
      typeof json.error === "string" ? json.error : "Invalid email or password",
    );
  }
  setSession(json.data.token);
}

export async function registerRequest(body: {
  name: string;
  email: string;
  password: string;
}) {
  const res = await fetch(`${apiBase()}/v1/auth/register`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  const json = (await res.json()) as {
    data?: { token?: string };
    error?: unknown;
  };
  if (!res.ok || !json.data?.token) {
    throw new Error(
      typeof json.error === "string" ? json.error : "Could not create account",
    );
  }
  setSession(json.data.token);
}

export async function logoutRequest() {
  const token = getSessionToken();
  await fetch(`${apiBase()}/v1/auth/logout`, {
    method: "POST",
    credentials: "include",
    headers: token ? { Authorization: `Bearer ${token}` } : undefined,
  }).catch(() => undefined);
  clearSession();
}
