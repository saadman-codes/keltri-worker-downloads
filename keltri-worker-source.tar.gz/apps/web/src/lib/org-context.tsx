import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  useRef,
} from "react";
import { api } from "./api";

type Developer = {
  id: string;
  name: string;
  email: string;
  slug: string;
  plan: string;
  githubConnected: boolean;
};

type Organization = {
  id: string;
  name: string;
  slug: string;
  plan: string;
  role: "owner" | "member";
  createdAt: string;
};

type OrgContextValue = {
  developer: Developer | null;
  organizations: Organization[];
  current: Organization | null;
  setCurrent: (org: Organization | null) => void;
  reload: () => void;
  selectWorkspace: (id: string | null) => Promise<void>;
};

const STORAGE_KEY = "qa_current_org";

const OrgContext = createContext<OrgContextValue | null>(null);

export function OrgProvider({ children }: { children: React.ReactNode }) {
  const [developer, setDeveloper] = useState<Developer | null>(null);
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [current, setCurrentState] = useState<Organization | null>(null);
  const revision = useRef(0);

  const reload = useCallback(() => {
    const request = ++revision.current;
    api.me().then((value) => setDeveloper(value as Developer)).catch(() => {});
    api.organizations
      .list()
      .then((value) => {
        if (request !== revision.current) return;
        const orgs = value as Organization[];
        setOrganizations(orgs);
        const storedId = window.localStorage.getItem(STORAGE_KEY);
        const match = orgs.find(org => org.id === storedId);
        setCurrentState(match ?? null);
        if (storedId && !match) window.localStorage.removeItem(STORAGE_KEY);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  function setCurrent(org: Organization | null) {
    revision.current++;
    setCurrentState(org);
    if (org) window.localStorage.setItem(STORAGE_KEY, org.id);
    else window.localStorage.removeItem(STORAGE_KEY);
  }

  async function selectWorkspace(id: string | null) {
    revision.current++;
    if (!id) { setCurrent(null); return; }
    const orgs = await api.organizations.list() as Organization[];
    const selected = orgs.find(org => org.id === id);
    if (!selected) throw new Error("The connected workspace is no longer accessible.");
    setOrganizations(orgs);
    setCurrent(selected);
  }

  return (
    <OrgContext.Provider
      value={{ developer, organizations, current, setCurrent, reload, selectWorkspace }}
    >
      {children}
    </OrgContext.Provider>
  );
}

export function useOrg() {
  const ctx = useContext(OrgContext);
  if (!ctx) throw new Error("useOrg() must be used inside <OrgProvider>");
  return ctx;
}
