import { sites } from "@keltri/ui";

const API =
  typeof window !== "undefined" && window.location.hostname === "localhost"
    ? ""
    : sites.api;

export function apiUrl(path: string) {
  return `${API}${path}`;
}

export type CatalogApp = {
  slug: string;
  name: string;
  shortDescription: string | null;
  category: string | null;
  iconUrl: string | null;
  miniAppEnabled: boolean;
  featured: boolean;
  developer: { name: string; slug: string };
  versionName?: string;
  installs: number;
  rating: number;
  reviewCount: number;
};

export type Catalog = {
  featured: CatalogApp[];
  newThisWeek: CatalogApp[];
  top: CatalogApp[];
  categories: string[];
};

export type PublicApp = CatalogApp & {
  description: string | null;
  contentRating: string | null;
  permissions: string[];
  releaseNotes: string | null;
  screenshots: Array<{ id: string; url: string }>;
  reviews: Array<{
    id: string;
    author: string;
    rating: number;
    body: string;
  }>;
  installUrl: string | null;
};

export type PublicDeveloper = {
  name: string;
  slug: string;
  bio: string | null;
  website: string | null;
  installs: number;
  rating: number;
  apps: CatalogApp[];
};

const sample = (
  partial: Omit<CatalogApp, "iconUrl" | "featured" | "reviewCount"> & {
    featured?: boolean;
    reviewCount?: number;
  },
): CatalogApp => ({
  iconUrl: null,
  featured: false,
  reviewCount: partial.reviewCount ?? 12,
  ...partial,
});

/** Fictional local/dev demo data. Never used as a production catalog fallback. */
export const sampleCatalog: Catalog = {
  featured: [
    sample({
      slug: "myapp",
      name: "MyApp",
      shortDescription: "The best task manager on Android",
      category: "productivity",
      miniAppEnabled: true,
      featured: true,
      developer: { name: "Dev Studio", slug: "dev-studio" },
      versionName: "1.3",
      installs: 142830,
      rating: 4.7,
      reviewCount: 3,
    }),
    sample({
      slug: "drift-racers",
      name: "Drift Racers",
      shortDescription: "Arcade racing with weekly tracks",
      category: "games",
      miniAppEnabled: false,
      featured: true,
      developer: { name: "Northwind Games", slug: "northwind-games" },
      installs: 98000,
      rating: 4.6,
    }),
  ],
  newThisWeek: [
    sample({
      slug: "pulse-chat",
      name: "Pulse Chat",
      shortDescription: "Encrypted group chat that stays on-device",
      category: "social",
      miniAppEnabled: false,
      developer: { name: "Harbor Labs", slug: "harbor-labs" },
      installs: 22100,
      rating: 4.5,
    }),
    sample({
      slug: "night-notes",
      name: "Night Notes",
      shortDescription: "Dark-mode notes that sync over OTA",
      category: "productivity",
      miniAppEnabled: false,
      developer: { name: "Harbor Labs", slug: "harbor-labs" },
      installs: 15400,
      rating: 4.4,
    }),
  ],
  top: [],
  categories: ["games", "tools", "productivity", "finance", "social"],
};

sampleCatalog.top = [
  ...sampleCatalog.featured,
  ...sampleCatalog.newThisWeek,
  sample({
    slug: "orbit-puzzle",
    name: "Orbit Puzzle",
    shortDescription: "Gravity puzzles in sixty-second rounds",
    category: "games",
    miniAppEnabled: false,
    developer: { name: "Northwind Games", slug: "northwind-games" },
    installs: 64000,
    rating: 4.8,
  }),
  sample({
    slug: "ledger-lite",
    name: "Ledger Lite",
    shortDescription: "Offline-first personal finance",
    category: "finance",
    miniAppEnabled: false,
    developer: { name: "Harbor Labs", slug: "harbor-labs" },
    installs: 41000,
    rating: 4.3,
  }),
  sample({
    slug: "signal-kit",
    name: "Signal Kit",
    shortDescription: "Network diagnostics in your pocket",
    category: "tools",
    miniAppEnabled: false,
    developer: { name: "Harbor Labs", slug: "harbor-labs" },
    installs: 30800,
    rating: 4.2,
  }),
  sample({
    slug: "vault-box",
    name: "Vault Box",
    shortDescription: "Private file locker with local keys",
    category: "tools",
    miniAppEnabled: false,
    developer: { name: "Harbor Labs", slug: "harbor-labs" },
    installs: 27500,
    rating: 4.1,
  }),
];

async function getJson<T>(path: string): Promise<T | null> {
  try {
    const res = await fetch(apiUrl(path), { cache: "no-store" });
    if (!res.ok) return null;
    const json = (await res.json()) as { data: T };
    return json.data;
  } catch {
    return null;
  }
}

export const fetchCatalog = () => getJson<Catalog>("/v1/public/catalog");
export const fetchPublicApp = (slug: string) =>
  getJson<PublicApp>(`/v1/public/apps/${slug}`);
export const fetchPublicDeveloper = (slug: string) =>
  getJson<PublicDeveloper>(`/v1/public/developers/${slug}`);

export const emptyCatalog: Catalog = {
  featured: [],
  newThisWeek: [],
  top: [],
  categories: [],
};

/** Local/dev only. Production must not substitute these fictional counts. */
export function allowSampleCatalogFallback(
  hostname = typeof window === "undefined" ? "" : window.location.hostname,
) {
  return hostname === "localhost" || hostname === "127.0.0.1";
}

export function uniqueApps(catalog: Catalog) {
  const map = new Map<string, CatalogApp>();
  for (const app of [...catalog.featured, ...catalog.newThisWeek, ...catalog.top]) {
    map.set(app.slug, app);
  }
  return [...map.values()];
}
