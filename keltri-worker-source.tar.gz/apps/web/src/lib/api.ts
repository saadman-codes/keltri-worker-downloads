import { createClient } from "@keltri/api-client";
import { apiBase } from "./api-origin";
import { getSessionToken } from "./session";

export const api = createClient({
  baseUrl: apiBase(),
  credentials: "include",
  apiKey: getSessionToken,
});
