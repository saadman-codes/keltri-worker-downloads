import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { useOrg } from "../lib/org-context";

export function OrgSwitcher() {
  const { developer, organizations, current, setCurrent } = useOrg();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const rootRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function onClick(event: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const label = current
    ? current.name
    : developer
      ? `${developer.name}'s projects`
      : "";
  const plan = (current ? current.plan : developer?.plan) ?? "";
  const filteredOrgs = organizations.filter((org) =>
    org.name.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="relative" ref={rootRef}>
      <button
        type="button"
        aria-expanded={open}
        aria-label="Switch workspace"
        onClick={() => setOpen((value) => !value)}
        className="flex w-full items-center justify-between gap-2 rounded-lg border border-line bg-ink-3 px-2 py-1.5 text-left text-xs"
      >
        <span className="min-w-0 flex-1 truncate">{label}</span>
        {plan ? (
          <span className="shrink-0 rounded-full border border-line px-1.5 py-0.5 text-[10px] text-mute">
            {plan.charAt(0).toUpperCase() + plan.slice(1)}
          </span>
        ) : null}
        <span className="shrink-0 text-mute">▾</span>
      </button>
      {open ? (
        <div className="absolute left-0 top-full z-10 mt-1 w-72 rounded-xl border border-line bg-ink-2 p-2 shadow-lg">
          <input
            autoFocus
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Find workspace…"
            aria-label="Find workspace"
            className="w-full rounded-lg border border-line bg-ink-3 px-2 py-1.5 text-xs"
          />
          <div className="mt-2 max-h-64 overflow-auto">
            <button
              type="button"
              onClick={() => {
                setCurrent(null);
                setOpen(false);
              }}
              className="flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-left text-xs hover:bg-ink-3"
            >
              <span className="truncate">
                {developer ? `${developer.name}'s projects` : "Personal"}
              </span>
              {!current ? <span className="text-signal">✓</span> : null}
            </button>
            {filteredOrgs.length > 0 ? (
              <div className="mt-1 space-y-0.5">
                {filteredOrgs.map((org) => (
                  <div
                    key={org.id}
                    className="flex items-center justify-between rounded-lg px-2 py-1.5 hover:bg-ink-3"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setCurrent(org);
                        setOpen(false);
                      }}
                      className="min-w-0 flex-1 truncate text-left text-xs"
                    >
                      {org.name}
                    </button>
                    <span className="flex shrink-0 items-center gap-2">
                      {current?.id === org.id ? (
                        <span className="text-signal">✓</span>
                      ) : null}
                      <Link
                        to={`/console/organizations/${org.id}/members`}
                        onClick={() => setOpen(false)}
                        className="text-mute hover:text-paper"
                      >
                        Members
                      </Link>
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 px-2 text-xs text-mute">
                Workspaces you create and join appear here.
              </p>
            )}
          </div>
          <Link
            to="/console/organizations/new"
            onClick={() => setOpen(false)}
            className="mt-2 block rounded-lg border border-line px-2 py-1.5 text-xs hover:bg-ink-3"
          >
            <span className="font-semibold">+ Create Workspace</span>
            <span className="block text-mute">
              Collaborate with others in a shared workspace.
            </span>
          </Link>
        </div>
      ) : null}
    </div>
  );
}
