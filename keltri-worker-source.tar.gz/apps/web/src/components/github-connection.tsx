import { useEffect, useRef, useState } from "react";
import type { GitStatus, GitTarget } from "@keltri/api-client";
import { api } from "../lib/api";
import { startGitHubConnection } from "../lib/github-connect";

export function GitHubConnection({ target, returnTo, onDisconnect, onStatus, compact = false }: { target: GitTarget; returnTo: string; onDisconnect?: () => void; onStatus?: (status: GitStatus | null) => void; compact?: boolean }) {
  const [status, setStatus] = useState<GitStatus | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [version, setVersion] = useState(0);
  const { projectId, organizationId } = target;
  const scope = JSON.stringify([projectId, organizationId]);
  const previousScope = useRef<string | null>(null);
  useEffect(() => {
    let active = true;
    // Keep existing controls mounted during focus/reload checks so a click
    // returning to this tab is not lost when the repository list disappears.
    if (previousScope.current !== scope) {
      setStatus(null);
      onStatus?.(null);
      previousScope.current = scope;
    }
    setError("");
    api.git.status({ ...(projectId ? { projectId } : {}), ...(organizationId ? { organizationId } : {}) })
      .then(value => { if (active) { setStatus(value); onStatus?.(value); } })
      .catch(err => { if (active) setError(err.message); });
    return () => { active = false; };
  }, [projectId, organizationId, version, onStatus, scope]);
  useEffect(() => {
    const refresh = () => { if (document.visibilityState === "visible") setVersion(v => v + 1); };
    window.addEventListener("focus", refresh);
    document.addEventListener("visibilitychange", refresh);
    return () => { window.removeEventListener("focus", refresh); document.removeEventListener("visibilitychange", refresh); };
  }, []);
  async function connect(installationId?: string, mode: "connect" | "install" = "connect") {
    setBusy(true); setError("");
    try { await startGitHubConnection(target, returnTo, installationId, mode); }
    catch (err) { setError(err instanceof Error ? err.message : "Could not connect GitHub."); setBusy(false); }
  }
  return <section className="mt-4 rounded-xl border border-line bg-ink-2 p-5">
    <details open={!compact || !status?.installations.length || !!error}>
    <summary className="cursor-pointer text-sm font-medium">{!status ? "Checking GitHub connection" : status.installations.length ? `GitHub · ${status.installations.map(i => i.accountLogin).join(", ")}` : "Connect GitHub to this workspace"}</summary>
    {status && !status.installations.length && <p className="mt-2 text-sm text-mute">This workspace has no saved GitHub connection. Link your account once to load its repositories automatically on future visits.</p>}
    {error && <p role="alert" className="mt-3 text-sm">{error} <button type="button" className="underline" onClick={() => setVersion(v => v + 1)}>Retry</button></p>}
    {!status && !error && <p role="status" className="mt-3 text-sm text-mute">Checking connection…</p>}
    {status && <>
      {!status.configured && <p className="mt-3 text-sm text-mute">The GitHub App needs server configuration before connections are available.</p>}
      {!status.canManage && <p className="mt-3 text-sm text-mute">A workspace owner can connect GitHub or change access.</p>}
      {status.installations.map(i => <div key={i.id} className="mt-4 border-t border-line pt-4"><p className="text-sm font-medium">{i.accountLogin} <span className="text-xs text-mute">{i.suspended ? "· Suspended" : `· ${i.repositoryCount} verified repositories`}</span></p>{status.canManage && <div className="mt-2 flex flex-wrap gap-4 text-xs"><a href={i.manageUrl} target="_blank" rel="noreferrer" className="text-signal">Manage on GitHub ↗</a><button type="button" disabled={busy || !status.configured} onClick={() => connect(i.id)} className="text-signal">Refresh access</button><button type="button" disabled={busy} className="text-mute" onClick={async () => { setBusy(true); setError(""); try { await api.git.disconnect({ ...target, installationId: i.id }); onDisconnect?.(); setVersion(v => v + 1); } catch (err) { setError(err instanceof Error ? err.message : "Could not disconnect."); } finally { setBusy(false); } }}>Disconnect workspace</button></div>}</div>)}
      {status.canManage && <div className="mt-4 flex flex-wrap items-center gap-4">{!status.installations.length && <button type="button" disabled={busy || !status.configured} onClick={() => connect()} className="rounded-lg bg-signal px-4 py-2 text-sm font-medium text-signal-ink">{busy ? "Connecting…" : "Connect GitHub"}</button>}<button type="button" disabled={busy || !status.configured} onClick={() => connect(undefined, "install")} className="text-sm text-signal">Add another GitHub account ↗</button><button type="button" disabled={busy} onClick={() => setVersion(v => v + 1)} className="text-sm text-signal">Reload connection</button></div>}
      {!!status.installations.length && <p className="mt-3 text-xs text-mute">After adding repositories on GitHub, use Refresh access to verify them for this workspace. Disconnecting here does not uninstall the GitHub App.</p>}
      {status.diagnostics && <details className="mt-4 text-xs text-mute">
        <summary className="cursor-pointer">GitHub App configuration (for verifying against github.com — no secrets shown)</summary>
        <dl className="mt-2 grid grid-cols-[max-content_1fr] gap-x-3 gap-y-1 font-mono">
          <dt>App ID</dt><dd>{status.diagnostics.appId}</dd>
          <dt>Client ID</dt><dd>{status.diagnostics.clientId}</dd>
          <dt>Slug</dt><dd>{status.diagnostics.slug}</dd>
          <dt>API origin</dt><dd>{status.diagnostics.apiOrigin}</dd>
          <dt>Callback URL</dt><dd>{status.diagnostics.callbackUrl}</dd>
          <dt>Secret length</dt><dd>{status.diagnostics.clientSecretLength} chars</dd>
          <dt>Secret fingerprint</dt><dd>sha256:{status.diagnostics.clientSecretFingerprint}…</dd>
          <dt>Private key fingerprint</dt><dd>sha256:{status.diagnostics.privateKeyFingerprint}…</dd>
        </dl>
        <p className="mt-2">Compare App ID/Client ID/Slug/Callback URL directly against the App's settings page. To confirm the secret without pasting it anywhere, run <code>printf %s YOUR_SECRET | shasum -a 256</code> locally and check the first 12 hex characters match the fingerprint above.</p>
      </details>}
    </>}
    </details>
  </section>;
}
