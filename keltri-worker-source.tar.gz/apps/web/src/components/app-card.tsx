import { Link } from "react-router-dom";
import { useState } from "react";
import type { CatalogApp } from "../lib/catalog";

export function AppIcon({
  app,
  size = "md",
}: {
  app: Pick<CatalogApp, "name" | "iconUrl">;
  size?: "sm" | "md" | "lg";
}) {
  const [broken, setBroken] = useState(false);
  const box =
    size === "lg"
      ? "h-24 w-24 text-3xl"
      : size === "sm"
        ? "h-12 w-12 text-lg"
        : "h-16 w-16 text-xl";
  if (app.iconUrl && !broken) {
    return (
      <img
        src={app.iconUrl}
        alt=""
        onError={() => setBroken(true)}
        className={`${box} rounded-2xl object-cover`}
      />
    );
  }
  return (
    <div
      className={`grid ${box} place-items-center rounded-2xl bg-ink-3 font-display text-signal`}
    >
      {app.name.slice(0, 1).toUpperCase()}
    </div>
  );
}

export function StoreActions({
  app,
  size = "sm",
}: {
  app: Pick<CatalogApp, "slug" | "miniAppEnabled">;
  size?: "sm" | "md";
}) {
  const compact = size === "sm";
  const base = compact
    ? "rounded-full px-3 py-1.5 text-xs"
    : "rounded-full px-5 py-2.5 text-sm";
  return (
    <div className="flex flex-wrap gap-2">
      {app.miniAppEnabled ? (
        <Link
          to={`/store/apps/${app.slug}/try`}
          className={`${base} bg-signal font-semibold text-signal-ink`}
        >
          Try
        </Link>
      ) : null}
      <Link
        to={`/get/${app.slug}`}
        className={`${base} border border-line`}
      >
        Install
      </Link>
    </div>
  );
}

export function AppCard({ app }: { app: CatalogApp }) {
  return (
    <article className="flex w-40 shrink-0 flex-col rounded-2xl border border-line bg-ink-2 p-3">
      <Link to={`/store/apps/${app.slug}`} className="min-w-0">
        <AppIcon app={app} />
        <p className="font-display mt-3 truncate text-base">{app.name}</p>
        <p className="mt-1 truncate text-xs text-mute">
          {app.category ?? "app"} · ★ {app.rating}
        </p>
      </Link>
      <div className="mt-3">
        <StoreActions app={app} />
      </div>
    </article>
  );
}

export function AppRail({
  title,
  apps,
}: {
  title: string;
  apps: CatalogApp[];
}) {
  if (apps.length === 0) return null;
  return (
    <section className="mt-10">
      <h2 className="font-display text-2xl">{title}</h2>
      <div className="mt-4 flex gap-3 overflow-x-auto pb-2">
        {apps.map((app) => (
          <AppCard key={app.slug} app={app} />
        ))}
      </div>
    </section>
  );
}
