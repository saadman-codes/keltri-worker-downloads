import { sites, Wordmark } from "@keltri/ui";
import { useEffect, useState } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { OrgSwitcher } from "./org-switcher";
import { api } from "../lib/api";
import { OrgProvider } from "../lib/org-context";
import { helloMailto } from "../lib/contacts";
import { isAuthed, logoutRequest } from "../lib/session";

const groups = [
  { label: "Workspace", links: [["Overview", "/console"]] },
  { label: "Projects", links: [["Projects", "/console/projects"], ["Deployments", "/console/deployments"]] },
  { label: "Platform", links: [["Domains", "/console/domains"], ["Storage", "/console/blobs"]] },
  { label: "Distribution", links: [["Store", "/console/store"]] },
  { label: "Manage", links: [["Audit log", "/console/audit-log"], ["Settings", "/console/settings"]] },
];

export function Shell() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [menu, setMenu] = useState(false);
  const [theme, setTheme] = useState(() => localStorage.getItem("qa_console_theme") === "dark" ? "dark" : "light");
  useEffect(() => { setMenu(false); }, [pathname]);
  useEffect(() => { localStorage.setItem("qa_console_theme", theme); }, [theme]);
  useEffect(() => {
    if (!isAuthed()) navigate("/console/login", { replace: true });
    else api.me().catch(() => navigate("/console/login", { replace: true }));
  }, [navigate]);

  return (
    <OrgProvider>
      <div className="console-theme min-h-screen md:flex" data-theme={theme}>
        <header className="flex items-center justify-between border-b border-line bg-ink-2 px-4 py-3 md:hidden">
          <Link to="/console"><Wordmark /></Link>
          <button type="button" aria-expanded={menu} aria-controls="console-navigation" onClick={() => setMenu(!menu)} className="rounded-lg border border-line px-3 py-2 text-sm">{menu ? "Close menu" : "Menu"}</button>
        </header>
        <aside id="console-navigation" className={`${menu ? "block" : "hidden"} shrink-0 border-r border-line bg-ink-2 p-5 md:sticky md:top-0 md:block md:h-screen md:w-60 md:overflow-y-auto`}>
          <Link className="hidden md:block" to="/console"><Wordmark /></Link>
          <div className="mt-4"><OrgSwitcher /></div>
          <nav aria-label="Workspace" className="mt-7 space-y-5 text-sm">
            {groups.map(group => <div key={group.label}>
              <p className="mb-1 px-3 text-[10px] font-semibold uppercase tracking-widest text-mute">{group.label}</p>
              {group.links.map(([label, href]) => {
                const active = href === "/console" ? pathname === href : pathname.startsWith(href);
                return <Link key={href} to={href} aria-current={active ? "page" : undefined} className={`my-0.5 block rounded-lg px-3 py-2 ${active ? "bg-ink-3 font-medium text-signal" : "text-mute hover:bg-ink-3 hover:text-paper"}`}>{label}</Link>;
              })}
            </div>)}
          </nav>
          <div className="mt-8 space-y-3 border-t border-line pt-5 text-xs text-mute">
            <div className="flex gap-5"><a href={sites.docs} target="_blank" rel="noreferrer">Docs ↗</a><a href={helloMailto}>Support ↗</a></div>
            <button type="button" className="block" onClick={() => setTheme(theme === "light" ? "dark" : "light")}>{theme === "light" ? "☾ Dark appearance" : "☀ Light appearance"}</button>
            <button type="button" onClick={async () => { await logoutRequest(); navigate("/console/login", { replace: true }); }}>Sign out</button>
          </div>
        </aside>
        <div className="min-w-0 flex-1"><Outlet /></div>
      </div>
    </OrgProvider>
  );
}
