import { useEffect, useState } from "react";
import type { GitStatus, GitTarget } from "@quantum/api-client";
import { api } from "../lib/api";
import { GitHubConnection } from "./github-connection";

export type ImportRepository = { id: number; name: string; fullName: string; installationId: string; private: boolean };

export function GitRepositoryPicker({ target, onSelect }: { target: GitTarget; onSelect: (repo: ImportRepository) => void }) {
  const [repos, setRepos] = useState<ImportRepository[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<GitStatus | null>(null);
  const connected = !!status?.installations.some(i => !i.suspended);
  const [version, setVersion] = useState(0);
  useEffect(() => {
    let active = true;
    setLoading(true); setError("");
    if (!status) return;
    if (!connected) { setRepos([]); setLoading(false); return; }
    const scope = { ...(target.organizationId ? { organizationId: target.organizationId } : {}), ...(target.projectId ? { projectId: target.projectId } : {}) };
    api.git.repos(scope).then(repositories => { if (active) setRepos(repositories); })
      .catch(err => { if (active) setError(err instanceof Error ? err.message : "Could not load repositories."); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [target.organizationId, target.projectId, version, status, connected]);
  const filtered = repos.filter(repo => repo.fullName.toLowerCase().includes(query.toLowerCase()));
  return <section aria-label="Import a GitHub repository">
    <GitHubConnection compact target={target} returnTo="/console/projects/new" onStatus={setStatus} onDisconnect={() => setStatus(null)} />
    {loading && connected && <p role="status" className="mt-4 text-sm text-mute">{repos.length ? "Refreshing repositories…" : "Loading repositories…"}</p>}
    {error && <p role="alert" className="mt-4 text-sm text-ember">{error} <button type="button" onClick={() => setVersion(v => v + 1)} className="underline">Retry</button></p>}
    {connected && (!loading || repos.length > 0) && <div className="mt-4">
      <label className="block text-sm text-mute">Find a repository<input value={query} onChange={event => setQuery(event.target.value)} className="mt-2 w-full rounded-xl border border-line bg-ink-2 px-3 py-2" placeholder="Search your repositories…" /></label>
      <div className="mt-3 max-h-80 space-y-2 overflow-auto">
        {filtered.map(repo => <button key={`${repo.installationId}:${repo.id}`} type="button" onClick={() => onSelect(repo)} className="flex w-full items-center justify-between rounded-xl border border-line p-4 text-left hover:bg-ink-2"><span><span className="block text-sm font-medium">{repo.fullName}</span><span className="text-xs text-mute">{repo.private ? "Private" : "Public"}</span></span><span className="text-sm text-signal">Import →</span></button>)}
        {!filtered.length && <p className="text-sm text-mute">{repos.length ? "No matching repositories." : "No repositories available. Choose repositories with Manage on GitHub, then Refresh access."}</p>}
      </div>
    </div>}
  </section>;
}
