import { Wordmark, sites } from "@keltri/ui";
import { Link, useLocation } from "react-router-dom";
import { ABUSE_EMAIL, HELLO_EMAIL, abuseMailto, helloMailto } from "../lib/contacts";
import { useDocumentTitle } from "../lib/title";

const navLinks = [
  { href: "/store", label: "Store" },
  { href: sites.docs, label: "Docs", external: true },
];

// Site-wide shell: platform landing, store, and every legal/utility page
// share this. Store-specific chrome (search, category chips) lives inside
// the store page itself now, not the global header — a website/backend
// project has nothing to search for apps in.
export function StoreShell({ children }: { children: React.ReactNode }) {
  useDocumentTitle("Keltri");
  const location = useLocation();

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-line/80 bg-ink/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-6">
          <Link to="/" aria-label="Keltri home" className="shrink-0">
            <Wordmark />
          </Link>
          <nav className="ml-auto hidden items-center gap-6 text-sm md:flex">
            {navLinks.map((link) => {
              const active =
                !link.external && location.pathname.startsWith(link.href);
              const className = active
                ? "text-paper"
                : "text-mute hover:text-paper";
              return link.external ? (
                <a key={link.href} href={link.href} className={className}>
                  {link.label}
                </a>
              ) : (
                <Link key={link.href} to={link.href} className={className}>
                  {link.label}
                </Link>
              );
            })}
          </nav>
          <Link
            to="/console"
            className="rounded-full border border-line px-3 py-1.5 text-sm text-mute hover:text-paper"
          >
            Console
          </Link>
        </div>
      </header>
      {children}
      <footer className="mt-auto border-t border-line bg-ink-2">
        <div className="mx-auto grid max-w-6xl gap-10 px-6 py-14 md:grid-cols-2 lg:grid-cols-5">
          <div className="md:col-span-1">
            <Wordmark />
            <p className="mt-4 max-w-xs text-sm leading-6 text-mute">
              Push web, backend, and mobile — preview it, then ship it. The
              app Store is optional distribution on top.
            </p>
          </div>
          <FooterCol
            title="Store"
            items={[
              ["Apps", "/store"],
              ["Games", "/store?category=games"],
              ["Status", "/status"],
            ]}
          />
          <FooterCol
            title="Platform"
            items={[
              ["Console", "/console"],
              ["Docs", sites.docs],
              ["CLI", `${sites.docs}/reference/cli`],
            ]}
          />
          <FooterCol
            title="Contact"
            items={[
              ["Discord", "https://discord.gg/quantumapps"],
              [HELLO_EMAIL, helloMailto],
            ]}
          />
          <FooterCol
            title="Legal"
            items={[
              ["Terms", "/terms"],
              ["Privacy", "/privacy"],
              ["Install help", "/install-help"],
              ["Abuse / report", abuseMailto],
            ]}
          />
        </div>
        <div className="border-t border-line px-6 py-5 text-center font-mono text-xs text-mute">
          CLI and SDK: MIT · Platform: Proprietary · Abuse:{" "}
          <a href={abuseMailto} className="hover:text-paper">
            {ABUSE_EMAIL}
          </a>
        </div>
      </footer>
    </>
  );
}

function FooterCol({
  title,
  items,
}: {
  title: string;
  items: [string, string][];
}) {
  return (
    <div>
      <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-mute">
        {title}
      </p>
      <ul className="mt-4 space-y-2 text-sm">
        {items.map(([label, href]) => (
          <li key={href}>
            {href.startsWith("/") ? (
              <Link to={href} className="text-paper/90 hover:text-signal">
                {label}
              </Link>
            ) : (
              <a href={href} className="text-paper/90 hover:text-signal">
                {label}
              </a>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
