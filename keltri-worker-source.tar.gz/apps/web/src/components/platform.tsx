import { Link } from "react-router-dom";
import { serviceLabel, type Project } from "../lib/platform";

export function Status({ value }: { value: string }) {
  const color = value === "ready" || value === "production" ? "var(--success)" : value === "failed" ? "var(--destructive)" : "var(--muted-foreground)";
  return <span className="inline-flex items-center gap-2 text-xs capitalize"><span aria-hidden="true" className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />{value}</span>;
}

export function ProjectCard({ project }: { project: Project }) {
  return <Link to={`/console/projects/${project.id}`} className="block rounded-xl border border-line bg-ink-2 p-5 transition hover:border-signal">
    <div className="flex items-center justify-between"><span className="flex h-9 w-9 items-center justify-center rounded-lg border border-line bg-ink-3 font-semibold">{project.name[0]?.toUpperCase()}</span><span className="text-mute">↗</span></div>
    <h3 className="mt-4 font-semibold">{project.name}</h3>
    <p className="mt-1 font-mono text-xs text-mute">{project.slug}</p>
    <div className="mt-5 flex flex-wrap gap-3 border-t border-line pt-4">
      {project.services.map(s => <span key={s.id} className="text-xs"><span className="block font-medium">{serviceLabel(s.type)}</span><span className="mt-1 block text-mute"><Status value={s.productionDeployment?.status === "ready" ? "production" : s.latestDeployment?.status ?? "not deployed"} /></span></span>)}
      {!project.services.length && <span className="text-xs text-mute">Add your first service →</span>}
    </div>
  </Link>;
}

export function GettingStarted() {
  return <section className="mt-8 rounded-xl border border-line bg-ink-2 p-6 sm:p-10">
    <p className="text-xs font-medium uppercase tracking-widest text-signal">Your whole product, together</p>
    <h2 className="mt-3 text-2xl font-semibold tracking-tight">Welcome to Keltri</h2>
    <p className="mt-2 text-sm text-mute">What do you want to deploy? Start with one service. Add the rest as you grow.</p>
    <div className="mt-7">
      <Link to="/console/projects/new" className="block rounded-xl border border-line p-5 hover:border-signal hover:bg-ink-3"><span className="text-lg text-signal">◇</span><h3 className="mt-3 font-medium">Import Git</h3><p className="mt-1 text-xs text-mute">Connect a GitHub repository</p></Link>
    </div>
    <p className="mt-5 text-xs text-mute">Web hosting is available now. API execution, Android services, and desktop builds are coming later.</p>
  </section>;
}
