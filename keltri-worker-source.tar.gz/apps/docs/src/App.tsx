import { Route, Routes } from "react-router-dom";
import { DocsShell } from "./components/docs-shell";
import { DocPage } from "./pages/doc";

export default function App() {
  return (
    <Routes>
      <Route element={<DocsShell />}>
        <Route path="/" element={<DocPage />} />
        <Route path="*" element={<DocPage />} />
      </Route>
    </Routes>
  );
}
