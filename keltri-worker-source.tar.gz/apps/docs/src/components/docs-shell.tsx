import { Wordmark, sites } from "@keltri/ui";
import { NavLink, Outlet } from "react-router-dom";
import { docsNav } from "../content";

export function DocsShell() {
  return (
    <div className="flex min-h-screen">
      <aside className="hidden w-64 shrink-0 border-r border-line bg-ink-2 p-5 md:block">
        <a href={sites.web}>
          <Wordmark />
        </a>
        <p className="mt-2 font-mono text-[10px] uppercase tracking-widest text-mute">
          docs
        </p>
        <nav className="mt-8 space-y-6">
          {docsNav.map((group) => (
            <div key={group.title}>
              <p className="font-mono text-[11px] uppercase tracking-widest text-mute">
                {group.title}
              </p>
              <ul className="mt-2 space-y-1 text-sm">
                {group.items.map(([label, href]) => (
                  <li key={href}>
                    <NavLink
                      to={href}
                      className={({ isActive }) =>
                        isActive
                          ? "text-signal"
                          : "text-paper/90 hover:text-signal"
                      }
                    >
                      {label}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
      </aside>
      <div className="min-w-0 flex-1">
        <Outlet />
      </div>
    </div>
  );
}
