import { useLocation } from "react-router-dom";
import { pages } from "../content";

export function DocPage() {
  const { pathname } = useLocation();
  const path = pathname.replace(/\/+$/, "") || "/";
  const page = pages[path];

  if (!page) {
    return (
      <article className="mx-auto max-w-3xl px-8 py-12">
        <p className="font-mono text-xs uppercase tracking-widest text-signal">
          404
        </p>
        <h1 className="font-display mt-3 text-4xl font-extrabold">
          Page not found
        </h1>
        <p className="mt-5 leading-7 text-mute">
          That docs route is not in this React app.
        </p>
      </article>
    );
  }

  return (
    <article className="mx-auto max-w-3xl px-8 py-12">
      <h1 className="font-display text-4xl font-extrabold">{page.title}</h1>
      {page.body.map((paragraph) => (
        <p key={paragraph} className="mt-5 leading-7 text-mute">
          {paragraph}
        </p>
      ))}
    </article>
  );
}
