export const docsNav = [
  {
    title: "Quickstart",
    items: [
      ["Upload your first app", "/quickstart/upload-your-first-app"],
      ["Get the bootstrapper", "/quickstart/get-the-bootstrapper"],
      ["Push your first update", "/quickstart/push-your-first-update"],
    ],
  },
  {
    title: "Guides",
    items: [
      ["OTA updates", "/guides/ota-updates"],
      ["Rollout and rollback", "/guides/rollout-and-rollback"],
      ["Private versions", "/guides/private-versions"],
      ["Mini-apps", "/guides/mini-apps"],
      ["CI/CD", "/guides/ci-cd"],
      ["Enterprise SSO", "/guides/enterprise-sso"],
    ],
  },
  {
    title: "Reference",
    items: [
      ["CLI", "/reference/cli"],
      ["API", "/reference/api"],
      ["SDK", "/reference/sdk"],
      ["Webhooks", "/reference/webhooks"],
    ],
  },
  {
    title: "Changelog",
    items: [["Platform versions", "/changelog"]],
  },
] as const;

export const pages: Record<string, { title: string; body: string[] }> = {
  "/": {
    title: "Working app live in under 10 minutes",
    body: [
      "A developer who has never heard of Keltri should have a live bootstrapper APK link within 10 minutes of this page. No credit card. No approval wait. No configuration beyond uploading an APK.",
      "Start with Upload your first app, then generate a bootstrapper, then push an OTA update from the CLI.",
    ],
  },
  "/quickstart/upload-your-first-app": {
    title: "Upload your first app",
    body: [
      "Open the portal, sign in, and drop an APK on the dashboard. The registry extracts the app name, icon, and version number automatically.",
      "Add a short description. The malware scan finishes in under 30 seconds. You now have a private app record — not yet in the public store.",
    ],
  },
  "/quickstart/get-the-bootstrapper": {
    title: "Get the bootstrapper",
    body: [
      "Open the app → Bootstrapper. Download the ~820KB APK or share keltriapps.dev/get/<slug>.",
      "Testers install the bootstrapper once. Later versions arrive over OTA. No Play Store, no TestFlight, no Drive folder.",
    ],
  },
  "/quickstart/push-your-first-update": {
    title: "Push your first update",
    body: [
      "Fix a bug, then run: keltri deploy ./app-release.apk",
      "Testers get the update silently — no re-install. Install count ticks up in the portal in real time.",
    ],
  },
  "/guides/ota-updates": {
    title: "How OTA updates work",
    body: [
      "Phase 1 ships a full-bundle OTA. The bootstrapper (or store app) calls GET /v1/public/apps/:slug/update?current=&device= and downloads the latest APK when newer.",
      "Rollout percent is honored with a stable device-id hash. Delta (bsdiff) patches are planned for a later phase; until then everyone downloads the full APK.",
    ],
  },
  "/guides/rollout-and-rollback": {
    title: "Staged rollouts and instant rollback",
    body: [
      "New versions default to 10% of devices. Use keltri rollout 50% or the slider in Version manager.",
      "If crash rate crosses your threshold, rollout pauses and a crash.spike webhook fires. Rollback restores the previous live version immediately.",
    ],
  },
  "/guides/private-versions": {
    title: "Private app hosting for teams",
    body: [
      "Keep an app private while you iterate. Share bootstrapper links with testers. Toggle to public and submit for store review when the listing is ready.",
      "Team and Enterprise plans include unlimited private apps.",
    ],
  },
  "/guides/mini-apps": {
    title: "Building for try-before-install",
    body: [
      "Add com.quantumapps:miniapp-sdk and declare permissions in the manifest. The sandbox only exposes APIs you list.",
      "Users see a permission summary before Try. The real app runs in the Keltri runtime. Install is one tap because the bundle is already on device.",
    ],
  },
  "/guides/ci-cd": {
    title: "GitHub Actions and GitLab CI",
    body: [
      "Use keltri-apps/deploy@v1 with KELTRI_API_KEY. Set rollout as an input. Pull request preview links post as comments automatically.",
      "The same CLI works in GitLab CI: keltri deploy ./app-release.apk after keltri login.",
    ],
  },
  "/guides/enterprise-sso": {
    title: "SSO and audit logs",
    body: [
      "Enterprise adds SAML/OIDC SSO, audit logs for every version and payout action, and a 99.99% SLA.",
      "Contact sales to enable the workspace.",
    ],
  },
  "/reference/cli": {
    title: "CLI commands",
    body: [
      "npm install -g keltri-cli",
      "keltri login · deploy · preview · rollout · rollback · logs · versions · open",
      "From this monorepo: pnpm --filter keltri-cli start -- deploy ./app-release.apk",
    ],
  },
  "/reference/api": {
    title: "REST API",
    body: [
      "Authorization: Bearer YOUR_API_KEY (CLI) or a qa_sess_* session cookie (portal) against https://api.keltriapps.dev/v1",
      "Auth: POST /auth/register, /auth/login, /auth/logout. GitHub OAuth is not enabled yet. API keys: GET/POST /api-keys, DELETE /api-keys/{id}.",
      "Apps: GET/POST /apps, GET /apps/{id}, POST /apps/{id}/versions/upload-url, POST /apps/{id}/versions/{vid}/finalize, PATCH rollout, POST rollback, GET analytics, GET bootstrapper, POST preview, POST submit, POST review.",
      "Public (no auth): GET /public/catalog, /public/apps/{slug}, /public/developers/{slug}, /public/apps/{slug}/bootstrapper, /public/apps/{slug}/update, /public/apps/{slug}/miniapp.",
      "Local server: http://localhost:4000/v1",
    ],
  },
  "/reference/sdk": {
    title: "Mini-app SDK JS bridge",
    body: [
      "QA.camera, QA.geolocation.getCurrentPosition, QA.pay, QA.storage, QA.notifications, QA.share, QA.biometric.verify.",
      "Declare permissions in AndroidManifest meta-data com.quantumapps.PERMISSIONS.",
    ],
  },
  "/reference/webhooks": {
    title: "Webhook payloads",
    body: [
      "Events: version.published, version.rolled_back, rollout.paused, review.approved, review.rejected, payout.processed, crash.spike.",
      "Retries: 8 attempts, exponential backoff. Configure under Settings → Webhooks in the portal.",
    ],
  },
  "/changelog": {
    title: "Changelog",
    body: [
      "0.1.0 — Monorepo foundation: public store, developer site, portal, REST API, CLI, SDK stubs, docs.",
      "0.2.0 — Phase 1 + store launch: email auth, APK upload, bootstrapper + full-bundle OTA, review pipeline, public catalog, Android Try WebView.",
      "Later: delta patch OTA (bsdiff), paid tiers and billing.",
    ],
  },
};
