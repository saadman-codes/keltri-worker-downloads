import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "VITE_");
  const api = env.VITE_API_URL || "http://localhost:4000";

  return {
    plugins: [react()],
    envPrefix: "VITE_",
    server: {
      port: 3002,
      strictPort: true,
      proxy: {
        "/v1": { target: api, changeOrigin: true },
      },
    },
    preview: {
      port: 3002,
      strictPort: true,
      proxy: {
        "/v1": { target: api, changeOrigin: true },
      },
    },
  };
});
