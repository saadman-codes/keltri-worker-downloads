export type Json = Record<string, unknown>;
export type GitTarget = { projectId?: string; organizationId?: string };
export type GitStatus = {
  configured: boolean; canManage: boolean;
  diagnostics?: {
    appId: string; clientId: string; slug: string; apiOrigin: string; callbackUrl: string;
    clientSecretLength: number; clientSecretFingerprint: string; privateKeyFingerprint: string;
  };
  installations: Array<{ id: string; accountLogin: string; accountType: string; suspended: boolean; repositoryCount: number; manageUrl: string }>;
};

export type ClientOptions = {
  apiKey?: string | (() => string);
  baseUrl?: string;
  credentials?: RequestCredentials;
};

function defaultBaseUrl() {
  return process.env.KELTRI_API_URL ?? "http://localhost:4000";
}

function resolveApiKey(apiKey: ClientOptions["apiKey"]) {
  if (typeof apiKey === "function") return apiKey();
  return apiKey ?? "";
}

export function createClient(
  apiKeyOrOptions: string | ClientOptions = "",
  baseUrlArg?: string,
) {
  const options: ClientOptions =
    typeof apiKeyOrOptions === "string"
      ? { apiKey: apiKeyOrOptions, baseUrl: baseUrlArg }
      : apiKeyOrOptions;
  const baseUrl = options.baseUrl ?? defaultBaseUrl();
  const credentials = options.credentials;

  async function request<T>(path: string, init?: RequestInit): Promise<T> {
    const headers = new Headers(init?.headers);
    const apiKey = resolveApiKey(options.apiKey);
    if (apiKey) headers.set("Authorization", `Bearer ${apiKey}`);
    if (init?.body && !headers.has("Content-Type")) {
      headers.set("Content-Type", "application/json");
    }
    const response = await fetch(`${baseUrl}${path}`, {
      ...init,
      headers,
      credentials,
    });
    const payload = (await response.json().catch(() => ({}))) as {
      data?: T;
      error?: unknown;
    };
    if (!response.ok) {
      throw new Error(
        typeof payload.error === "string" ? payload.error : "Request failed",
      );
    }
    return payload.data as T;
  }

  // For endpoints that return raw bytes, not the {data}/{error} envelope
  // (e.g. blob content) — caller reads the body itself.
  async function requestRaw(path: string, init?: RequestInit): Promise<Response> {
    const headers = new Headers(init?.headers);
    const apiKey = resolveApiKey(options.apiKey);
    if (apiKey) headers.set("Authorization", `Bearer ${apiKey}`);
    const response = await fetch(`${baseUrl}${path}`, {
      ...init,
      headers,
      credentials,
    });
    if (!response.ok) throw new Error(`Request failed (${response.status})`);
    return response;
  }

  return {
    request,
    me: () => request("/v1/me"),
    dashboard: () => request("/v1/dashboard"),
    payouts: () => request("/v1/payouts"),
    reviewQueue: () => request("/v1/review"),
    reviewLive: () => request("/v1/review/live"),
    apiKeys: {
      list: () => request("/v1/api-keys"),
      create: (name: string) =>
        request("/v1/api-keys", {
          method: "POST",
          body: JSON.stringify({ name }),
        }),
      revoke: (id: string) =>
        request(`/v1/api-keys/${id}`, { method: "DELETE" }),
    },
    apps: {
      list: () => request("/v1/apps"),
      get: (id: string) => request(`/v1/apps/${id}`),
      create: (body: Json) =>
        request("/v1/apps", { method: "POST", body: JSON.stringify(body) }),
      versions: (id: string) => request(`/v1/apps/${id}/versions`),
      uploadUrl: (id: string, body: Json = {}) =>
        request<{ versionId: string; uploadUrl: string; uploadToken: string }>(
          `/v1/apps/${id}/versions/upload-url`,
          { method: "POST", body: JSON.stringify(body) },
        ),
      finalize: (id: string, vid: string, body: Json = {}) =>
        request(`/v1/apps/${id}/versions/${vid}/finalize`, {
          method: "POST",
          body: JSON.stringify(body),
        }),
      rollout: (id: string, vid: string, body: Json) =>
        request(`/v1/apps/${id}/versions/${vid}`, {
          method: "PATCH",
          body: JSON.stringify(body),
        }),
      rollback: (id: string) =>
        request(`/v1/apps/${id}/rollback`, { method: "POST" }),
      analytics: (id: string) => request(`/v1/apps/${id}/analytics`),
      bootstrapper: (id: string) => request(`/v1/apps/${id}/bootstrapper`),
      preview: (id: string) =>
        request(`/v1/apps/${id}/preview`, { method: "POST" }),
      updateListing: (id: string, body: Json) =>
        request(`/v1/apps/${id}/listing`, {
          method: "PATCH",
          body: JSON.stringify(body),
        }),
      submit: (id: string) =>
        request(`/v1/apps/${id}/submit`, { method: "POST" }),
      review: (id: string, body: { decision: string; note?: string }) =>
        request(`/v1/apps/${id}/review`, {
          method: "POST",
          body: JSON.stringify(body),
        }),
      unpublish: (id: string, body: { note?: string } = {}) =>
        request(`/v1/apps/${id}/unpublish`, {
          method: "POST",
          body: JSON.stringify(body),
        }),
    },
    projects: {
      list: () => request("/v1/projects"),
      get: (id: string) => request(`/v1/projects/${id}`),
      create: (body: Json) =>
        request("/v1/projects", {
          method: "POST",
          body: JSON.stringify(body),
        }),
      analytics: (id: string) => request(`/v1/projects/${id}/analytics`),
      team: {
        list: (id: string) => request(`/v1/projects/${id}/team`),
        invite: (id: string, body: { email: string; role?: string }) =>
          request(`/v1/projects/${id}/team`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
        remove: (id: string, memberId: string) =>
          request(`/v1/projects/${id}/team/${memberId}`, {
            method: "DELETE",
          }),
      },
      services: {
        build: (id: string, serviceId: string) => request<{ deploymentId: string }>(`/v1/projects/${id}/services/${serviceId}/builds`, { method: "POST" }),
        buildLog: (id: string, serviceId: string, deploymentId: string) => request<{ status: string; logs: string; branch: string; commitSha: string } | null>(`/v1/projects/${id}/services/${serviceId}/builds/${deploymentId}`),
        list: (id: string) => request(`/v1/projects/${id}/services`),
        get: (id: string, serviceId: string) =>
          request(`/v1/projects/${id}/services/${serviceId}`),
        create: (id: string, body: Json) =>
          request(`/v1/projects/${id}/services`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
        uploadUrl: (id: string, serviceId: string, body: Json = {}) =>
          request<{
            deploymentId: string;
            uploadUrl: string;
            uploadToken: string;
          }>(`/v1/projects/${id}/services/${serviceId}/deployments/upload-url`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
        finalize: (id: string, serviceId: string, deploymentId: string) =>
          request(
            `/v1/projects/${id}/services/${serviceId}/deployments/${deploymentId}/finalize`,
            { method: "POST" },
          ),
        recordDeployment: (id: string, serviceId: string, body: Json = {}) =>
          request(`/v1/projects/${id}/services/${serviceId}/deployments`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
        promote: (id: string, serviceId: string, deploymentId: string) =>
          request(
            `/v1/projects/${id}/services/${serviceId}/deployments/${deploymentId}/promote`,
            { method: "POST" },
          ),
        rollback: (id: string, serviceId: string) =>
          request(`/v1/projects/${id}/services/${serviceId}/rollback`, {
            method: "POST",
          }),
        envList: (id: string, serviceId: string) =>
          request(`/v1/projects/${id}/services/${serviceId}/env`),
        envSet: (id: string, serviceId: string, body: Json) =>
          request(`/v1/projects/${id}/services/${serviceId}/env`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
        envDelete: (id: string, serviceId: string, envId: string) =>
          request(`/v1/projects/${id}/services/${serviceId}/env/${envId}`, {
            method: "DELETE",
          }),
        envResolved: (id: string, serviceId: string, target: "production" | "preview") =>
          request<Record<string, string>>(
            `/v1/projects/${id}/services/${serviceId}/env/resolved?target=${target}`,
          ),
        flags: {
          list: (id: string, serviceId: string) =>
            request(`/v1/projects/${id}/services/${serviceId}/flags`),
          set: (id: string, serviceId: string, body: Json) =>
            request(`/v1/projects/${id}/services/${serviceId}/flags`, {
              method: "POST",
              body: JSON.stringify(body),
            }),
          remove: (id: string, serviceId: string, flagId: string) =>
            request(`/v1/projects/${id}/services/${serviceId}/flags/${flagId}`, {
              method: "DELETE",
            }),
        },
        domains: {
          list: (id: string, serviceId: string) =>
            request(`/v1/projects/${id}/services/${serviceId}/domains`),
          create: (id: string, serviceId: string, body: { hostname: string }) =>
            request(`/v1/projects/${id}/services/${serviceId}/domains`, {
              method: "POST",
              body: JSON.stringify(body),
            }),
          remove: (id: string, serviceId: string, domainId: string) =>
            request(`/v1/projects/${id}/services/${serviceId}/domains/${domainId}`, {
              method: "DELETE",
            }),
        },
        gitLink: (id: string, serviceId: string, body: { repoFullName: string; defaultBranch: string; installationId: string; repositoryId: string }) =>
          request(`/v1/projects/${id}/services/${serviceId}/git-link`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
      },
    },
    git: {
      start: (body: GitTarget & { returnTo: string; clientProof: string; installationId?: string; mode?: "connect" | "install" }) =>
        request<{ flowId: string; url: string }>("/v1/git/connect", { method: "POST", body: JSON.stringify(body) }),
      complete: (body: { flowId: string; code: string; clientProof: string; installationId?: string }) =>
        request<{ returnTo: string; organizationId: string | null; installations?: Array<{ installationId: string; accountLogin: string; accountType: string }> }>("/v1/git/complete", { method: "POST", body: JSON.stringify(body) }),
      status: (target: GitTarget = {}) => request<GitStatus>(`/v1/git/status?${new URLSearchParams(target).toString()}`),
      disconnect: (body: GitTarget & { installationId: string }) => request("/v1/git/disconnect", { method: "POST", body: JSON.stringify(body) }),
      repos: (target: GitTarget = {}) =>
        request<
          Array<{
            id: number;
            name: string;
            fullName: string;
            defaultBranch: string;
            private: boolean;
            updatedAt: string;
            installationId: string;
          }>
        >(`/v1/git/repos?${new URLSearchParams(target).toString()}`),
      detect: (installationId: string, repositoryId: string, target: GitTarget = {}) =>
        request<{
          defaultBranch: string;
          detectedFramework: string;
          buildCommand: string | null;
          outputDir: string | null;
          startCommand: string | null;
        }>(`/v1/git/installations/${encodeURIComponent(installationId)}/repositories/${encodeURIComponent(repositoryId)}/detect?${new URLSearchParams(target).toString()}`),
    },
    organizations: {
      list: () => request("/v1/organizations"),
      get: (id: string) => request(`/v1/organizations/${id}`),
      create: (body: { name: string }) =>
        request("/v1/organizations", {
          method: "POST",
          body: JSON.stringify(body),
        }),
      members: {
        list: (id: string) => request(`/v1/organizations/${id}/members`),
        invite: (id: string, body: { email: string; role?: string }) =>
          request(`/v1/organizations/${id}/members`, {
            method: "POST",
            body: JSON.stringify(body),
          }),
        remove: (id: string, memberId: string) =>
          request(`/v1/organizations/${id}/members/${memberId}`, {
            method: "DELETE",
          }),
      },
    },
    auditLog: {
      list: (params?: { page?: number; pageSize?: number }) =>
        request(
          `/v1/audit-log?page=${params?.page ?? 1}&pageSize=${params?.pageSize ?? 50}`,
        ),
    },
    blobs: {
      list: () => request("/v1/blobs"),
      put: (key: string, body: BodyInit, contentType = "application/octet-stream") =>
        request(`/v1/blobs/${key}`, {
          method: "PUT",
          body,
          headers: { "Content-Type": contentType },
        }),
      get: (key: string) => requestRaw(`/v1/blobs/${key}`),
      delete: (key: string) =>
        request(`/v1/blobs/${key}`, { method: "DELETE" }),
    },
    webhooks: {
      list: () => request("/v1/webhooks"),
      create: (body: { url: string; events?: string[] }) =>
        request("/v1/webhooks", {
          method: "POST",
          body: JSON.stringify(body),
        }),
      delete: (id: string) =>
        request(`/v1/webhooks/${id}`, { method: "DELETE" }),
    },
    public: {
      catalog: () => request("/v1/public/catalog"),
      app: (slug: string) => request(`/v1/public/apps/${slug}`),
      developer: (slug: string) =>
        request(`/v1/public/developers/${slug}`),
      flags: (
        projectSlug: string,
        serviceSlug: string,
        target?: "production" | "preview",
        bucket?: string,
      ) => {
        const params = new URLSearchParams();
        if (target) params.set("target", target);
        if (bucket) params.set("bucket", bucket);
        const qs = params.toString();
        return request<Record<string, boolean>>(
          `/v1/public/flags/${projectSlug}/${serviceSlug}${qs ? `?${qs}` : ""}`,
        );
      },
    },
  };
}

export type QuantumClient = ReturnType<typeof createClient>;
