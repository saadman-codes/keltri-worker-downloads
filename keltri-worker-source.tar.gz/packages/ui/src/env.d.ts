interface ImportMetaEnv {
  readonly VITE_WEB_URL?: string;
  readonly VITE_DOCS_URL?: string;
  readonly VITE_API_URL?: string;
  readonly VITE_GITHUB_AUTH?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
