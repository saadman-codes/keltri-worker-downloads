// Console (formerly its own apps/portal deployment) now lives at
// `${sites.web}/console` — there is no separate console origin anymore.
export const sites = {
  web: import.meta.env.VITE_WEB_URL || "http://localhost:3000",
  docs: import.meta.env.VITE_DOCS_URL || "http://localhost:3002",
  api: import.meta.env.VITE_API_URL || "http://localhost:4000",
};
