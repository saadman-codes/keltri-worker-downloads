import type { SVGProps } from "react";

export function Logo({ className, ...props }: SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={className}
      aria-hidden="true"
      {...props}
    >
      <rect width="32" height="32" rx="8" fill="var(--color-ink-2)" />
      <path
        d="M16 7.5a8.5 8.5 0 1 0 6.2 14.4L26 26"
        fill="none"
        stroke="var(--color-signal)"
        strokeWidth="2.3"
        strokeLinecap="round"
      />
      <circle cx="16" cy="16" r="2.2" fill="var(--color-signal)" />
    </svg>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-2 whitespace-nowrap ${className ?? ""}`}>
      <Logo className="h-7 w-7" />
      <span className="font-display whitespace-nowrap text-[15px] font-semibold tracking-tight">
        Keltri
      </span>
    </span>
  );
}
