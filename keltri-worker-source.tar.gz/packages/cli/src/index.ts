#!/usr/bin/env node
import { createClient } from "@keltri/api-client";
import JSZip from "jszip";
import { readdir, readFile, writeFile } from "node:fs/promises";
import { basename, join, relative } from "node:path";

function isLocalApi(url: string) {
  try {
    const { hostname } = new URL(url);
    return hostname === "localhost" || hostname === "127.0.0.1";
  } catch {
    return false;
  }
}

function resolveApiKey() {
  if (process.env.KELTRI_API_KEY) return process.env.KELTRI_API_KEY;
  const apiUrl = process.env.KELTRI_API_URL ?? "http://localhost:4000";
  if (isLocalApi(apiUrl)) return "qa_dev_seed_key";
  throw new Error(
    "KELTRI_API_KEY is required. The local demo key is not used against remote APIs.",
  );
}

const client = createClient({
  apiKey: resolveApiKey,
  baseUrl: process.env.KELTRI_API_URL,
});
const rawArgs = process.argv.slice(2);
const [command, ...args] = rawArgs[0] === "--" ? rawArgs.slice(1) : rawArgs;

async function pickApp() {
  const slug = process.env.KELTRI_APP_SLUG;
  const apps = (await client.apps.list()) as Array<{
    id: string;
    name: string;
    slug: string;
  }>;
  const app = slug ? apps.find((item) => item.slug === slug) : apps[0];
  if (!app) throw new Error("No apps on this account");
  return app;
}

function flag(args: string[], name: string) {
  const index = args.indexOf(name);
  return index >= 0 ? args[index + 1] : undefined;
}

async function pickProject(args: string[]) {
  const slug = flag(args, "--project") ?? process.env.KELTRI_PROJECT_SLUG;
  if (!slug) {
    throw new Error(
      "Pass --project <slug> or set KELTRI_PROJECT_SLUG",
    );
  }
  const projects = (await client.projects.list()) as Array<{
    id: string;
    slug: string;
  }>;
  const project = projects.find((item) => item.slug === slug);
  if (!project) throw new Error(`No project with slug "${slug}"`);
  return project;
}

// A Project can own more than one Service (Projects -> Services pivot) --
// every deploy/env-pull call needs to know which one, same as --project
// disambiguates which Project.
async function pickService(args: string[], projectId: string) {
  const slug = flag(args, "--service") ?? process.env.KELTRI_SERVICE_SLUG;
  if (!slug) {
    throw new Error("Pass --service <slug> or set KELTRI_SERVICE_SLUG");
  }
  const services = (await client.projects.services.list(projectId)) as Array<{
    id: string;
    slug: string;
  }>;
  const service = services.find((item) => item.slug === slug);
  if (!service) throw new Error(`No service with slug "${slug}" in this project`);
  return service;
}

// Recursively zips a build-output directory the same shape the console's
// own upload form produces (relative paths, no leading slash) so it
// extracts identically on the server (see server/src/deploy.ts).
async function zipDirectory(dir: string) {
  const zip = new JSZip();

  async function walk(current: string) {
    for (const entry of await readdir(current, { withFileTypes: true })) {
      const full = join(current, entry.name);
      if (entry.isDirectory()) {
        await walk(full);
      } else if (entry.isFile()) {
        const data = await readFile(full);
        zip.file(relative(dir, full), data);
      }
    }
  }

  await walk(dir);
  return zip.generateAsync({ type: "nodebuffer" });
}

async function main() {
  console.log("\n  Keltri CLI v0.1.0\n");

  switch (command) {
    case "login":
      console.log("  Using KELTRI_API_KEY from the environment.");
      await client.me();
      console.log("  ✔  Authenticated\n");
      break;
    case "deploy": {
      const filePath = args[0];
      if (!filePath) throw new Error("Usage: keltri deploy ./app-release.apk");
      const app = await pickApp();
      const body = await readFile(filePath);
      const created = await client.apps.uploadUrl(app.id, {
        versionName: new Date().toISOString().slice(11, 19).replaceAll(":", ""),
        versionCode: Date.now() % 1_000_000,
        releaseNotes: `Deployed ${basename(filePath)}`,
      });
      const put = await fetch(created.uploadUrl, {
        method: "PUT",
        headers: {
          "Content-Type": "application/vnd.android.package-archive",
        },
        body,
      });
      if (!put.ok) throw new Error(`Upload failed (${put.status})`);
      const version = await client.apps.finalize(app.id, created.versionId, {
        releaseNotes: `Deployed ${basename(filePath)}`,
      });
      console.log("  ✔  APK uploaded and hashed");
      console.log("  ✔  Manifest parsed");
      console.log("  ✔  Malware scan queued");
      console.log(`  ✔  Version uploaded for ${app.name}`);
      console.log("\n  Rolling out to 10% of users (default)");
      console.log("  Change with: keltri rollout <percent>\n");
      console.log(version);
      break;
    }
    case "deploy-project": {
      const dirPath = args[0];
      if (!dirPath) {
        throw new Error(
          "Usage: keltri deploy-project ./dist --project <slug> --service <slug> [--promote]",
        );
      }
      const project = await pickProject(args);
      const service = await pickService(args, project.id);
      const apiOrigin = process.env.KELTRI_API_URL ?? "http://localhost:4000";
      const promote = args.includes("--promote");
      const commitRef = process.env.GITHUB_SHA?.slice(0, 8);

      const buffer = await zipDirectory(dirPath);
      const created = await client.projects.services.uploadUrl(project.id, service.id, {
        commitRef,
      });
      const put = await fetch(created.uploadUrl, {
        method: "PUT",
        headers: { "Content-Type": "application/zip" },
        body: buffer,
      });
      if (!put.ok) throw new Error(`Upload failed (${put.status})`);
      const deployment = (await client.projects.services.finalize(
        project.id,
        service.id,
        created.deploymentId,
      )) as { id: string; fileCount: number; secretScanStatus: string };

      console.log(`  ✔  Deployed ${deployment.fileCount} files`);
      console.log(
        `  Preview: ${apiOrigin}/v1/public/deploy/d/${deployment.id}/`,
      );
      if (deployment.secretScanStatus === "flagged") {
        console.log(
          "  ⚠  Possible secrets found in this build — check the console.",
        );
      }

      if (promote) {
        await client.projects.services.promote(project.id, service.id, deployment.id);
        console.log(
          `  ✔  Promoted: ${apiOrigin}/v1/public/deploy/p/${project.slug}/${service.slug}/`,
        );
      }
      break;
    }
    case "env-pull": {
      const project = await pickProject(args);
      const service = await pickService(args, project.id);
      const target = flag(args, "--target") ?? "production";
      if (target !== "production" && target !== "preview") {
        throw new Error("--target must be 'production' or 'preview'");
      }
      const vars = await client.projects.services.envResolved(project.id, service.id, target);
      const lines = Object.entries(vars).map(([key, value]) => `${key}=${value}`);
      const outFile = flag(args, "--out");
      if (outFile) {
        await writeFile(outFile, lines.join("\n") + "\n");
        console.log(`  ✔  Wrote ${lines.length} vars to ${outFile}`);
      } else {
        console.log(lines.join("\n"));
      }
      break;
    }
    case "blob-put": {
      const key = args[0];
      const filePath = args[1];
      if (!key || !filePath) {
        throw new Error("Usage: keltri blob-put <key> <file>");
      }
      const body = await readFile(filePath);
      const entry = (await client.blobs.put(key, new Uint8Array(body))) as {
        key: string;
        sizeBytes: number;
      };
      console.log(`  ✔  Stored ${entry.key} (${entry.sizeBytes} bytes)`);
      break;
    }
    case "blob-get": {
      const key = args[0];
      const outFile = args[1];
      if (!key || !outFile) {
        throw new Error("Usage: keltri blob-get <key> <out-file>");
      }
      const response = await client.blobs.get(key);
      const buffer = Buffer.from(await response.arrayBuffer());
      await writeFile(outFile, buffer);
      console.log(`  ✔  Wrote ${buffer.byteLength} bytes to ${outFile}`);
      break;
    }
    case "blob-list": {
      const list = (await client.blobs.list()) as Array<{
        key: string;
        contentType: string;
        sizeBytes: number;
      }>;
      for (const entry of list) {
        console.log(`  ${entry.key}\t${entry.sizeBytes}b\t${entry.contentType}`);
      }
      break;
    }
    case "blob-rm": {
      const key = args[0];
      if (!key) throw new Error("Usage: keltri blob-rm <key>");
      await client.blobs.delete(key);
      console.log(`  ✔  Deleted ${key}`);
      break;
    }
    case "preview": {
      const app = await pickApp();
      const preview = await client.apps.preview(app.id);
      console.log("  Preview link generated");
      console.log(preview);
      break;
    }
    case "rollout": {
      const percent = Number(String(args[0] ?? "10").replace("%", ""));
      const app = await pickApp();
      const versions = (await client.apps.versions(app.id)) as Array<{
        id: string;
      }>;
      await client.apps.rollout(app.id, versions[0].id, {
        rolloutPercent: percent,
      });
      console.log(`  ✔  Rollout set to ${percent}%`);
      break;
    }
    case "rollback": {
      const app = await pickApp();
      await client.apps.rollback(app.id);
      console.log("  ✔  Rolled back to previous version");
      break;
    }
    case "logs":
      console.log("  Tailing crash reports… (demo)");
      console.log("  14:02  MyApp  NullPointerException  v1.2  12 devices");
      break;
    case "versions": {
      const app = await pickApp();
      const versions = await client.apps.versions(app.id);
      console.log(`  ${app.name}`);
      console.log(versions);
      break;
    }
    case "open":
      console.log("  http://localhost:3000/console");
      break;
    default:
      console.log(
        `  Commands: login deploy deploy-project env-pull blob-put blob-get blob-list blob-rm preview rollout rollback logs versions open`,
      );
      console.log(`  Example:  keltri deploy ./app-release.apk`);
      console.log(
        `  Example:  keltri deploy-project ./dist --project my-site --service web --promote`,
      );
      console.log(
        `  Example:  keltri env-pull --project my-site --service web --target production --out .env\n`,
      );
  }
}

main().catch((error) => {
  console.error(`  ✖  ${error instanceof Error ? error.message : error}`);
  process.exit(1);
});
