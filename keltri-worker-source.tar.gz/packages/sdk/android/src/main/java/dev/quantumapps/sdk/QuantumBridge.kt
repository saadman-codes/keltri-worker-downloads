package dev.quantumapps.sdk

import android.content.Context
import android.content.Intent
import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * JS bridge injected as `window.QuantumBridge` / `window.QA`.
 * Only methods listed in [allowed] are callable.
 */
class QuantumBridge(
    private val context: Context,
    private val allowed: Set<String>,
) {
    private val prefs = context.getSharedPreferences("qa_miniapp", Context.MODE_PRIVATE)

    @JavascriptInterface
    fun invoke(name: String, payloadJson: String?): String {
        val method = name.substringBefore(".")
        if (method !in allowed && name !in allowed) {
            return JSONObject()
                .put("error", "permission_denied")
                .put("method", name)
                .toString()
        }
        val payload = runCatching { JSONObject(payloadJson ?: "{}") }.getOrElse { JSONObject() }
        val result = when (name) {
            "storage.set" -> {
                prefs.edit().putString(payload.optString("key"), payload.optString("value")).apply()
                JSONObject().put("ok", true)
            }
            "storage.get" -> JSONObject().put("value", prefs.getString(payload.optString("key"), JSONObject.NULL.toString()))
            "share" -> {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, payload.optString("title"))
                    putExtra(Intent.EXTRA_TEXT, payload.optString("text", payload.optString("url")))
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(send, payload.optString("title")))
                JSONObject().put("ok", true)
            }
            "camera" -> JSONObject().put("uri", "content://dev.quantumapps.sdk/stub-camera")
            "geolocation.getCurrentPosition" -> JSONObject().put("lat", 0.0).put("lng", 0.0)
            "pay" -> JSONObject().put("status", "canceled")
            "notifications.requestPermission" -> JSONObject().put("ok", true)
            "notifications.schedule" -> JSONObject().put("ok", true)
            "biometric.verify" -> JSONObject().put("ok", true)
            else -> JSONObject().put("error", "unknown_method").put("method", name)
        }
        return result.toString()
    }

    companion object {
        const val JS_OBJECT = "AndroidBridge"

        fun bootstrapScript(): String = """
            (function() {
              window.QuantumBridge = {
                invoke: function(name, payload) {
                  var raw = AndroidBridge.invoke(name, JSON.stringify(payload || {}));
                  try { return Promise.resolve(JSON.parse(raw)); }
                  catch (e) { return Promise.resolve(raw); }
                }
              };
              window.QA = {
                camera: function(options) { return window.QuantumBridge.invoke('camera', options); },
                geolocation: {
                  getCurrentPosition: function() {
                    return window.QuantumBridge.invoke('geolocation.getCurrentPosition');
                  }
                },
                pay: function(input) { return window.QuantumBridge.invoke('pay', input); },
                storage: {
                  set: function(key, value) {
                    return window.QuantumBridge.invoke('storage.set', { key: key, value: value });
                  },
                  get: function(key) { return window.QuantumBridge.invoke('storage.get', { key: key }); }
                },
                notifications: {
                  requestPermission: function() {
                    return window.QuantumBridge.invoke('notifications.requestPermission');
                  },
                  schedule: function(input) {
                    return window.QuantumBridge.invoke('notifications.schedule', input);
                  }
                },
                share: function(input) { return window.QuantumBridge.invoke('share', input); },
                biometric: {
                  verify: function(input) { return window.QuantumBridge.invoke('biometric.verify', input); }
                }
              };
            })();
        """.trimIndent()
    }
}
