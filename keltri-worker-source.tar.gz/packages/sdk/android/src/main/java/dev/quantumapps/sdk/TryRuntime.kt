package dev.quantumapps.sdk

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

object TryRuntime {
    @SuppressLint("SetJavaScriptEnabled")
    fun attach(
        webView: WebView,
        bridge: QuantumBridge,
        url: String,
    ) {
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.addJavascriptInterface(bridge, QuantumBridge.JS_OBJECT)
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, loaded: String) {
                view.evaluateJavascript(QuantumBridge.bootstrapScript(), null)
            }
        }
        webView.loadUrl(url)
    }
}
