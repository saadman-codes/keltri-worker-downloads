# Mini-app SDK

Open source, MIT. Intended future repo: `github.com/keltri-apps/miniapp-sdk`.

```kotlin
// build.gradle (app)
dependencies {
    implementation("com.quantumapps:miniapp-sdk:1.0.0")
}
```

```xml
<meta-data
    android:name="com.quantumapps.PERMISSIONS"
    android:value="camera,geolocation,payments,notifications" />
```

The Kotlin implementation lives in `android/` (`QuantumBridge`, `TryRuntime`) and is included by `mobile/store`. The JS bridge lives in `js/index.ts` (`QA.camera`, `QA.pay`, …). The sandbox only exposes APIs declared for the listing.
