export type Permission =
  | "camera"
  | "geolocation"
  | "payments"
  | "notifications"
  | "storage"
  | "share"
  | "biometric";

async function call<T>(name: string, payload?: unknown): Promise<T> {
  const bridge = (
    globalThis as {
      QuantumBridge?: { invoke: (name: string, payload?: unknown) => Promise<T> };
    }
  ).QuantumBridge;

  if (!bridge) {
    throw new Error(`${name} is only available inside the Keltri mini-app runtime`);
  }

  return bridge.invoke(name, payload);
}

export const QA = {
  camera: (options?: { quality?: "low" | "high" }) =>
    call<{ uri: string }>("camera", options),
  geolocation: {
    getCurrentPosition: () =>
      call<{ lat: number; lng: number }>("geolocation.getCurrentPosition"),
  },
  pay: (input: { amount: number; currency: string; description: string }) =>
    call<{ status: "succeeded" | "canceled" }>("pay", input),
  storage: {
    set: (key: string, value: string) => call<void>("storage.set", { key, value }),
    get: (key: string) => call<string | null>("storage.get", { key }),
  },
  notifications: {
    requestPermission: () => call<boolean>("notifications.requestPermission"),
    schedule: (input: { title: string; body: string; delay: number }) =>
      call<void>("notifications.schedule", input),
  },
  share: (input: { title: string; url: string }) => call<void>("share", input),
  biometric: {
    verify: (input: { reason: string }) =>
      call<boolean>("biometric.verify", input),
  },
};

export default QA;
