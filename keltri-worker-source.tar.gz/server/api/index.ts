import { handle } from "hono/vercel";
import { app } from "../src/app.js";

export const runtime = "nodejs";

// Vercel's Node.js runtime only uses the Fetch-API calling convention
// (a Request in, a Response out) when it recognizes named HTTP-method
// exports, the same convention Next.js route handlers use. A bare
// `export default handle(app)` gets invoked with the legacy Node
// (req, res) signature instead, which breaks hono/vercel's handle() —
// it assumes a real Fetch Request and calls req.headers.get(), which
// doesn't exist on a Node IncomingMessage. The Hono app already
// dispatches by method internally, so the same handler covers all of them.
const handler = handle(app);

export {
  handler as GET,
  handler as POST,
  handler as PUT,
  handler as PATCH,
  handler as DELETE,
  handler as OPTIONS,
  handler as HEAD,
};
