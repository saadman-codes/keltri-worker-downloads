CREATE TABLE "GitHubInstallation" (
  "id" TEXT NOT NULL,
  "installationId" TEXT NOT NULL,
  "scopeKey" TEXT NOT NULL,
  "developerId" TEXT NOT NULL,
  "organizationId" TEXT,
  "githubUserId" TEXT NOT NULL,
  "accountLogin" TEXT NOT NULL,
  "accountType" TEXT NOT NULL,
  "repositoryIds" TEXT[] NOT NULL,
  "suspended" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "GitHubInstallation_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "GitHubInstallation_scope_check" CHECK (
    ("organizationId" IS NULL AND "scopeKey" = 'developer:' || "developerId") OR
    ("organizationId" IS NOT NULL AND "scopeKey" = 'organization:' || "organizationId")
  )
);
CREATE UNIQUE INDEX "GitHubInstallation_installationId_key" ON "GitHubInstallation"("installationId");
CREATE INDEX "GitHubInstallation_scopeKey_idx" ON "GitHubInstallation"("scopeKey");
ALTER TABLE "GitHubInstallation" ADD CONSTRAINT "GitHubInstallation_developerId_fkey" FOREIGN KEY ("developerId") REFERENCES "Developer"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "GitHubInstallation" ADD CONSTRAINT "GitHubInstallation_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "GitHubConnectAttempt" (
  "id" TEXT NOT NULL,
  "stateHash" TEXT NOT NULL,
  "browserHash" TEXT NOT NULL,
  "clientHash" TEXT NOT NULL,
  "developerId" TEXT NOT NULL,
  "organizationId" TEXT,
  "scopeKey" TEXT NOT NULL,
  "returnTo" TEXT NOT NULL,
  "phase" TEXT NOT NULL,
  "installationId" TEXT,
  "verifier" TEXT,
  "result" JSONB,
  "expiresAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "GitHubConnectAttempt_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "GitHubConnectAttempt_stateHash_key" ON "GitHubConnectAttempt"("stateHash");
CREATE INDEX "GitHubConnectAttempt_expiresAt_idx" ON "GitHubConnectAttempt"("expiresAt");
ALTER TABLE "GitHubConnectAttempt" ADD CONSTRAINT "GitHubConnectAttempt_developerId_fkey" FOREIGN KEY ("developerId") REFERENCES "Developer"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "GitHubConnectAttempt" ADD CONSTRAINT "GitHubConnectAttempt_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "ServiceGitLink" ADD COLUMN "githubInstallationId" TEXT, ADD COLUMN "githubRepositoryId" TEXT;
ALTER TABLE "ServiceGitLink" ADD CONSTRAINT "ServiceGitLink_githubInstallationId_fkey" FOREIGN KEY ("githubInstallationId") REFERENCES "GitHubInstallation"("id") ON DELETE SET NULL ON UPDATE CASCADE;
-- Old OAuth repository tokens are no longer used by the integration.
UPDATE "Developer" SET "githubRepoToken" = NULL;
