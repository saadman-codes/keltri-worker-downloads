-- AlterTable
ALTER TABLE "Deployment" ADD COLUMN     "promotedAt" TIMESTAMP(3);
