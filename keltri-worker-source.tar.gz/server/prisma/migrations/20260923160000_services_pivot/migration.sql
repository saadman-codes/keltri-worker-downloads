-- Projects -> Services IA pivot. This is the first migration in this
-- repo's history with a hand-authored data-backfill step (every prior
-- migration was pure DDL): every existing Project gets exactly one
-- Service (slug "default", type copied from the old surface column),
-- and every Deployment/EnvVar/FeatureFlag/Domain row is repointed from
-- projectId onto that Service's id, before the new column is made
-- NOT NULL and the old column is dropped.

-- 1. New tables first (Service before ServiceGitLink, which references it).
CREATE TABLE "Service" (
    "id" TEXT NOT NULL,
    "projectId" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "buildCommand" TEXT,
    "startCommand" TEXT,
    "outputDir" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Service_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "ServiceGitLink" (
    "id" TEXT NOT NULL,
    "serviceId" TEXT NOT NULL,
    "repoFullName" TEXT NOT NULL,
    "defaultBranch" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ServiceGitLink_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "Service" ADD CONSTRAINT "Service_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ServiceGitLink" ADD CONSTRAINT "ServiceGitLink_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE INDEX "Service_projectId_idx" ON "Service"("projectId");
CREATE UNIQUE INDEX "Service_projectId_slug_key" ON "Service"("projectId", "slug");
CREATE UNIQUE INDEX "ServiceGitLink_serviceId_key" ON "ServiceGitLink"("serviceId");

-- 2. Developer.githubRepoToken -- nullable, no backfill needed.
ALTER TABLE "Developer" ADD COLUMN "githubRepoToken" TEXT;

-- 3. Backfill: one Service per existing Project, id via gen_random_uuid()
-- since this is a raw INSERT (Prisma's cuid() default is applied
-- client-side, not available to plain SQL). "default" is guaranteed
-- unique per project since it's the only Service that project has yet.
INSERT INTO "Service" ("id", "projectId", "slug", "name", "type", "buildCommand", "startCommand", "outputDir", "createdAt", "updatedAt")
SELECT gen_random_uuid()::text, "id", 'default', "name", "surface", "buildCommand", "startCommand", NULL, "createdAt", "updatedAt"
FROM "Project";

-- 4. Add serviceId as nullable first so the backfill UPDATE below can run,
-- then repoint every dependent row, then tighten to NOT NULL.
ALTER TABLE "Deployment" ADD COLUMN "serviceId" TEXT;
UPDATE "Deployment" d SET "serviceId" = s."id" FROM "Service" s WHERE s."projectId" = d."projectId";
ALTER TABLE "Deployment" ALTER COLUMN "serviceId" SET NOT NULL;
ALTER TABLE "Deployment" DROP COLUMN "projectId";
ALTER TABLE "Deployment" ADD CONSTRAINT "Deployment_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
CREATE INDEX "Deployment_serviceId_idx" ON "Deployment"("serviceId");
CREATE INDEX "Deployment_serviceId_environment_idx" ON "Deployment"("serviceId", "environment");

ALTER TABLE "Domain" ADD COLUMN "serviceId" TEXT;
UPDATE "Domain" d SET "serviceId" = s."id" FROM "Service" s WHERE s."projectId" = d."projectId";
ALTER TABLE "Domain" ALTER COLUMN "serviceId" SET NOT NULL;
ALTER TABLE "Domain" DROP COLUMN "projectId";
ALTER TABLE "Domain" ADD CONSTRAINT "Domain_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
CREATE INDEX "Domain_serviceId_idx" ON "Domain"("serviceId");

ALTER TABLE "EnvVar" ADD COLUMN "serviceId" TEXT;
UPDATE "EnvVar" e SET "serviceId" = s."id" FROM "Service" s WHERE s."projectId" = e."projectId";
ALTER TABLE "EnvVar" ALTER COLUMN "serviceId" SET NOT NULL;
ALTER TABLE "EnvVar" DROP COLUMN "projectId";
ALTER TABLE "EnvVar" ADD CONSTRAINT "EnvVar_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
CREATE INDEX "EnvVar_serviceId_idx" ON "EnvVar"("serviceId");
CREATE UNIQUE INDEX "EnvVar_serviceId_key_target_key" ON "EnvVar"("serviceId", "key", "target");

ALTER TABLE "FeatureFlag" ADD COLUMN "serviceId" TEXT;
UPDATE "FeatureFlag" f SET "serviceId" = s."id" FROM "Service" s WHERE s."projectId" = f."projectId";
ALTER TABLE "FeatureFlag" ALTER COLUMN "serviceId" SET NOT NULL;
ALTER TABLE "FeatureFlag" DROP COLUMN "projectId";
ALTER TABLE "FeatureFlag" ADD CONSTRAINT "FeatureFlag_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "Service"("id") ON DELETE CASCADE ON UPDATE CASCADE;
CREATE INDEX "FeatureFlag_serviceId_idx" ON "FeatureFlag"("serviceId");
CREATE UNIQUE INDEX "FeatureFlag_serviceId_key_target_key" ON "FeatureFlag"("serviceId", "key", "target");

-- 5. Now that every Service carries the old data, drop it from Project.
ALTER TABLE "Project" DROP COLUMN "buildCommand",
DROP COLUMN "startCommand",
DROP COLUMN "surface";
