-- CreateTable
CREATE TABLE "BlobEntry" (
    "id" TEXT NOT NULL,
    "developerId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "contentType" TEXT NOT NULL DEFAULT 'application/octet-stream',
    "sizeBytes" INTEGER NOT NULL,
    "storageKey" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BlobEntry_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "BlobEntry_developerId_idx" ON "BlobEntry"("developerId");

-- CreateIndex
CREATE UNIQUE INDEX "BlobEntry_developerId_key_key" ON "BlobEntry"("developerId", "key");

-- AddForeignKey
ALTER TABLE "BlobEntry" ADD CONSTRAINT "BlobEntry_developerId_fkey" FOREIGN KEY ("developerId") REFERENCES "Developer"("id") ON DELETE CASCADE ON UPDATE CASCADE;
