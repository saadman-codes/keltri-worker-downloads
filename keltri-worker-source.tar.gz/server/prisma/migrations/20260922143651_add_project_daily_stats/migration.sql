-- CreateTable
CREATE TABLE "ProjectDailyStat" (
    "id" TEXT NOT NULL,
    "projectId" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "views" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProjectDailyStat_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ProjectDailyStat_projectId_idx" ON "ProjectDailyStat"("projectId");

-- CreateIndex
CREATE UNIQUE INDEX "ProjectDailyStat_projectId_date_key" ON "ProjectDailyStat"("projectId", "date");

-- AddForeignKey
ALTER TABLE "ProjectDailyStat" ADD CONSTRAINT "ProjectDailyStat_projectId_fkey" FOREIGN KEY ("projectId") REFERENCES "Project"("id") ON DELETE CASCADE ON UPDATE CASCADE;
