ALTER TABLE "Service" ADD COLUMN "rootDir" TEXT NOT NULL DEFAULT '.';
CREATE TABLE "BuildJob" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "dedupeKey" TEXT NOT NULL,
  "deploymentId" TEXT NOT NULL REFERENCES "Deployment"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "repositoryId" TEXT NOT NULL,
  "connectionId" TEXT NOT NULL,
  "commitSha" TEXT NOT NULL,
  "branch" TEXT NOT NULL,
  "target" TEXT NOT NULL,
  "rootDir" TEXT NOT NULL,
  "buildCommand" TEXT NOT NULL,
  "outputDir" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'queued',
  "logs" TEXT NOT NULL DEFAULT '',
  "startedAt" TIMESTAMP(3),
  "finishedAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX "BuildJob_dedupeKey_key" ON "BuildJob"("dedupeKey");
CREATE UNIQUE INDEX "BuildJob_deploymentId_key" ON "BuildJob"("deploymentId");
CREATE INDEX "BuildJob_status_createdAt_idx" ON "BuildJob"("status", "createdAt");
