-- AlterTable
ALTER TABLE "Deployment" ADD COLUMN     "secretFindings" TEXT,
ADD COLUMN     "secretScanStatus" TEXT NOT NULL DEFAULT 'pending';
