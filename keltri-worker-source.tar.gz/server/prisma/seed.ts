import { PrismaClient } from "@prisma/client";
import { createHash } from "node:crypto";
import JSZip from "jszip";
import { hashPassword } from "../src/password.js";
import { putObject } from "../src/storage.js";
import { DEMO_API_KEY, DEMO_EMAIL, DEMO_PASSWORD } from "../src/demo-credentials.js";
import { assertSeedAllowed } from "../src/seed-guard.js";

const prisma = new PrismaClient();

function hashKey(key: string) {
  return createHash("sha256").update(key).digest("hex");
}

function daysAgo(n: number) {
  const d = new Date();
  d.setUTCHours(0, 0, 0, 0);
  d.setUTCDate(d.getUTCDate() - n);
  return d;
}

const miniappHtml = `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>MyApp Try</title>
    <style>
      :root { color-scheme: dark; }
      body { font-family: ui-sans-serif, system-ui, sans-serif; background: #0b0d10; color: #f4f7fb; padding: 24px; margin: 0; }
      button { background: #5b8cff; color: #fff; border: 0; padding: 10px 16px; border-radius: 999px; font-weight: 600; }
      pre { background: #14181f; padding: 12px; border-radius: 12px; overflow: auto; }
    </style>
  </head>
  <body>
    <h1>MyApp Try</h1>
    <p>This is the bundled mini-app. Native APIs are available as window.QA.</p>
    <button type="button" onclick="demo()">Share hello</button>
    <pre id="out"></pre>
    <script>
      async function demo() {
        const out = document.getElementById("out");
        try {
          const qa = window.QA || {
            share: async (payload) => {
              if (navigator.share) await navigator.share(payload);
              return { ok: true, polyfill: true };
            }
          };
          const res = await qa.share({ title: "MyApp", text: "Tried from Keltri" });
          out.textContent = JSON.stringify(res ?? { ok: true }, null, 2);
        } catch (e) { out.textContent = String(e); }
      }
    </script>
  </body>
</html>
`;

const png = Buffer.from(
  "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==",
  "base64",
);

async function buildSeedApk() {
  const zip = new JSZip();
  zip.file(
    "AndroidManifest.xml",
    `<?xml version="1.0" encoding="utf-8"?>
<manifest package="dev.studio.myapp" android:versionCode="13" android:versionName="1.3">
  <uses-permission android:name="android.permission.STORAGE" />
  <application android:label="MyApp" />
</manifest>
`,
  );
  zip.file(
    "assets/config.json",
    JSON.stringify({
      packageName: "dev.studio.myapp",
      versionName: "1.3",
      versionCode: 13,
    }),
  );
  zip.file("miniapp/index.html", miniappHtml);
  zip.file("icon.png", png);
  return zip.generateAsync({ type: "nodebuffer" });
}

async function main() {
  assertSeedAllowed();

  await prisma.dailyStat.deleteMany();
  await prisma.review.deleteMany();
  await prisma.screenshot.deleteMany();
  await prisma.appVersion.deleteMany();
  await prisma.webhook.deleteMany();
  await prisma.payout.deleteMany();
  await prisma.session.deleteMany();
  await prisma.apiKey.deleteMany();
  await prisma.app.deleteMany();
  await prisma.developer.deleteMany();

  const demoKey = DEMO_API_KEY;

  const developer = await prisma.developer.create({
    data: {
      email: DEMO_EMAIL,
      name: "Dev Studio",
      slug: "dev-studio",
      bio: "Independent studio shipping Android tools used by 140k people.",
      website: "https://devstudio.example",
      plan: "team",
      isReviewer: true,
      passwordHash: hashPassword(DEMO_PASSWORD),
      apiKeys: {
        create: {
          name: "Local demo",
          prefix: demoKey.slice(0, 8),
          hashedKey: hashKey(demoKey),
        },
      },
      webhooks: {
        create: {
          url: "https://example.com/keltri-webhooks",
          events: JSON.stringify([
            "version.published",
            "crash.spike",
            "payout.processed",
            "review.approved",
            "review.rejected",
            "listing.unpublished",
          ]),
          secret: "whsec_demo",
        },
      },
      payouts: {
        create: [
          {
            grossCents: 381176,
            feeCents: 57176,
            netCents: 324000,
            status: "scheduled",
            periodLabel: "Sep 2026",
          },
          {
            grossCents: 294118,
            feeCents: 44118,
            netCents: 250000,
            status: "processed",
            periodLabel: "Aug 2026",
            processedAt: daysAgo(11),
          },
          {
            grossCents: 211765,
            feeCents: 31765,
            netCents: 180000,
            status: "processed",
            periodLabel: "Jul 2026",
            processedAt: daysAgo(42),
          },
        ],
      },
    },
  });

  const myApp = await prisma.app.create({
    data: {
      developerId: developer.id,
      slug: "myapp",
      name: "MyApp",
      packageName: "dev.studio.myapp",
      shortDescription: "The best task manager on Android",
      description:
        "MyApp is a fast, offline-first task manager. Capture, schedule, and finish work without fighting the UI.",
      category: "productivity",
      tags: JSON.stringify(["tasks", "productivity", "offline"]),
      contentRating: "Everyone",
      status: "live",
      visibility: "public",
      featured: true,
      miniAppEnabled: true,
      hasMiniApp: true,
      miniAppPermissions: JSON.stringify(["storage", "share"]),
      versions: {
        create: [
          {
            versionName: "1.3",
            versionCode: 13,
            status: "live",
            scanStatus: "ready",
            rolloutPercent: 100,
            apkSha256: "a".repeat(64),
            apkSizeBytes: 18_400_000,
            apkKey: `apps/placeholder/app.apk`,
            miniappKey: `apps/placeholder/miniapp`,
            releaseNotes:
              "- Fixed crash on Android 14\n- Dark mode improvements",
            installCount: 82000,
            crashRate: 0.003,
            createdAt: daysAgo(12),
          },
          {
            versionName: "1.2",
            versionCode: 12,
            status: "rolled_back",
            scanStatus: "ready",
            rolloutPercent: 0,
            apkSizeBytes: 17_900_000,
            releaseNotes: "Widget refresh.",
            installCount: 41000,
            crashRate: 0.011,
            createdAt: daysAgo(40),
          },
          {
            versionName: "1.1",
            versionCode: 11,
            status: "live",
            scanStatus: "ready",
            rolloutPercent: 0,
            apkSizeBytes: 16_200_000,
            releaseNotes: "Share sheet + widgets.",
            installCount: 12800,
            crashRate: 0.004,
            createdAt: daysAgo(70),
          },
          {
            versionName: "1.0",
            versionCode: 10,
            status: "live",
            scanStatus: "ready",
            rolloutPercent: 0,
            apkSizeBytes: 15_100_000,
            releaseNotes: "First public release.",
            installCount: 7030,
            crashRate: 0.006,
            createdAt: daysAgo(110),
          },
        ],
      },
      reviews: {
        create: [
          {
            author: "Priya K.",
            rating: 5,
            body: "Switched from Google Play and never looking back.",
          },
          {
            author: "Marcus T.",
            rating: 5,
            body: "OTA landed a crash fix the same afternoon. That sold me.",
          },
          {
            author: "Elena V.",
            rating: 4,
            body: "Try-before-install is how every store should work.",
          },
        ],
      },
      screenshots: {
        create: [
          { url: "/screens/myapp-1.png", sortOrder: 0 },
          { url: "/screens/myapp-2.png", sortOrder: 1 },
          { url: "/screens/myapp-3.png", sortOrder: 2 },
        ],
      },
    },
  });

  const live = await prisma.appVersion.findFirst({
    where: { appId: myApp.id, versionName: "1.3" },
  });
  const apkKey = `apps/${myApp.id}/${live?.id ?? "seed"}/app.apk`;
  const miniappKey = `apps/${myApp.id}/${live?.id ?? "seed"}/miniapp`;
  const iconKey = `apps/${myApp.id}/${live?.id ?? "seed"}/icon.png`;
  const apk = await buildSeedApk();
  await putObject(apkKey, apk);
  await putObject(`${miniappKey}/index.html`, Buffer.from(miniappHtml));
  await putObject(iconKey, png);

  if (live) {
    await prisma.appVersion.update({
      where: { id: live.id },
      data: {
        apkKey,
        miniappKey,
        iconKey,
        apkSha256: createHash("sha256").update(apk).digest("hex"),
        apkSizeBytes: apk.length,
      },
    });
  }

  const harbor = await prisma.developer.create({
    data: {
      email: "hello@harborlabs.example",
      name: "Harbor Labs",
      slug: "harbor-labs",
      bio: "Utility apps that stay out of the way.",
      website: "https://harborlabs.example",
      plan: "pro",
    },
  });

  const northwind = await prisma.developer.create({
    data: {
      email: "studio@northwind.example",
      name: "Northwind Games",
      slug: "northwind-games",
      bio: "Small-room arcade games for Android.",
      website: "https://northwind.example",
      plan: "pro",
    },
  });

  await seedShowcaseApps(harbor.id, northwind.id);

  await prisma.app.create({
    data: {
      developerId: developer.id,
      slug: "secondapp",
      name: "SecondApp",
      packageName: "dev.studio.secondapp",
      shortDescription: "Private build for the team.",
      status: "draft",
      visibility: "private",
      versions: {
        create: {
          versionName: "0.9",
          versionCode: 9,
          status: "draft",
          scanStatus: "pending",
          rolloutPercent: 0,
          installCount: 0,
          crashRate: 0,
        },
      },
    },
  });

  await prisma.app.create({
    data: {
      developerId: developer.id,
      slug: "thirdapp",
      name: "ThirdApp",
      packageName: "dev.studio.thirdapp",
      shortDescription: "Waiting on store review.",
      status: "in_review",
      visibility: "public",
      versions: {
        create: {
          versionName: "2.1",
          versionCode: 21,
          status: "review",
          scanStatus: "ready",
          rolloutPercent: 0,
          installCount: 0,
          crashRate: 0,
        },
      },
    },
  });

  const stats = Array.from({ length: 30 }, (_, i) => {
    const day = 29 - i;
    const wave = Math.sin(i / 4) * 180;
    return {
      appId: myApp.id,
      date: daysAgo(day),
      installs: Math.round(2100 + wave + i * 18),
      uninstalls: Math.round(90 + (i % 5) * 8),
      crashes: Math.round(6 + (i % 7)),
    };
  });

  await prisma.dailyStat.createMany({ data: stats });

  console.log("Seeded Dev Studio demo data (local/development only).");
  console.log(`Demo API key: ${demoKey}`);
  console.log(`Portal login: ${DEMO_EMAIL} / ${DEMO_PASSWORD}`);
}

type ShowcaseSpec = {
  developerId: string;
  slug: string;
  name: string;
  category: string;
  shortDescription: string;
  description: string;
  featured?: boolean;
  installs: number;
  createdDaysAgo: number;
  reviews: { author: string; rating: number; body: string }[];
};

async function seedShowcaseApps(harborId: string, northwindId: string) {
  const specs: ShowcaseSpec[] = [
    {
      developerId: northwindId,
      slug: "drift-racers",
      name: "Drift Racers",
      category: "games",
      shortDescription: "Arcade racing with weekly tracks",
      description:
        "Short races, weekly tracks, and ghost laps. Built for phones, not consoles.",
      featured: true,
      installs: 98000,
      createdDaysAgo: 3,
      reviews: [
        { author: "Sam R.", rating: 5, body: "Weekly tracks keep me coming back." },
        { author: "Lia P.", rating: 4, body: "Install was instant. Racing is tight." },
      ],
    },
    {
      developerId: northwindId,
      slug: "orbit-puzzle",
      name: "Orbit Puzzle",
      category: "games",
      shortDescription: "Gravity puzzles in sixty-second rounds",
      description:
        "Sling planets around a star and land them on the beacon before time runs out.",
      installs: 64000,
      createdDaysAgo: 18,
      reviews: [
        { author: "Ken M.", rating: 5, body: "The sixty-second format is perfect." },
      ],
    },
    {
      developerId: northwindId,
      slug: "pixel-farm",
      name: "Pixel Farm",
      category: "games",
      shortDescription: "A quiet farm you can check in a minute",
      description: "Plant, harvest, and trade without an energy timer.",
      installs: 51000,
      createdDaysAgo: 26,
      reviews: [
        { author: "Ava C.", rating: 4, body: "Cozy and actually offline." },
      ],
    },
    {
      developerId: harborId,
      slug: "pulse-chat",
      name: "Pulse Chat",
      category: "social",
      shortDescription: "Encrypted group chat that stays on-device",
      description: "Groups, replies, and media that never leave your phone until you send.",
      installs: 22100,
      createdDaysAgo: 2,
      reviews: [
        { author: "Noor H.", rating: 5, body: "Tried it, then installed the same night." },
      ],
    },
    {
      developerId: harborId,
      slug: "night-notes",
      name: "Night Notes",
      category: "productivity",
      shortDescription: "Dark-mode notes that sync over OTA",
      description: "Markdown notes with a tiny bootstrapper and silent updates.",
      installs: 15400,
      createdDaysAgo: 4,
      reviews: [
        { author: "Chris D.", rating: 4, body: "Finally a notes app that does not nag." },
      ],
    },
    {
      developerId: harborId,
      slug: "ledger-lite",
      name: "Ledger Lite",
      category: "finance",
      shortDescription: "Offline-first personal finance",
      description: "Track spend without an account. Export CSV when you need it.",
      installs: 41000,
      createdDaysAgo: 21,
      reviews: [
        { author: "Mei L.", rating: 4, body: "Simple ledger, no bank login required." },
      ],
    },
    {
      developerId: harborId,
      slug: "signal-kit",
      name: "Signal Kit",
      category: "tools",
      shortDescription: "Network diagnostics in your pocket",
      description: "Ping, traceroute, and Wi-Fi stats without a Play Store wait.",
      installs: 30800,
      createdDaysAgo: 15,
      reviews: [
        { author: "Omar S.", rating: 4, body: "Exactly the toolkit I wanted on a work phone." },
      ],
    },
    {
      developerId: harborId,
      slug: "vault-box",
      name: "Vault Box",
      category: "tools",
      shortDescription: "Private file locker with local keys",
      description: "Lock files behind a local key. No cloud unless you add one.",
      installs: 27500,
      createdDaysAgo: 33,
      reviews: [
        { author: "Rita J.", rating: 4, body: "Does what it says. Updates arrived overnight." },
      ],
    },
  ];

  for (const spec of specs) {
    await prisma.app.create({
      data: {
        developerId: spec.developerId,
        slug: spec.slug,
        name: spec.name,
        packageName: `app.keltri.${spec.slug.replace(/-/g, "")}`,
        shortDescription: spec.shortDescription,
        description: spec.description,
        category: spec.category,
        tags: JSON.stringify([spec.category]),
        contentRating: spec.category === "games" ? "Everyone 10+" : "Everyone",
        status: "live",
        visibility: "public",
        featured: Boolean(spec.featured),
        createdAt: daysAgo(spec.createdDaysAgo),
        versions: {
          create: {
            versionName: "1.0",
            versionCode: 10,
            status: "live",
            scanStatus: "ready",
            rolloutPercent: 100,
            installCount: spec.installs,
            crashRate: 0.002,
            releaseNotes: "Latest store build.",
            createdAt: daysAgo(spec.createdDaysAgo),
          },
        },
        reviews: { create: spec.reviews },
      },
    });
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
