#!/usr/bin/env bash
set -euo pipefail
# Run against a dedicated build VM. Source is a trusted Keltri checkout,
# never one of the customer repositories processed by this worker.
[[ $EUID == 0 ]] || { echo 'Run with sudo.'; exit 1; }
source_dir=$(realpath "${1:?Usage: install-debian.sh CHECKOUT [micro|standard]}")
profile=${2:-standard}
[[ $profile == micro || $profile == standard ]] || { echo 'Unknown profile'; exit 1; }
[[ -f $source_dir/server/src/build-worker.ts && -f $source_dir/pnpm-lock.yaml ]] || { echo 'Not a Keltri checkout'; exit 1; }
source /etc/os-release
[[ $ID == debian && ( $VERSION_ID == 12 || $VERSION_ID == 13 ) && $(uname -m) == x86_64 ]] || { echo 'Installer requires Debian 12/13 x86_64.'; exit 1; }
# Stop our worker before replacing code/network rules; do not stop other services.
systemctl stop keltri-build-worker.service 2>/dev/null || true
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg iptables rsync xz-utils e2fsprogs util-linux
install -d -m 0755 /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
chmod 0644 /etc/apt/keyrings/docker.asc
printf 'deb [arch=amd64 signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian %s stable\n' "$VERSION_CODENAME" > /etc/apt/sources.list.d/keltri-docker.list
curl -fsSL https://gvisor.dev/archive.key | gpg --dearmor --yes -o /etc/apt/keyrings/gvisor.gpg
echo 'deb [arch=amd64 signed-by=/etc/apt/keyrings/gvisor.gpg] https://storage.googleapis.com/gvisor/releases release main' > /etc/apt/sources.list.d/keltri-gvisor.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin runsc
runsc install
systemctl enable --now docker
systemctl reload docker

if ! test -x /opt/keltri-node/bin/node; then
  temporary=$(mktemp -d)
  trap 'rm -rf -- "$temporary"' EXIT
  curl -fsSL https://nodejs.org/dist/latest-v22.x/SHASUMS256.txt -o "$temporary/SHASUMS256.txt"
  archive=$(awk '$2 ~ /^node-v22\.[0-9]+\.[0-9]+-linux-x64\.tar\.xz$/ {print $2}' "$temporary/SHASUMS256.txt")
  [[ $archive =~ ^node-v22\.[0-9]+\.[0-9]+-linux-x64\.tar\.xz$ ]] || { echo 'Could not identify Node archive'; exit 1; }
  curl -fsSL "https://nodejs.org/dist/latest-v22.x/$archive" -o "$temporary/$archive"
  (cd "$temporary"; grep "  $archive$" SHASUMS256.txt | sha256sum -c -)
  install -d /opt/keltri-node
  tar -xJf "$temporary/$archive" --strip-components=1 -C /opt/keltri-node
fi
export PATH=/opt/keltri-node/bin:$PATH
node -e 'if(Number(process.versions.node.split(".")[0])<22)process.exit(1)'
npm install -g pnpm@10.34.5
id keltri-worker >/dev/null 2>&1 || useradd --system --create-home --home-dir /var/lib/keltri-worker --shell /usr/sbin/nologin keltri-worker
usermod -aG docker keltri-worker
install -d -m 0755 /opt/keltri-worker
if [[ $source_dir != /opt/keltri-worker ]]; then
  rsync -a --exclude='.git' --exclude='node_modules' --exclude='.env' --exclude='.env.*' --exclude='*.pem' --exclude='*.key' "$source_dir/" /opt/keltri-worker/
fi
cd /opt/keltri-worker
pnpm --filter @keltri/server... install --frozen-lockfile --ignore-scripts
pnpm --filter @keltri/server exec prisma generate
chmod 0755 server/build-runner/*.sh
docker build -t keltri-builder:local server/build-runner

# A dedicated bounded filesystem prevents customer build files filling the OS disk.
# Never format an existing volume or resize a pre-existing image automatically.
install -d -m 0755 /var/lib/keltri-builds
if ! mountpoint -q /var/lib/keltri-builds; then
  if [[ ! -e /var/lib/keltri-build-volume.img ]]; then
    free_mb=$(df -Pm /var/lib | awk 'NR==2 {print $4}')
    (( free_mb >= 5120 )) || { echo 'Need 5 GB free disk before creating the 2 GB build workspace. Increase the disk and rerun.'; exit 1; }
    fallocate -l 2G /var/lib/keltri-build-volume.img
    chmod 0600 /var/lib/keltri-build-volume.img
    mkfs.ext4 -F /var/lib/keltri-build-volume.img
  fi
  grep -q '^/var/lib/keltri-build-volume.img ' /etc/fstab || echo '/var/lib/keltri-build-volume.img /var/lib/keltri-builds ext4 loop,nosuid,nodev 0 0' >> /etc/fstab
  mount /var/lib/keltri-builds
fi
chown keltri-worker:keltri-worker /var/lib/keltri-builds
chmod 0700 /var/lib/keltri-builds
install -d -m 0700 /etc/keltri
if [[ $profile == micro ]]; then
  printf 'BUILD_MEMORY_MB=512\nBUILD_CPUS=0.5\nBUILD_TMP_MB=64\nNODE_OPTIONS=--max-old-space-size=160\n' > /etc/keltri/resources.env
else
  printf 'BUILD_MEMORY_MB=2048\nBUILD_CPUS=2\nBUILD_TMP_MB=256\n' > /etc/keltri/resources.env
fi
chmod 0600 /etc/keltri/resources.env
install -m 0644 server/build-runner/keltri-build-network.service /etc/systemd/system/
install -m 0644 server/build-runner/keltri-build-worker.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable keltri-build-network.service keltri-build-worker.service
systemctl restart keltri-build-network.service
bash server/build-runner/smoke-test.sh
if [[ -s /etc/keltri/worker.env ]]; then
  systemctl restart keltri-build-worker.service
  sleep 3
  systemctl is-active --quiet keltri-build-worker.service
  echo 'Worker service started. Verify a complete queued build before enabling customer builds.'
else
  echo 'Host setup complete. Worker is stopped: /etc/keltri/worker.env still needs production credentials.'
fi
