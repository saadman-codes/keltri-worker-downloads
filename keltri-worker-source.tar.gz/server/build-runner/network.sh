#!/usr/bin/env bash
set -euo pipefail
# Dedicated bridge; leave the VM's SSH and other host traffic unchanged.
if ! docker network inspect keltri-build >/dev/null 2>&1; then
  docker network create --driver bridge --subnet 172.30.250.0/24 \
    --opt com.docker.network.bridge.name=keltri-build0 \
    --opt com.docker.network.bridge.enable_icc=false keltri-build >/dev/null
fi
[[ $(docker network inspect -f '{{index .Options "com.docker.network.bridge.name"}}' keltri-build) == keltri-build0 ]] || { echo 'Unexpected existing build network'; exit 1; }
iptables -N KELTRI-BUILD 2>/dev/null || true
iptables -F KELTRI-BUILD
for cidr in 0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 172.16.0.0/12 192.168.0.0/16 192.0.0.0/24 192.0.2.0/24 198.18.0.0/15 198.51.100.0/24 203.0.113.0/24 224.0.0.0/4 240.0.0.0/4; do
  iptables -A KELTRI-BUILD -d "$cidr" -j REJECT
done
iptables -A KELTRI-BUILD -p tcp -m multiport --dports 80,443 -j ACCEPT
iptables -A KELTRI-BUILD -d 8.8.8.8 -p udp --dport 53 -j ACCEPT
iptables -A KELTRI-BUILD -d 8.8.8.8 -p tcp --dport 53 -j ACCEPT
iptables -A KELTRI-BUILD -j REJECT
iptables -C DOCKER-USER -i keltri-build0 -j KELTRI-BUILD 2>/dev/null || iptables -I DOCKER-USER 1 -i keltri-build0 -j KELTRI-BUILD
iptables -C INPUT -i keltri-build0 -j REJECT 2>/dev/null || iptables -I INPUT 1 -i keltri-build0 -j REJECT
# IPv6 is not enabled on the build bridge. Also deny it explicitly.
ip6tables -C FORWARD -i keltri-build0 -j REJECT 2>/dev/null || ip6tables -I FORWARD 1 -i keltri-build0 -j REJECT
ip6tables -C INPUT -i keltri-build0 -j REJECT 2>/dev/null || ip6tables -I INPUT 1 -i keltri-build0 -j REJECT
