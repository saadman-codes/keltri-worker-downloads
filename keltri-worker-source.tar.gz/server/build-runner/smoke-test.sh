#!/usr/bin/env bash
set -euo pipefail
[[ $EUID == 0 ]] || { echo 'Run with sudo.'; exit 1; }
source /etc/keltri/resources.env
user_id=$(id -u keltri-worker)
group_id=$(id -g keltri-worker)
docker run --rm --runtime runsc --network keltri-build --dns 8.8.8.8 \
  --user "$user_id:$group_id" --memory "${BUILD_MEMORY_MB}m" --memory-swap "${BUILD_MEMORY_MB}m" \
  --cpus "$BUILD_CPUS" --pids-limit 128 --cap-drop ALL --security-opt no-new-privileges \
  --read-only --tmpfs "/tmp:rw,nosuid,size=${BUILD_TMP_MB}m" \
  keltri-builder:local timeout 60 node --input-type=module -e '
const response = await fetch("https://registry.npmjs.org/is-number/latest", {signal: AbortSignal.timeout(20000)});
if (!response.ok) throw new Error("Package registry is unreachable");
for (const url of ["http://169.254.169.254/", "http://172.30.250.1/"]) {
  let reachable = false;
  try { await fetch(url, {signal: AbortSignal.timeout(3000)}); reachable = true; } catch {}
  if (reachable) throw new Error("Sandbox can reach a prohibited destination");
}
console.log("Sandbox smoke test passed: public registry reachable, metadata and bridge host blocked.");
'
