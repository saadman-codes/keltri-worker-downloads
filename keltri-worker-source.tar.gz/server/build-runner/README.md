# Automatic Git builds

This worker runs separately from the Vercel API. Customers connect the GitHub App,
import a web service, and deploy without installing workflows or repository secrets.
Signed `push` webhooks queue immutable commits. Default-branch builds publish
production; other branches publish previews. Failed builds leave production alone.
Secret findings prevent automatic promotion. Deployment pages poll job logs.

## Operator setup

### Automated Google Cloud installation

From a Windows checkout with Google Cloud CLI authenticated, run:

```powershell
./server/build-runner/deploy-gce.ps1 -Project keltri -Zone us-central1-a -Instance instance-20260929-061941 -Profile micro
```

Use `-Gcloud C:/path/to/google-cloud-sdk/bin/gcloud.cmd` for a portable SDK, and
`-ThroughIap` if the VM is reachable through IAP rather than an external IP.
This installs on the existing VM; it does not provision or resize instances.
The source bundle includes working-tree changes and excludes ignored credentials.
The installer uses the official Docker and gVisor repositories and verifies its
Node archive checksum. It installs a systemd worker and a persistent restricted
Docker bridge, and allocates a bounded 2 GB workspace filesystem (requires 5 GB
free disk at that step). It does not modify incoming SSH/HTTP firewall settings.

For activation, create an **untracked, external** credentials file using
`worker.env.example` as the format, then pass `-WorkerEnvFile C:/secure/worker.env`.
The file goes through SSH into a private staging directory and is installed at
`/etc/keltri/worker.env` with mode 0600. Its contents are never printed by the
installer. Do not reuse development database/storage credentials for production.
No secrets are required from the customers whose repositories will be built.

`micro` uses 512 MB build memory, half a CPU, a 64 MB sandbox temporary filesystem,
and a 160 MB worker JavaScript heap. It is an experimental profile for tiny builds,
not a reliable public build tier; total process memory can exceed the JS heap.
`standard` uses 2 GB per build and two CPUs and needs at least a 4 GB host.
Both profiles run **one job at a time per VM**. Resource limits are configurable
in `/etc/keltri/resources.env`. No VM resize is performed automatically.

Add more existing VMs by rerunning the installer with their instance names. Each
uses the shared PostgreSQL queue with atomic job claims. This is a worker pool,
not a Kubernetes cluster; fleet autoscaling and a worker-health dashboard are
not yet implemented. Scale by adding VMs, never by starting multiple workers on
this 1 GB host. A larger pool cannot make a single oversized build fit in 512 MB.

Check `sudo systemctl status keltri-build-worker` and
`sudo journalctl -u keltri-build-worker -n 50 --no-pager` after installation.
The smoke test verifies sandbox startup, public registry access, and blocked
metadata/bridge-host access. A full repository build is still required before
turning on `GIT_BUILDS_ENABLED` on the API. Existing database migration and
GitHub Push event requirements below still apply.

### Manual installation

1. Apply the checked-in migration with `pnpm --filter @keltri/server db:migrate:deploy`.
   Back up the database before running production migrations. This adds `BuildJob`
   and the service root directory; it does not remove existing data.
2. Provision a **dedicated Linux build host** with Node 22+, pnpm, Docker, and
   [gVisor's runsc runtime](https://gvisor.dev/docs/user_guide/quick_start/docker/).
   Do not run user builds on the API/database host. Firewall the build containers
   from the host, private networks, and cloud metadata endpoints; allow public
   package registries. Give disposable build storage a disk quota and monitor it.
   Docker's CPU/memory limits do not enforce a disk quota.
3. From the repository root, build the image:
   `docker build -t keltri-builder:local server/build-runner`.
   Run the worker as a dedicated non-root OS user with access to Docker. The
   container uses that user's UID/GID and receives no Docker socket.
4. Set the worker's `DATABASE_URL`, GitHub App environment variables, `NODE_ENV=production`,
   and the same R2/S3 storage configuration as the API. Worker and API must share
   the database and bucket. Do not copy these credentials into build containers.
   Optional: `BUILD_CONTAINER_IMAGE` (default `keltri-builder:local`) and
   `BUILD_CONTAINER_RUNTIME` (default `runsc`; required in production).
5. Start `pnpm --filter @keltri/server worker:builds` under a process supervisor.
   It processes one job at a time. Multiple workers claim jobs using PostgreSQL
   `FOR UPDATE SKIP LOCKED`. Use a direct PostgreSQL connection or a pooler that
   supports interactive transactions.
6. Enable the GitHub App's **Push** event subscription, keeping Contents: read.
   Its webhook URL remains `https://quantaserver.vercel.app/v1/git/webhook`, secured
   with `GITHUB_APP_WEBHOOK_SECRET`. No Actions/workflow write permission is needed.
7. Only after the worker is running, set `GIT_BUILDS_ENABLED=true` on the API and
   redeploy it. Existing linked services can use **Deploy latest commit**.

## Verification before enabling customer builds

Import a disposable static-site repository. Confirm queued → building → ready,
logs, the preview URL, and production URL. Push a change to the default branch,
then a feature branch. Confirm only the default branch updates production.
Fail a build and verify production stays available. Redeliver a push webhook and
confirm it creates no duplicate. Suspend the installation and verify builds fail.

Builds have a ten-minute sandbox timeout, 2 GB memory, two CPUs, 256 PIDs,
a read-only container filesystem (apart from its disposable workspace and /tmp),
and no capabilities. Source/output limits are 100 MB; output must contain
`index.html`. Logs are capped and exact service secret values are redacted;
application code can still deliberately transform or disclose its own variables.

The container runs install scripts and build commands, so gVisor plus host network
and disk isolation are deployment requirements, not optional hardening for a public
multi-tenant service. Platform credentials remain in the trusted worker process.
The container has its own timeout if the worker exits. Jobs abandoned for twenty
minutes are marked failed; redeploy explicitly to retry. Operators should clean
up stopped `keltri-build-*` containers and abandoned temporary workspaces after a
worker crash, and run a periodic sweep in production.

Initial scope: static websites, branch pushes, manual redeploy, build logs, and
production publication. No backend/SSR processes, PR status comments, caching,
automatic retry, cancellation UI, or custom-domain provisioning yet. Root-directory
builds install dependencies in that directory; workspace monorepos that need a
root install should keep root `.` and use a workspace build command/output path.

Local unit/type/build checks do not substitute for the Linux integration test above.
Do not enable the API flag until that test passes on your configured host.
