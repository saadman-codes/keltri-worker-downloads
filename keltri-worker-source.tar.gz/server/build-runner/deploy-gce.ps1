param(
  [string]$Project = 'keltri',
  [string]$Zone = 'us-central1-a',
  [string]$Instance = 'instance-20260929-061941',
  [ValidateSet('micro', 'standard')][string]$Profile = 'micro',
  [string]$Gcloud = 'gcloud',
  [string]$WorkerEnvFile,
  [switch]$ThroughIap
)
$ErrorActionPreference = 'Stop'
foreach ($identifier in @($Project, $Zone, $Instance)) {
  if ($identifier -notmatch '^[a-z][a-z0-9-]+$') { throw 'Invalid Google Cloud identifier' }
}
$repoPath = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$taskDir = Join-Path ([IO.Path]::GetTempPath()) ('keltri-deploy-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $taskDir | Out-Null
$remoteDir = '/tmp/keltri-setup-' + [guid]::NewGuid().ToString('N')
$connection = @('--project', $Project, '--zone', $Zone)
if ($ThroughIap) { $connection += '--tunnel-through-iap' }
function Invoke-Gcloud([string[]]$Arguments) {
  & $Gcloud @Arguments
  if ($LASTEXITCODE -ne 0) { throw 'Google Cloud command failed; installation stopped.' }
}
if ($WorkerEnvFile) { $WorkerEnvFile = (Resolve-Path -LiteralPath $WorkerEnvFile).Path }
Push-Location $repoPath
try {
  # Include local implementation changes, but never ignored .env files, keys,
  # node_modules, Git history, or user uploads in the source bundle.
  $files = @(git ls-files --cached --others --exclude-standard -- server/src server/prisma server/build-runner server/package.json server/tsconfig.json server/api packages apps package.json pnpm-lock.yaml pnpm-workspace.yaml turbo.json)
  if ($LASTEXITCODE -ne 0) { throw 'Could not enumerate source files' }
  $files = @($files | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Sort-Object -Unique)
  foreach ($file in $files) {
    if ($file -match '(^|/)\.env($|\.)' -and $file -notmatch '\.example$' -or $file -match '\.(pem|key|p12|db)$') { throw "Sensitive file excluded from deployment: $file" }
    if ($file -match '\.(sh|service)$') {
      $text = [IO.File]::ReadAllText((Join-Path $repoPath $file)).Replace("`r`n", "`n")
      [IO.File]::WriteAllText((Join-Path $repoPath $file), $text, [Text.UTF8Encoding]::new($false))
    }
  }
  $manifest = Join-Path $taskDir 'files.txt'
  [IO.File]::WriteAllLines($manifest, $files, [Text.UTF8Encoding]::new($false))
  $bundle = Join-Path $taskDir 'source.tar.gz'
  & tar -czf $bundle -T $manifest
  if ($LASTEXITCODE -ne 0) { throw 'Could not create source archive' }
  Invoke-Gcloud (@('compute','ssh',$Instance) + $connection + @('--command', "umask 077 && mkdir $remoteDir"))
  Invoke-Gcloud (@('compute','scp',$bundle,"${Instance}:$remoteDir/source.tar.gz") + $connection)
  if ($WorkerEnvFile) {
    Invoke-Gcloud (@('compute','scp',$WorkerEnvFile,"${Instance}:$remoteDir/worker.env") + $connection)
  }
  $command = "set -eu; mkdir $remoteDir/source; tar -xzf $remoteDir/source.tar.gz -C $remoteDir/source; "
  if ($WorkerEnvFile) {
    $command += "sudo install -d -m 700 /etc/keltri; sudo install -m 600 $remoteDir/worker.env /etc/keltri/worker.env; rm $remoteDir/worker.env; "
  }
  $command += "sudo bash $remoteDir/source/server/build-runner/install-debian.sh $remoteDir/source $Profile"
  Invoke-Gcloud (@('compute','ssh',$Instance) + $connection + @('--command', $command))
  Write-Output 'Installer completed. Check worker status and run an end-to-end deployment before enabling API build intake.'
} finally {
  Pop-Location
  # Temp archives contain source only. Retained on failure for diagnosis.
  Write-Output "Local source bundle: $taskDir"
}
