import assert from "node:assert/strict";
import test from "node:test";
import { createHmac } from "node:crypto";
import { Hono } from "hono";
import type { PrismaClient } from "@prisma/client";
import { GitHubApp, GitHubError } from "./github-app.js";
import { createGitRouters } from "./routes/git.js";
import { githubScope, connectedRepository } from "./github-scope.js";

function fixture() {
  const attempts = new Map<string, any>();
  const connections = new Map<string, any>();
  const matches = (row: any, where: any): boolean => Object.entries(where).every(([key, value]: [string, any]) =>
    value && typeof value === "object" ? (value.gt ? row[key] > value.gt : row[key] < value.lt) : row[key] === value);
  function table(rows: Map<string, any>) {
    return {
      async create({ data }: any) { const row = { id: `row${rows.size + 1}`, result: null, verifier: null, ...data }; rows.set(row.id, row); return { ...row }; },
      async findUnique({ where }: any) { return [...rows.values()].find(row => matches(row, where)) ?? null; },
      async findFirst({ where }: any) { return [...rows.values()].find(row => matches(row, where)) ?? null; },
      async findMany({ where }: any) { return [...rows.values()].filter(row => matches(row, where)); },
      async deleteMany({ where }: any) { let count = 0; for (const row of rows.values()) if (matches(row, where)) { rows.delete(row.id); count++; } return { count }; },
      async update({ where, data }: any) { const row = [...rows.values()].find(row => matches(row, where)); Object.assign(row, data); return row; },
    };
  }
  const db = { gitHubConnectAttempt: table(attempts), gitHubInstallation: table(connections),
    organizationMember: { async findUnique() { return { role: "member" }; } },
    async $transaction(fn: any) { return fn(db); },
  } as unknown as PrismaClient;
  const provider = new GitHubApp({ appId: "123", clientId: "client", clientSecret: "secret", slug: "test", privateKey: "unused", apiOrigin: "https://api.example.test" });
  provider.userInstallations = async () => [{ id: 12, app_id: 123, suspended_at: null, account: { login: "alice", type: "User" } }];
  provider.exchangeCode = async () => "transient-token";
  provider.checkConnectionConfiguration = async () => {};
  provider.verifyInstallation = async id => ({ installation: { id: Number(id), app_id: 123, suspended_at: null, account: { login: "alice", type: "User" } }, userId: "7", repositoryIds: ["42"] });
  provider.installationToken = async () => "installation-token";
  const routers = createGitRouters({ db, github: () => provider, configured: () => true, consoleUrl: () => "https://web.example.test/console", webhookSecret: () => "webhook-test-secret" });
  const app = new Hono();
  app.route("/v1/git", routers.publicGit);
  app.use("/v1/git/*", async (c, next) => { c.set("developer", { id: c.req.header("x-test-user") ?? "alice" } as any); await next(); });
  app.route("/v1/git", routers.git);
  const proof = "browser-proof-".repeat(4);
  const post = (path: string, body: unknown, user = "alice") => app.request(`https://api.example.test/v1/git${path}`, { method: "POST", headers: { "Content-Type": "application/json", "x-test-user": user }, body: JSON.stringify(body) });
  return { app, attempts, connections, db, proof, post, provider };
}

async function verifiedFlow(f = fixture()) {
  const start = await f.post("/connect", { clientProof: f.proof, returnTo: "/console/projects/project1/services/new", mode: "install" });
  assert.equal(start.status, 200);
  const { data } = await start.json();
  const landing = await f.app.request(data.url);
  const cookie = landing.headers.get("set-cookie")!.split(";")[0];
  const installState = new URL(landing.headers.get("location")!).searchParams.get("state");
  const setupUrl = `https://api.example.test/v1/git/setup?state=${installState}&installation_id=12`;
  const missingCookie = await f.app.request(setupUrl);
  assert.match(missingCookie.headers.get("location")!, /error=expired/);
  const setup = await f.app.request(setupUrl, { headers: { cookie } });
  const authorization = new URL(setup.headers.get("location")!);
  assert.equal(authorization.searchParams.get("code_challenge_method"), "S256");
  const callback = `https://api.example.test/v1/git/connect/callback?state=${authorization.searchParams.get("state")}&code=github-code`;
  const returned = await f.app.request(callback, { headers: { cookie } });
  const replay = await f.app.request(callback, { headers: { cookie } });
  assert.match(replay.headers.get("location")!, /error=expired/);
  const destination = new URL(returned.headers.get("location")!);
  assert.equal(destination.origin, "https://web.example.test");
  const completion = { flowId: data.flowId, code: destination.searchParams.get("code"), clientProof: f.proof };
  return { ...f, completion };
}

test("cross-site install returns to the project and links only once with the original user and proof", async () => {
  const f = await verifiedFlow();
  assert.equal((await f.post("/complete", f.completion, "mallory")).status, 403);
  assert.equal((await f.post("/complete", { ...f.completion, clientProof: "wrong".repeat(10) })).status, 403);
  const completed = await f.post("/complete", f.completion);
  assert.equal(completed.status, 200);
  assert.equal((await completed.json()).data.returnTo, "/console/projects/project1/services/new");
  assert.equal((await f.post("/complete", f.completion)).status, 403);
  assert.equal(f.connections.size, 1);
  assert.equal([...f.connections.values()][0].scopeKey, "developer:alice");
  assert.equal(JSON.stringify([...f.attempts.values(), ...f.connections.values()]).includes("transient-token"), false);
});

async function discover(f = fixture()) {
  const start = await f.post("/connect", { clientProof: f.proof, returnTo: "/console/projects/new" });
  const { data } = await start.json();
  const landing = await f.app.request(data.url);
  const cookie = landing.headers.get("set-cookie")!.split(";")[0];
  const authorize = new URL(landing.headers.get("location")!);
  assert.equal(authorize.pathname, "/login/oauth/authorize");
  const returned = await f.app.request(`https://api.example.test/v1/git/connect/callback?state=${authorize.searchParams.get("state")}&code=github-code`, { headers: { cookie } });
  const location = new URL(returned.headers.get("location")!);
  return { ...f, cookie, location, completion: { flowId: data.flowId, code: location.searchParams.get("code"), clientProof: f.proof } };
}

test("already installed on GitHub but not linked in Quanta skips installation settings", async () => {
  const f = await discover();
  assert.equal(f.location.pathname, "/console/git/callback");
  assert.equal((await f.post("/complete", f.completion)).status, 200);
  assert.equal(f.connections.size, 1);
  f.provider.repositories = async () => [{ id: 42, name: "app", full_name: "alice/app", default_branch: "main", private: true, updated_at: "2026-09-27" }];
  const response = await f.app.request("https://api.example.test/v1/git/repos");
  assert.equal(response.status, 200);
  assert.equal((await response.json()).data[0].fullName, "alice/app");
});

test("invalid deployment credentials block both entry points before creating an attempt", async () => {
  const f = fixture();
  f.provider.checkConnectionConfiguration = async () => { throw new GitHubError("Connection unavailable", 503, "client_credentials"); };
  for (const mode of ["connect", "install"]) {
    const response = await f.post("/connect", { clientProof: f.proof, returnTo: "/console/projects/new", mode });
    assert.equal(response.status, 503);
    assert.equal(response.headers.get("location"), null);
    assert.equal(f.attempts.size, 0);
  }
});

test("multiple installations require an explicit verified selection", async () => {
  const f = fixture();
  f.provider.userInstallations = async () => [12, 13].map(id => ({ id, app_id: 123, suspended_at: null, account: { login: `account${id}`, type: "User" } }));
  const flow = await discover(f);
  const choices = await flow.post("/complete", flow.completion);
  assert.equal((await choices.json()).data.installations.length, 2);
  assert.equal(f.connections.size, 0);
  assert.equal((await flow.post("/complete", { ...flow.completion, installationId: "99" })).status, 403);
  assert.equal((await flow.post("/complete", { ...flow.completion, installationId: "13" })).status, 200);
  assert.equal([...f.connections.values()][0].installationId, "13");
});

test("first-time users install, return through either callback, then verify and link", async () => {
  for (const route of ["setup", "connect/callback", "connect/callback?code=automatic-code&"]) {
    const f = fixture();
    f.provider.userInstallations = async () => [];
    const flow = await discover(f);
    assert.equal(flow.location.pathname, "/apps/test/installations/new");
    const state = flow.location.searchParams.get("state");
    const setup = await f.app.request(`https://api.example.test/v1/git/${route}${route.includes("?") ? "" : "?"}state=${state}${route.includes("?") ? "" : "&installation_id=12"}&setup_action=install`, { headers: { cookie: flow.cookie } });
    f.provider.userInstallations = async () => [{ id: 12, app_id: 123, suspended_at: null, account: { login: "alice", type: "User" } }];
    const authorization = new URL(setup.headers.get("location")!);
    assert.equal(authorization.pathname, "/login/oauth/authorize");
    const returned = await f.app.request(`https://api.example.test/v1/git/connect/callback?state=${authorization.searchParams.get("state")}&code=code`, { headers: { cookie: flow.cookie } });
    const destination = new URL(returned.headers.get("location")!);
    assert.equal((await flow.post("/complete", { ...flow.completion, code: destination.searchParams.get("code") })).status, 200);
  }
});

test("cancelled authorization retains the original import destination", async () => {
  const f = fixture();
  const start = await f.post("/connect", { clientProof: f.proof, returnTo: "/console/projects/project1/services/new" });
  const landing = await f.app.request((await start.json()).data.url);
  const state = new URL(landing.headers.get("location")!).searchParams.get("state");
  const response = await f.app.request(`https://api.example.test/v1/git/connect/callback?state=${state}&error=access_denied`, { headers: { cookie: landing.headers.get("set-cookie")!.split(";")[0] } });
  const destination = new URL(response.headers.get("location")!);
  assert.equal(destination.searchParams.get("error"), "cancelled");
  assert.equal(destination.searchParams.get("returnTo"), "/console/projects/project1/services/new");
  assert.equal(f.connections.size, 0);
});

test("callback exposes only a safe reason and logs the failed verification stage", async () => {
  const f = fixture();
  f.provider.exchangeCode = async () => { throw new GitHubError("do-not-expose", 400, "client_credentials", 200); };
  const logs: unknown[][] = [];
  const previous = console.error;
  console.error = (...args) => { logs.push(args); };
  try {
    const flow = await discover(f);
    assert.equal(flow.location.searchParams.get("error"), "client_credentials");
    assert.equal(flow.location.toString().includes("do-not-expose"), false);
    assert.deepEqual(logs, [["GitHub connection failed", { stage: "token_exchange", reason: "client_credentials", upstreamStatus: 200 }]]);
  } finally { console.error = previous; }
});

test("expired completion and cross-workspace installation takeover are rejected", async () => {
  const expired = await verifiedFlow();
  [...expired.attempts.values()][0].expiresAt = new Date(0);
  assert.equal((await expired.post("/complete", expired.completion)).status, 403);
  const f = await verifiedFlow();
  f.connections.set("other", { id: "other", installationId: "12", scopeKey: "developer:someone-else" });
  assert.equal((await f.post("/complete", f.completion)).status, 409);
  assert.equal(f.connections.get("other").scopeKey, "developer:someone-else");
});

test("members cannot manage workspace connections and repository access is scoped", async () => {
  const f = fixture();
  await assert.rejects(githubScope(f.db, "alice", { organizationId: "org" }, true), /owner/);
  f.connections.set("linked", { id: "linked", scopeKey: "developer:alice", suspended: false, repositoryIds: ["42"] });
  await assert.rejects(connectedRepository(f.db, "developer:bob", "linked", "42"), /not connected/);
  await assert.rejects(connectedRepository(f.db, "developer:alice", "linked", "99"), /not connected/);
  assert.equal((await connectedRepository(f.db, "developer:alice", "linked", "42")).id, "linked");
});

test("only a signed lifecycle webhook can disconnect an installation", async () => {
  const f = fixture();
  f.connections.set("linked", { id: "linked", installationId: "12" });
  const body = JSON.stringify({ action: "deleted", installation: { id: 12 } });
  const send = (signature: string) => f.app.request("https://api.example.test/v1/git/webhook", { method: "POST", body, headers: { "x-github-event": "installation", "x-hub-signature-256": signature } });
  assert.equal((await send("invalid")).status, 401);
  assert.equal(f.connections.size, 1);
  const signature = `sha256=${createHmac("sha256", "webhook-test-secret").update(body).digest("hex")}`;
  assert.equal((await send(signature)).status, 200);
  assert.equal(f.connections.size, 0);
  assert.equal((await send(signature)).status, 200);
});
