import { randomUUID } from "node:crypto";
import { mkdtemp, rm, writeFile, lstat } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { prisma } from "./db.js";
import { GitHubApp, githubConfig } from "./github-app.js";
import { connectedRepository } from "./github-scope.js";
import { redactBuildLogs, safeRelativePath } from "./build-policy.js";
import { collectOutput, docker, extractSource, readLimited } from "./build-sandbox.js";
import { putObject } from "./storage.js";
import { capFindings, scanFile } from "./secret-scan.js";
import { buildResources } from "./build-resources.js";

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
let stopping = false;
process.on("SIGTERM", () => { stopping = true; });
process.on("SIGINT", () => { stopping = true; });
const runtime = process.env.BUILD_CONTAINER_RUNTIME || "runsc";
const resources = buildResources();
if (resources.memoryMb * 1024 * 1024 + 384 * 1024 * 1024 > os.totalmem()) throw new Error("Build memory limit leaves insufficient host memory. Set BUILD_MEMORY_MB or resize the worker.");
if (process.env.NODE_ENV === "production" && runtime !== "runsc") throw new Error("Production builds require the runsc sandbox runtime.");
if (process.platform !== "linux") throw new Error("Run the build worker on Linux with Docker and gVisor.");
if (process.getuid!() === 0) throw new Error("Run the build worker as a dedicated non-root user.");

async function work() {
  // An abandoned build is failed, never reclaimed while its sandbox may exist.
  await prisma.$transaction(async tx => {
    const expired = await tx.buildJob.findMany({ where: { status: "building", startedAt: { lt: new Date(Date.now() - 20 * 60_000) } }, select: { id: true, deploymentId: true } });
    for (const job of expired) {
      const changed = await tx.buildJob.updateMany({ where: { id: job.id, status: "building" }, data: { status: "failed", finishedAt: new Date(), logs: "Worker stopped or build exceeded its time limit. Redeploy to retry." } });
      if (changed.count) await tx.deployment.update({ where: { id: job.deploymentId }, data: { status: "failed" } });
    }
  });
  const job = await prisma.$transaction(async tx => {
    const rows = await tx.$queryRaw<{ id: string }[]>`SELECT "id" FROM "BuildJob" WHERE "status" = 'queued' ORDER BY "createdAt" FOR UPDATE SKIP LOCKED LIMIT 1`;
    if (!rows[0]) return null;
    const claimed = await tx.buildJob.update({ where: { id: rows[0].id }, data: { status: "building", startedAt: new Date() }, include: { deployment: { include: { service: { include: { project: true } } } } } });
    await tx.deployment.update({ where: { id: claimed.deploymentId }, data: { status: "building" } });
    return claimed;
  });
  if (!job) return false;
  const service = job.deployment.service;
  const container = `keltri-build-${randomUUID()}`;
  let directory: string | undefined;
  let raw = "Preparing repository…\n";
  let secrets: string[] = [];
  let flush: Promise<unknown> = Promise.resolve();
  const saveLogs = () => {
    // Hold back the end of the stream: a secret can span stdout chunks.
    const tail = Math.max(1, ...secrets.map(value => value.length));
    const logs = redactBuildLogs(raw, secrets).slice(0, -tail);
    flush = flush.catch(() => {}).then(() => prisma.buildJob.updateMany({ where: { id: job.id, status: "building" }, data: { logs } }));
  };
  const interval = setInterval(saveLogs, 2000);
  try {
    if (!safeRelativePath(job.rootDir) || !safeRelativePath(job.outputDir)) throw new Error("Invalid build directories.");
    const scope = service.project.organizationId ? `organization:${service.project.organizationId}` : `developer:${service.project.developerId}`;
    const connection = await connectedRepository(prisma, scope, job.connectionId, job.repositoryId);
    const github = new GitHubApp(githubConfig());
    const token = await github.installationToken(connection.installationId, job.repositoryId);
    secrets.push(token);
    const response = await fetch(`https://api.github.com/repositories/${job.repositoryId}/zipball/${job.commitSha}`, {
      headers: { Authorization: `Bearer ${token}`, Accept: "application/vnd.github+json" }, signal: AbortSignal.timeout(60_000),
    });
    directory = await mkdtemp(path.join(os.tmpdir(), "keltri-build-"));
    const workspace = path.join(directory, "source");
    await extractSource(await readLimited(response), workspace);
    let buildRoot = workspace;
    for (const part of job.rootDir.split("/").filter(p => p && p !== ".")) {
      buildRoot = path.join(buildRoot, part);
      if (!(await lstat(buildRoot)).isDirectory()) throw new Error("Root directory does not exist.");
    }
    const vars = await prisma.envVar.findMany({ where: { serviceId: service.id, target: { in: ["all", job.target] } } });
    const env: Record<string, string> = {};
    for (const variable of [...vars.filter(v => v.target === "all"), ...vars.filter(v => v.target !== "all")]) env[variable.key] = variable.value;
    secrets.push(...Object.values(env));
    // Configuration is outside the source tree, mounted read-only. Only service
    // variables are passed, never worker/database/storage/GitHub credentials.
    await writeFile(path.join(directory, "config.json"), JSON.stringify({ env, command: job.buildCommand }), { mode: 0o600 });
    const script = `const fs=require('fs'), cp=require('child_process');
const c=JSON.parse(fs.readFileSync('/run/keltri-config.json','utf8'));
const env={...process.env,...c.env};
const install=fs.existsSync('pnpm-lock.yaml')?'pnpm install --frozen-lockfile':fs.existsSync('yarn.lock')?'if [ "$(yarn --version | cut -d. -f1)" = 1 ]; then yarn install --frozen-lockfile; else yarn install --immutable; fi':fs.existsSync('package-lock.json')?'npm ci':'npm install';
for(const command of [install,c.command]) cp.execFileSync('bash',['-e','-o','pipefail','-c',command],{env,stdio:'inherit'});`;
    raw += `Building ${job.branch}@${job.commitSha.slice(0, 8)}\n`;
    await docker(["run", "--name", container, "--runtime", runtime, "--network", resources.network, "--dns", "8.8.8.8",
      "--memory", `${resources.memoryMb}m`, "--memory-swap", `${resources.memoryMb}m`, "--cpus", String(resources.cpus), "--pids-limit", "256",
      "--log-driver", "none", "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "--read-only", "--tmpfs", `/tmp:rw,nosuid,size=${resources.tmpMb}m`,
      "--user", `${process.getuid!()}:${process.getgid!()}`,
      "--mount", `type=bind,src=${workspace},dst=/workspace`, "--mount", `type=bind,src=${path.join(directory, "config.json")},dst=/run/keltri-config.json,readonly`,
      "--workdir", `/workspace/${job.rootDir}`, process.env.BUILD_CONTAINER_IMAGE || "keltri-builder:local", "timeout", "--kill-after=10", "600", "node", "-e", script,
    ], text => { raw += text; if (raw.length > 2_000_000) raw = redactBuildLogs(raw, secrets); });
    // No process remains when walking artifacts. Reject links/special files.
    const files = await collectOutput(workspace, `${job.rootDir}/${job.outputDir}`);
    raw += "Publishing static files…\n";
    const prefix = `projects/${service.projectId}/services/${service.id}/deployments/${job.deploymentId}`;
    const findings = capFindings(files.flatMap(file => scanFile(file.name, file.bytes)));
    for (const file of files) await putObject(`${prefix}/${file.name}`, file.bytes);
    // Recheck access after the build in case the installation was disconnected.
    await connectedRepository(prisma, scope, job.connectionId, job.repositoryId);
    const currentLink = await prisma.serviceGitLink.findUnique({ where: { serviceId: service.id } });
    if (currentLink?.githubRepositoryId !== job.repositoryId || currentLink.githubInstallationId !== job.connectionId) throw new Error("Repository connection changed during the build.");
    const head = job.target === "production" && currentLink.defaultBranch === job.branch
      ? await github.branchCommit(connection.installationId, job.repositoryId, job.branch) : null;
    await prisma.$transaction(async tx => {
      // Serialize publication per service so two finishing builds cannot both
      // become production. GitHub's branch head (not webhook arrival order)
      // decides whether this commit is eligible for automatic publication.
      await tx.$queryRaw`SELECT "id" FROM "Service" WHERE "id" = ${service.id} FOR UPDATE`;
      const active = await tx.buildJob.findUnique({ where: { id: job.id } });
      if (active?.status !== "building") throw new Error("Build expired before publication.");
      // A newer publication may have finished while this worker was querying
      // GitHub. Never replace it using an earlier head observation.
      const laterPublication = await tx.deployment.count({ where: { serviceId: service.id, environment: "production", buildJob: { createdAt: { gt: job.createdAt } } } });
      const promote = head === job.commitSha && laterPublication === 0 && findings.length === 0;
      if (promote) await tx.deployment.updateMany({ where: { serviceId: service.id, environment: "production" }, data: { environment: "preview" } });
      await tx.deployment.update({ where: { id: job.deploymentId }, data: { status: "ready", environment: promote ? "production" : "preview", promotedAt: promote ? new Date() : null,
        fileCount: files.length, totalBytes: files.reduce((sum, f) => sum + f.bytes.length, 0), secretScanStatus: findings.length ? "flagged" : "clean", secretFindings: findings.length ? JSON.stringify(findings) : null } });
      raw += promote ? "Production deployment ready.\n" : "Preview ready. Review before promoting.\n";
      await tx.buildJob.update({ where: { id: job.id }, data: { status: "ready", finishedAt: new Date(), logs: redactBuildLogs(raw, secrets) } });
    });
  } catch (error) {
    raw += `\n${error instanceof Error ? error.message : "Build failed."}\n`;
    await prisma.$transaction(async tx => {
      const changed = await tx.buildJob.updateMany({ where: { id: job.id, status: "building" }, data: { status: "failed", finishedAt: new Date(), logs: redactBuildLogs(raw, secrets) } });
      if (changed.count) await tx.deployment.update({ where: { id: job.deploymentId }, data: { status: "failed" } });
    });
  } finally {
    clearInterval(interval);
    await flush.catch(() => {});
    await docker(["rm", "-f", container], () => {}, 15_000).catch(() => {});
    if (directory) await rm(directory, { recursive: true, force: true });
  }
  return true;
}

while (!stopping) {
  try { if (!await work()) await delay(3000); }
  catch { console.error("Build worker could not process jobs. Check database and worker configuration."); await delay(5000); }
}
await prisma.$disconnect();
