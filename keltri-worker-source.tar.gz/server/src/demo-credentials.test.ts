import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  DEMO_API_KEY,
  DEMO_EMAIL,
  DEMO_PASSWORD,
  isForbiddenProductionAccount,
  isForbiddenProductionLogin,
  isForbiddenProductionToken,
  isProductionEnv,
} from "./demo-credentials.js";

describe("demo credentials", () => {
  it("treats NODE_ENV=production as production", () => {
    assert.equal(isProductionEnv("production"), true);
    assert.equal(isProductionEnv("development"), false);
    assert.equal(isProductionEnv(undefined), false);
  });

  it("rejects the seeded portal login in production", () => {
    assert.equal(isForbiddenProductionLogin(DEMO_EMAIL, "any-password"), true);
    assert.equal(
      isForbiddenProductionLogin("dev@example.com", DEMO_PASSWORD),
      true,
    );
    assert.equal(
      isForbiddenProductionLogin("dev@example.com", "a-real-password"),
      false,
    );
  });

  it("rejects the seeded CLI key and demo account", () => {
    assert.equal(isForbiddenProductionToken(DEMO_API_KEY), true);
    assert.equal(isForbiddenProductionToken("qa_live_not_seed"), false);
    assert.equal(isForbiddenProductionAccount(DEMO_EMAIL), true);
    assert.equal(isForbiddenProductionAccount("ops@example.com"), false);
  });
});
