import JSZip from "jszip";
import { capFindings, scanFile, type SecretFinding } from "./secret-scan.js";
import { putObject } from "./storage.js";

export type ExtractedBundle = {
  fileCount: number;
  totalBytes: number;
  secretFindings: SecretFinding[];
};

// Extracts a zipped static-site build (whatever `buildCommand` produced,
// e.g. `dist/` or `out/`) into storage under `prefix/`, keyed by each
// file's path inside the zip. Mirrors how parseApk() unpacks a mini-app
// bundle out of an APK in apk.ts. Scans each file for secrets while it's
// already in memory, rather than re-fetching from storage afterward.
export async function extractBundleToStorage(
  buffer: Buffer,
  prefix: string,
): Promise<ExtractedBundle> {
  const zip = await JSZip.loadAsync(buffer).catch(() => null);
  if (!zip) throw new Error("Not a valid zip archive");

  const files = Object.values(zip.files).filter((file) => !file.dir);
  if (files.length === 0) throw new Error("Zip archive is empty");

  let totalBytes = 0;
  const secretFindings: SecretFinding[] = [];
  for (const file of files) {
    const data = await file.async("nodebuffer");
    await putObject(`${prefix}/${file.name}`, data);
    totalBytes += data.length;
    secretFindings.push(...scanFile(file.name, data));
  }

  return {
    fileCount: files.length,
    totalBytes,
    secretFindings: capFindings(secretFindings),
  };
}
