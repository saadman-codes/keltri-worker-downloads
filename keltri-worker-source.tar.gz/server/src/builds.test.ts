import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, mkdir, rm, writeFile, readFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import JSZip from "jszip";
import type { PrismaClient } from "@prisma/client";
import { enqueueBuild, enqueuePush } from "./build-queue.js";
import { pushBuild, redactBuildLogs, safeRelativePath } from "./build-policy.js";
import { extractSource, collectOutput } from "./build-sandbox.js";
import { detectFromPackageJson } from "./github-framework.js";
import { buildResources } from "./build-resources.js";

const push = { installation: { id: 12 }, repository: { id: 42 }, ref: "refs/heads/main", after: "a".repeat(40) };
test("small workers have configurable limits and reject invalid resource values", () => {
  assert.equal(buildResources({ BUILD_MEMORY_MB: "512", BUILD_CPUS: "0.5" }).memoryMb, 512);
  assert.equal(buildResources({ BUILD_CPUS: "0.5" }).cpus, 0.5);
  assert.equal(buildResources({}).network, "keltri-build");
  assert.throws(() => buildResources({ BUILD_MEMORY_MB: "0" }));
  assert.throws(() => buildResources({ BUILD_CPUS: "NaN" }));
});
test("Next.js detection targets static export output", () => {
  assert.equal(detectFromPackageJson({ dependencies: { next: "15" } }).outputDir, "out");
});
test("only non-deletion branch pushes with immutable commits are buildable", () => {
  assert.equal(pushBuild(push)?.branch, "main");
  for (const invalid of [null, {}, { ...push, deleted: true }, { ...push, ref: "refs/tags/v1" }, { ...push, after: "0".repeat(40) }, { ...push, after: "main" }, { ...push, repository: { id: -1 } }]) assert.equal(pushBuild(invalid), null);
});
test("build directories cannot escape the repository", () => {
  for (const value of [".", "apps/web", "dist"]) assert.ok(safeRelativePath(value));
  for (const value of ["", "../outside", "apps/../../etc", "/etc", "C:\\temp", "apps\\web", "a\nb"]) assert.equal(safeRelativePath(value), false);
});
test("logs redact complete secrets assembled across output chunks", () => {
  assert.equal(redactBuildLogs("start super" + "secret done", ["supersecret"]), "start [REDACTED] done");
  assert.ok(redactBuildLogs("a".repeat(100_000), []).length <= 64_000);
});

function database() {
  const jobs = new Map<string, any>();
  const connection = { id: "connection", suspended: false, repositoryIds: ["42"] };
  const link = { serviceId: "web", defaultBranch: "main", githubRepositoryId: "42", githubInstallation: connection,
    service: { type: "web", rootDir: ".", buildCommand: "npm run build", outputDir: "dist" } };
  let filter: unknown;
  const db = {
    serviceGitLink: { findUnique: async () => link, findMany: async ({ where }: any) => { filter = where; return [link]; } },
    buildJob: { upsert: async ({ where, create }: any) => { if (!jobs.has(where.dedupeKey)) jobs.set(where.dedupeKey, { id: String(jobs.size), ...create }); return jobs.get(where.dedupeKey); } },
  } as unknown as PrismaClient;
  return { db, jobs, connection, link, filter: () => filter };
}
test("redelivered pushes create one job and default branch selects production", async () => {
  const f = database();
  await enqueuePush(f.db, push, "delivery");
  await enqueuePush(f.db, push, "delivery");
  assert.equal(f.jobs.size, 1);
  assert.equal([...f.jobs.values()][0].target, "production");
  assert.deepEqual(f.filter(), { githubRepositoryId: "42", githubInstallation: { installationId: "12", suspended: false } });
  await enqueueBuild(f.db, "web", push.after, "feature", "other");
  assert.equal([...f.jobs.values()][1].target, "preview");
});
test("suspended, unapproved repositories and backend services never queue", async () => {
  const f = database();
  f.connection.suspended = true;
  assert.equal(await enqueueBuild(f.db, "web", push.after, "main", "1"), null);
  f.connection.suspended = false; f.connection.repositoryIds = [];
  assert.equal(await enqueueBuild(f.db, "web", push.after, "main", "2"), null);
  f.connection.repositoryIds = ["42"]; f.link.service.type = "backend";
  assert.equal(await enqueueBuild(f.db, "web", push.after, "main", "3"), null);
  assert.equal(f.jobs.size, 0);
});
test("archive extraction strips GitHub's prefix and rejects symlinks", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "keltri-test-"));
  try {
    const zip = new JSZip().file("repo-sha/package.json", "{}");
    await extractSource(await zip.generateAsync({ type: "nodebuffer" }), root);
    assert.equal(await readFile(path.join(root, "package.json"), "utf8"), "{}");
    const bad = new JSZip().file("repo-sha/link", "/etc/passwd", { unixPermissions: 0o120777 });
    await assert.rejects(extractSource(await bad.generateAsync({ type: "nodebuffer", platform: "UNIX" }), root), /unsafe/);
  } finally { await rm(root, { recursive: true, force: true }); }
});
test("static artifacts require index.html and preserve nested assets", async () => {
  const root = await mkdtemp(path.join(os.tmpdir(), "keltri-test-"));
  try {
    await mkdir(path.join(root, "dist", "assets"), { recursive: true });
    await writeFile(path.join(root, "dist", "assets", "app.js"), "console.log(1)");
    await assert.rejects(collectOutput(root, "dist"), /index.html/);
    await writeFile(path.join(root, "dist", "index.html"), "<html></html>");
    const files = await collectOutput(root, "dist");
    assert.deepEqual(files.map(f => f.name).sort(), ["assets/app.js", "index.html"]);
    await assert.rejects(collectOutput(root, "../outside"), /relative/);
  } finally { await rm(root, { recursive: true, force: true }); }
});
