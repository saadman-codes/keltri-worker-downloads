import { createHmac } from "node:crypto";
import { prisma } from "./db.js";

export async function fireWebhook(
  developerId: string,
  event: string,
  payload: Record<string, unknown>,
) {
  const hooks = await prisma.webhook.findMany({ where: { developerId } });
  const body = JSON.stringify({ event, payload, at: new Date().toISOString() });

  await Promise.all(
    hooks.map(async (hook) => {
      const events = JSON.parse(hook.events || "[]") as string[];
      if (events.length > 0 && !events.includes(event)) return;
      const signature = createHmac("sha256", hook.secret)
        .update(body)
        .digest("hex");
      try {
        await fetch(hook.url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-Keltri-Event": event,
            "X-Keltri-Signature": signature,
          },
          body,
        });
      } catch {
        // Best-effort delivery.
      }
    }),
  );
}
