import { isProductionEnv } from "./demo-credentials.js";

export function assertSeedAllowed(nodeEnv = process.env.NODE_ENV) {
  if (isProductionEnv(nodeEnv)) {
    throw new Error(
      "Refusing to seed: NODE_ENV=production. Demo catalog users and install counts are for local development only (`pnpm db:seed` with NODE_ENV unset or development).",
    );
  }
}
