import { createHash, createHmac, randomBytes, sign, timingSafeEqual } from "node:crypto";
import { readFileSync } from "node:fs";

export class GitHubError extends Error {
  constructor(message: string, public status = 502, public reason = "verification", public upstreamStatus?: number) { super(message); }
}
export type GitHubAppConfig = {
  appId: string; clientId: string; clientSecret: string; slug: string;
  privateKey: string; apiOrigin: string;
};
function envValue(value: string | undefined) {
  const trimmed = value?.trim() ?? "";
  // Dashboard environment editors may retain quotes copied from .env examples.
  return ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")))
    ? trimmed.slice(1, -1).trim() : trimmed;
}
export function githubConfigured() {
  try { githubConfig(); return true; } catch { return false; }
}
export function githubConfig(env: NodeJS.ProcessEnv = process.env): GitHubAppConfig {
  const appId = envValue(env.GITHUB_APP_ID);
  const clientId = envValue(env.GITHUB_APP_CLIENT_ID);
  const clientSecret = envValue(env.GITHUB_APP_CLIENT_SECRET);
  const slug = envValue(env.GITHUB_APP_SLUG);
  const key = envValue(env.GITHUB_APP_PRIVATE_KEY);
  const keyPath = envValue(env.GITHUB_APP_PRIVATE_KEY_PATH);
  if (!appId || !clientId || !clientSecret || !slug || (!key && !keyPath)) {
    throw new GitHubError("GitHub App is not configured on the server.", 503, "configuration");
  }
  let origin: URL;
  try { origin = new URL(envValue(env.API_ORIGIN) || (env.NODE_ENV === "production" ? "" : "http://localhost:4000")); }
  catch { throw new GitHubError("GitHub App requires a valid API_ORIGIN.", 503, "configuration"); }
  if (!['http:', 'https:'].includes(origin.protocol) || origin.username || origin.password || origin.search || origin.hash || origin.pathname !== "/" || (env.NODE_ENV === "production" && origin.protocol !== "https:")) {
    throw new GitHubError("API_ORIGIN must be an origin without a path or credentials, and HTTPS in production.", 503, "configuration");
  }
  let privateKey: string;
  try { privateKey = (key || readFileSync(keyPath, "utf8")).replace(/\\n/g, "\n"); }
  catch { throw new GitHubError("The GitHub App private-key file could not be read.", 503, "private_key"); }
  return { appId, clientId, clientSecret, slug, privateKey, apiOrigin: origin.origin };
}
export const hashState = (value: string) => createHash("sha256").update(value).digest("hex");
export const pkceChallenge = (value: string) => createHash("sha256").update(value).digest("base64url");
export const validGitHubId = (value: unknown): value is string => typeof value === "string" && /^[1-9][0-9]{0,15}$/.test(value) && Number.isSafeInteger(Number(value));

export function appJwt(config: GitHubAppConfig, now = Date.now()) {
  const seconds = Math.floor(now / 1000);
  const header = Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(JSON.stringify({ iat: seconds - 60, exp: seconds + 540, iss: config.clientId })).toString("base64url");
  const body = `${header}.${payload}`;
  try {
    return `${body}.${sign("RSA-SHA256", Buffer.from(body), config.privateKey).toString("base64url")}`;
  } catch {
    throw new GitHubError("The server cannot read the GitHub App private key.", 503, "private_key");
  }
}

export function verifyGitHubSignature(body: Uint8Array, signature: string | undefined, secret: string) {
  if (!secret || !signature || !/^sha256=[a-f0-9]{64}$/.test(signature)) return false;
  const expected = createHmac("sha256", secret).update(body).digest();
  return timingSafeEqual(expected, Buffer.from(signature.slice(7), "hex"));
}

export type GitHubRepo = {
  id: number; name: string; full_name: string; default_branch: string;
  private: boolean; updated_at: string;
};
export type Installation = {
  id: number; app_id: number; suspended_at: string | null;
  account: { login: string; type: string };
};

export class GitHubApp {
  constructor(public config: GitHubAppConfig, private fetcher: typeof fetch = fetch) {}
  async request<T>(path: string, token: string, init: RequestInit = {}): Promise<T> {
    const response = await this.fetcher(`https://api.github.com${path}`, {
      ...init, signal: AbortSignal.timeout(15000),
      headers: { Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28", Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    });
    if (!response.ok) throw new GitHubError(
      response.status === 401 || response.status === 403 || response.status === 404
        ? "GitHub access is unavailable. Reconnect the installation and check repository permissions."
        : "GitHub is unavailable. Please try again.", response.status === 404 ? 404 : 502,
      response.status === 401 ? (path.startsWith("/app/") ? "app_credentials" : "user_token")
        : response.status === 403 ? "github_permissions" : response.status === 404 ? "installation_unavailable" : "github_unavailable", response.status);
    return await response.json() as T;
  }
  async pages<T>(path: string, key: string, token: string): Promise<T[]> {
    const values: T[] = [];
    for (let page = 1; page <= 100; page++) {
      const data = await this.request<Record<string, T[]>>(`${path}${path.includes("?") ? "&" : "?"}per_page=100&page=${page}`, token);
      const batch = data[key];
      if (!Array.isArray(batch)) throw new GitHubError("Unexpected response from GitHub.");
      values.push(...batch);
      if (batch.length < 100) return values;
    }
    throw new GitHubError("Too many repositories to connect at once. Select fewer repositories on GitHub.", 400);
  }
  installationUrl(state: string) {
    return `https://github.com/apps/${encodeURIComponent(this.config.slug)}/installations/new?state=${encodeURIComponent(state)}`;
  }
  authorizationUrl(state: string, verifier: string) {
    const url = new URL("https://github.com/login/oauth/authorize");
    url.search = new URLSearchParams({ client_id: this.config.clientId, state,
      redirect_uri: `${this.config.apiOrigin}/v1/git/connect/callback`,
      code_challenge: pkceChallenge(verifier), code_challenge_method: "S256" }).toString();
    return url.toString();
  }
  async exchangeCode(code: string, verifier: string) {
    const response = await this.fetcher("https://github.com/login/oauth/access_token", {
      method: "POST", signal: AbortSignal.timeout(15000),
      headers: { Accept: "application/json", "Content-Type": "application/json" },
      body: JSON.stringify({ client_id: this.config.clientId, client_secret: this.config.clientSecret,
        code, code_verifier: verifier, redirect_uri: `${this.config.apiOrigin}/v1/git/connect/callback` }),
    });
    const data: unknown = await response.json().catch(() => null);
    if (!data || typeof data !== "object") throw new GitHubError("GitHub returned an invalid token response.", 502, "token_exchange", response.status);
    const tokenResponse = data as { access_token?: unknown; error?: unknown };
    if (!response.ok || typeof tokenResponse.access_token !== "string" || !tokenResponse.access_token || tokenResponse.error) {
      const reason = tokenResponse.error === "incorrect_client_credentials" ? "client_credentials"
        : tokenResponse.error === "redirect_uri_mismatch" ? "callback_mismatch"
        : tokenResponse.error === "bad_verification_code" ? "authorization_code" : "token_exchange";
      throw new GitHubError("GitHub authorization did not complete. Please reconnect.", 400, reason, response.status);
    }
    return tokenResponse.access_token;
  }
  async checkConnectionConfiguration() {
    // A deliberately invalid code cannot create a user token. GitHub validates
    // the client credentials and redirect URI before rejecting this code.
    try {
      await this.exchangeCode(`keltri-preflight-${randomBytes(24).toString("hex")}`, randomBytes(32).toString("base64url"));
    } catch (error) {
      if (error instanceof GitHubError && error.reason === "authorization_code") return;
      if (error instanceof GitHubError && error.reason === "client_credentials") {
        throw new GitHubError("GitHub connection is unavailable because the server's App credentials were rejected. No installation changes are needed; contact the platform administrator.", 503, "client_credentials");
      }
      if (error instanceof GitHubError && error.reason === "callback_mismatch") {
        throw new GitHubError("GitHub connection is unavailable because the server's callback URL is not registered. Contact the platform administrator.", 503, "callback_mismatch");
      }
      throw new GitHubError("Could not check GitHub availability. Try again shortly.", 503, "github_unavailable");
    }
    throw new GitHubError("GitHub returned an unexpected configuration-check response.", 503, "configuration");
  }
  async userInstallations(userToken: string) {
    return (await this.pages<Installation>("/user/installations", "installations", userToken))
      .filter(i => String(i.app_id) === this.config.appId && !i.suspended_at);
  }
  async verifyInstallation(installationId: string, userToken: string) {
    const installations = await this.pages<Installation>("/user/installations", "installations", userToken);
    if (!installations.some(i => String(i.id) === installationId && String(i.app_id) === this.config.appId)) {
      throw new GitHubError("Your GitHub account cannot access this installation.", 403);
    }
    const installation = await this.request<Installation>(`/app/installations/${installationId}`, appJwt(this.config));
    if (installation.suspended_at || String(installation.app_id) !== this.config.appId) throw new GitHubError("This installation is unavailable.", 403);
    const user = await this.request<{ id: number }>("/user", userToken);
    const repos = await this.pages<GitHubRepo>(`/user/installations/${installationId}/repositories`, "repositories", userToken);
    return { installation, userId: String(user.id), repositoryIds: repos.map(r => String(r.id)) };
  }
  async installationToken(installationId: string, repositoryId?: string) {
    const token = await this.request<{ token: string }>(`/app/installations/${installationId}/access_tokens`, appJwt(this.config), {
      method: "POST", body: JSON.stringify({ permissions: { contents: "read" }, ...(repositoryId ? { repository_ids: [Number(repositoryId)] } : {}) }),
    });
    return token.token;
  }
  async repositories(installationId: string, allowedIds: string[]) {
    if (!allowedIds.length) return [];
    const token = await this.installationToken(installationId);
    const repos = await this.pages<GitHubRepo>("/installation/repositories", "repositories", token);
    const allowed = new Set(allowedIds);
    return repos.filter(repo => allowed.has(String(repo.id)));
  }
  async repository(installationId: string, repositoryId: string) {
    const token = await this.installationToken(installationId, repositoryId);
    return this.request<GitHubRepo>(`/repositories/${repositoryId}`, token);
  }
  async branchCommit(installationId: string, repositoryId: string, branch: string) {
    const token = await this.installationToken(installationId, repositoryId);
    const commit = await this.request<{ sha: string }>(`/repositories/${repositoryId}/commits/${encodeURIComponent(branch)}`, token);
    if (!/^[a-f0-9]{40}$/.test(commit.sha)) throw new GitHubError("Invalid commit returned by GitHub.");
    return commit.sha;
  }
  async packageJson(installationId: string, repositoryId: string, repo: GitHubRepo) {
    const token = await this.installationToken(installationId, repositoryId);
    const path = repo.full_name.split("/").map(encodeURIComponent).join("/");
    try {
      const file = await this.request<{ content?: string; encoding?: string }>(`/repos/${path}/contents/package.json?ref=${encodeURIComponent(repo.default_branch)}`, token);
      if (file.encoding !== "base64" || !file.content) return {};
      const parsed: unknown = JSON.parse(Buffer.from(file.content, "base64").toString("utf8"));
      return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed as Record<string, unknown> : {};
    } catch (error) {
      if ((error instanceof GitHubError && error.status === 404) || error instanceof SyntaxError) return {};
      throw error;
    }
  }
}
