import { prisma } from "./db.js";

// Never blocks the caller and never throws -- a logging failure must not
// break the mutation it's describing. metadata must never include secret
// material (env var values, webhook secrets, API key tokens): only
// non-sensitive identifiers like names, urls, prefixes, and keys.
export async function logAudit(
  developerId: string,
  action: string,
  targetType: string,
  targetId?: string,
  metadata?: Record<string, unknown>,
) {
  try {
    await prisma.auditLog.create({
      data: {
        developerId,
        action,
        targetType,
        targetId,
        metadata: metadata ? JSON.stringify(metadata) : null,
      },
    });
  } catch {
    // Best-effort, matches fireWebhook's delivery posture.
  }
}
