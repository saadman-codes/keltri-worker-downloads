import assert from "node:assert/strict";
import test from "node:test";
import { createHmac, generateKeyPairSync, verify, randomUUID } from "node:crypto";
import { writeFileSync, unlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { GitHubApp, appJwt, verifyGitHubSignature, validGitHubId, githubConfig, pkceChallenge } from "./github-app.js";

const keys = generateKeyPairSync("rsa", { modulusLength: 2048 });
const config = { appId: "123", clientId: "Iv.test", clientSecret: "test-secret", slug: "test-app", apiOrigin: "https://api.example.test", privateKey: keys.privateKey.export({ type: "pkcs8", format: "pem" }).toString() };

const env = {
  NODE_ENV: "production", GITHUB_APP_ID: ' "123" ', GITHUB_APP_CLIENT_ID: ' "Iv.test" ',
  GITHUB_APP_CLIENT_SECRET: " 'test-secret' ", GITHUB_APP_SLUG: ' "test-app" ',
  GITHUB_APP_PRIVATE_KEY: `"${config.privateKey.replace(/\n/g, "\\n")}"`, API_ORIGIN: ' "https://api.example.test/" ',
};

test("dashboard env quotes are removed and the exact App credentials and PKCE proof reach GitHub", async () => {
  const parsed = githubConfig(env);
  assert.equal(parsed.privateKey.trim(), config.privateKey.trim());
  const app = new GitHubApp(parsed, (async (url: string | URL | Request, init?: RequestInit) => {
    assert.equal(url, "https://github.com/login/oauth/access_token");
    assert.equal(init?.method, "POST");
    assert.equal((init?.headers as Record<string, string>)["Content-Type"], "application/json");
    assert.deepEqual(JSON.parse(String(init?.body)), {
      client_id: "Iv.test", client_secret: "test-secret", code: "fresh-code",
      code_verifier: "original-verifier", redirect_uri: "https://api.example.test/v1/git/connect/callback",
    });
    return Response.json({ access_token: "temporary-user-token" });
  }) as typeof fetch);
  const authorization = new URL(app.authorizationUrl("state", "original-verifier"));
  assert.equal(authorization.searchParams.get("client_id"), "Iv.test");
  assert.equal(authorization.searchParams.get("code_challenge"), pkceChallenge("original-verifier"));
  assert.equal(authorization.searchParams.get("redirect_uri"), "https://api.example.test/v1/git/connect/callback");
  assert.equal(await app.exchangeCode("fresh-code", "original-verifier"), "temporary-user-token");
});

test("empty credentials and malformed API origins fail before redirecting users", () => {
  for (const secret of ["", "  ", '""', "'  '"]) {
    assert.throws(() => githubConfig({ ...env, GITHUB_APP_CLIENT_SECRET: secret }), (error: any) => error.reason === "configuration");
  }
  for (const origin of ["", "not-a-url", "http://api.example.test", "https://api.example.test/v1", "https://api.example.test?query=value", "https://user:password@api.example.test"]) {
    assert.throws(() => githubConfig({ ...env, API_ORIGIN: origin }), (error: any) => error.reason === "configuration" && !error.message.includes("password"));
  }
});

test("PEM files copied with escaped newlines can sign App JWTs", () => {
  const path = join(tmpdir(), `keltri-key-test-${randomUUID()}.pem`);
  try {
    writeFileSync(path, config.privateKey.replace(/\n/g, "\\n"));
    const parsed = githubConfig({ ...env, GITHUB_APP_PRIVATE_KEY: "", GITHUB_APP_PRIVATE_KEY_PATH: path });
    const [header, payload, signature] = appJwt(parsed).split(".");
    assert.ok(verify("RSA-SHA256", Buffer.from(`${header}.${payload}`), keys.publicKey, Buffer.from(signature, "base64url")));
  } finally { unlinkSync(path); }
});

test("malformed token responses never become user credentials", async () => {
  for (const body of ["null", "<html>Gateway error</html>", '{"access_token":42}', '{"access_token":"token","error":"incorrect_client_credentials"}']) {
    const app = new GitHubApp(config, (async () => new Response(body)) as typeof fetch);
    await assert.rejects(app.exchangeCode("code", "verifier"), (error: any) => ["token_exchange", "client_credentials"].includes(error.reason));
  }
});

test("App JWT uses the client ID and a bounded, signed lifetime", () => {
  const jwt = appJwt(config, 1_800_000_000_000);
  const [header, payload, signature] = jwt.split(".");
  assert.deepEqual(JSON.parse(Buffer.from(payload, "base64url").toString()), { iat: 1799999940, exp: 1800000540, iss: "Iv.test" });
  assert.ok(verify("RSA-SHA256", Buffer.from(`${header}.${payload}`), keys.publicKey, Buffer.from(signature, "base64url")));
});

test("webhooks require the exact signed body and secret", () => {
  const body = Buffer.from('{"action":"deleted"}');
  const signature = `sha256=${createHmac("sha256", "secret").update(body).digest("hex")}`;
  assert.equal(verifyGitHubSignature(body, signature, "secret"), true);
  assert.equal(verifyGitHubSignature(Buffer.from("{}"), signature, "secret"), false);
  assert.equal(verifyGitHubSignature(body, signature, "wrong"), false);
  assert.equal(verifyGitHubSignature(body, undefined, "secret"), false);
  assert.equal(verifyGitHubSignature(body, "sha256=bad", "secret"), false);
});

test("installation selection is checked against the authorizing GitHub user", async () => {
  const app = new GitHubApp(config, (async () => Response.json({ installations: [{ id: 12, app_id: 123 }] })) as typeof fetch);
  await assert.rejects(app.verifyInstallation("99", "user-token"), /cannot access/);
});

test("repository browsing filters installation permissions to verified user access", async () => {
  const app = new GitHubApp(config, (async (url: string | URL | Request) => {
    if (String(url).includes("access_tokens")) return Response.json({ token: "installation-token" });
    return Response.json({ repositories: [{ id: 1 }, { id: 2 }] });
  }) as typeof fetch);
  assert.deepEqual(await app.repositories("12", ["2"]), [{ id: 2 }]);
});

test("single repository reads mint a token restricted to that repository", async () => {
  const app = new GitHubApp(config, (async (url: string | URL | Request, init?: RequestInit) => {
    if (String(url).includes("access_tokens")) {
      assert.deepEqual(JSON.parse(String(init?.body)), { permissions: { contents: "read" }, repository_ids: [42] });
      return Response.json({ token: "restricted-token" });
    }
    assert.equal((init?.headers as Record<string, string>).Authorization, "Bearer restricted-token");
    return Response.json({ id: 42 });
  }) as typeof fetch);
  assert.deepEqual(await app.repository("12", "42"), { id: 42 });
});

test("repository IDs cannot round to a different numeric ID", () => {
  assert.equal(validGitHubId("42"), true);
  for (const value of ["0", "-1", "01", "9007199254740993", "../42"]) assert.equal(validGitHubId(value), false);
});

test("code exchange classifies GitHub failures without exposing response secrets", async () => {
  for (const [error, reason] of [["incorrect_client_credentials", "client_credentials"], ["redirect_uri_mismatch", "callback_mismatch"], ["bad_verification_code", "authorization_code"], ["unknown", "token_exchange"]]) {
    const app = new GitHubApp(config, (async () => Response.json({ error, error_description: "sensitive upstream content" })) as typeof fetch);
    await assert.rejects(app.exchangeCode("code", "verifier"), (failure: any) => {
      assert.equal(failure.reason, reason);
      assert.equal(failure.message.includes("sensitive"), false);
      return true;
    });
  }
});

test("invalid private keys produce a safe actionable error", () => {
  assert.throws(() => appJwt({ ...config, privateKey: "invalid-key" }), (error: any) => error.reason === "private_key" && !error.message.includes("invalid-key"));
});

test("connection preflight accepts only GitHub's invalid-code response", async () => {
  for (const [error, expected] of [["bad_verification_code", "ready"], ["incorrect_client_credentials", "client_credentials"], ["redirect_uri_mismatch", "callback_mismatch"]]) {
    const app = new GitHubApp(config, (async (_url, init) => {
      const body = JSON.parse(String(init?.body));
      assert.match(body.code, /^keltri-preflight-/);
      assert.equal(body.redirect_uri, `${config.apiOrigin}/v1/git/connect/callback`);
      return Response.json({ error });
    }) as typeof fetch);
    if (expected === "ready") await app.checkConnectionConfiguration();
    else await assert.rejects(app.checkConnectionConfiguration(), (failure: any) => failure.reason === expected && failure.status === 503);
  }
});
