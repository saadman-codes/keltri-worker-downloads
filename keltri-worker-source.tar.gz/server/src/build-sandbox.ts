import { spawn } from "node:child_process";
import { lstat, mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import JSZip from "jszip";
import { safeRelativePath } from "./build-policy.js";

const LIMIT = 100 * 1024 * 1024;
export async function readLimited(response: Response) {
  if (!response.ok || !response.body) throw new Error("Could not download repository archive.");
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of response.body as unknown as AsyncIterable<Uint8Array>) {
    size += chunk.length;
    if (size > LIMIT) throw new Error("Repository archive exceeds 100 MB.");
    chunks.push(Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}

// ZIP contents are data, never executable on the worker host. GitHub adds a
// single top-level directory. Reject symlinks and traversal before writing.
export async function extractSource(bytes: Buffer, destination: string) {
  const zip = await JSZip.loadAsync(bytes);
  let size = 0;
  const files = Object.values(zip.files);
  if (files.length > 20_000) throw new Error("Repository has too many files.");
  for (const entry of files) {
    const original = (entry as typeof entry & { unsafeOriginalName?: string }).unsafeOriginalName ?? entry.name;
    const name = original.split("/").slice(1).join("/");
    if (!name) continue;
    if (!safeRelativePath(name) || (Number(entry.unixPermissions) & 0o170000) === 0o120000) throw new Error("Repository contains an unsafe path or symlink.");
    const target = path.join(destination, name);
    if (entry.dir) { await mkdir(target, { recursive: true }); continue; }
    const chunks: Buffer[] = [];
    for await (const chunk of new Readable().wrap(entry.nodeStream())) {
      size += chunk.length;
      if (size > LIMIT) throw new Error("Expanded repository exceeds 100 MB.");
      chunks.push(Buffer.from(chunk));
    }
    await mkdir(path.dirname(target), { recursive: true });
    await writeFile(target, Buffer.concat(chunks), { mode: (Number(entry.unixPermissions) & 0o111) ? 0o755 : 0o644 });
  }
}

export async function collectOutput(root: string, outputDir: string) {
  if (!safeRelativePath(outputDir)) throw new Error("Output directory must be relative without ..");
  let current = root;
  for (const part of outputDir.split("/").filter(p => p !== "." && p !== "")) {
    current = path.join(current, part);
    if (!(await lstat(current)).isDirectory()) throw new Error("Output directory must not be a symlink.");
  }
  const files: { name: string; bytes: Buffer }[] = [];
  let size = 0;
  let visited = 0;
  async function visit(dir: string, prefix = "") {
    for (const entry of await readdir(dir, { withFileTypes: true })) {
      if (++visited > 20_000 || prefix.split("/").length > 50) throw new Error("Build output contains too many directories.");
      const name = prefix + entry.name;
      const filename = path.join(dir, entry.name);
      if (entry.isSymbolicLink() || !entry.isDirectory() && !entry.isFile()) throw new Error("Build output contains an unsupported file.");
      if (entry.isDirectory()) { await visit(filename, name + "/"); continue; }
      size += (await lstat(filename)).size;
      if (size > LIMIT || files.length >= 10_000) throw new Error("Build output exceeds 100 MB or 10,000 files.");
      files.push({ name, bytes: await readFile(filename) });
    }
  }
  await visit(current);
  if (!files.some(f => f.name === "index.html")) throw new Error("Output must contain index.html. Server-rendered apps require a static export.");
  return files;
}

export function docker(args: string[], log: (text: string) => void, timeout = 600_000) {
  return new Promise<void>((resolve, reject) => {
    const child = spawn("docker", args, { stdio: ["ignore", "pipe", "pipe"] });
    const timer = setTimeout(() => { child.kill("SIGKILL"); reject(new Error("Build timed out.")); }, timeout);
    child.stdout.on("data", bytes => log(bytes.toString()));
    child.stderr.on("data", bytes => log(bytes.toString()));
    child.on("error", () => { clearTimeout(timer); reject(new Error("Could not start the build sandbox.")); });
    child.on("close", code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error("Build failed. Review the build logs.")); });
  });
}
