import { serve } from "@hono/node-server";
import { app } from "./app.js";

// Force-redeploy marker: bumps the build so a fresh env var set is picked up.

const port = Number(process.env.PORT ?? 4000);

serve({ fetch: app.fetch, port }, () => {
  console.log(`Keltri API listening on http://localhost:${port}`);
});
