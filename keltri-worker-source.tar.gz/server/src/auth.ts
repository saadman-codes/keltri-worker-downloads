import { createHash, randomBytes } from "node:crypto";
import { deleteCookie, getCookie, setCookie } from "hono/cookie";
import type { MiddlewareHandler } from "hono";
import { prisma } from "./db.js";

import type { Developer } from "@prisma/client";
import {
  isForbiddenProductionAccount,
  isForbiddenProductionToken,
  isProductionEnv,
} from "./demo-credentials.js";

export const SESSION_COOKIE = "qa_session";

// Strip legacy repository credentials even before the migration clears them.
export function publicDeveloper(developer: Developer) {
  const { passwordHash: _passwordHash, githubRepoToken: _githubRepoToken, ...rest } = developer;
  // Repository access now belongs to workspaces; clients use /git/status.
  return { ...rest, githubConnected: false };
}

export function hashKey(key: string) {
  return createHash("sha256").update(key).digest("hex");
}

export function newApiKey() {
  const raw = `qa_${randomBytes(24).toString("base64url")}`;
  return { raw, hashedKey: hashKey(raw), prefix: raw.slice(0, 8) };
}

export function newSessionToken() {
  const raw = `qa_sess_${randomBytes(24).toString("base64url")}`;
  return { raw, hashedKey: hashKey(raw) };
}

export async function createSession(developerId: string) {
  const token = newSessionToken();
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 30);
  await prisma.session.create({
    data: {
      developerId,
      tokenHash: token.hashedKey,
      expiresAt,
    },
  });
  return { token: token.raw, expiresAt };
}

export function attachSessionCookie(
  c: Parameters<MiddlewareHandler>[0],
  token: string,
  expiresAt: Date,
) {
  setCookie(c, SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "Lax",
    path: "/",
    expires: expiresAt,
    secure: process.env.NODE_ENV === "production",
  });
}

export function clearSessionCookie(c: Parameters<MiddlewareHandler>[0]) {
  deleteCookie(c, SESSION_COOKIE, { path: "/" });
}

async function developerFromToken(token: string) {
  if (isProductionEnv() && isForbiddenProductionToken(token)) {
    return null;
  }

  if (token.startsWith("qa_sess_")) {
    const session = await prisma.session.findUnique({
      where: { tokenHash: hashKey(token) },
      include: { developer: true },
    });
    if (!session || session.expiresAt < new Date()) return null;
    return session.developer;
  }

  const apiKey = await prisma.apiKey.findUnique({
    where: { hashedKey: hashKey(token) },
    include: { developer: true },
  });
  if (!apiKey) return null;
  await prisma.apiKey.update({
    where: { id: apiKey.id },
    data: { lastUsedAt: new Date() },
  });
  return apiKey.developer;
}

export const requireDeveloper: MiddlewareHandler = async (c, next) => {
  const header = c.req.header("authorization") ?? "";
  const bearer = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const cookie = getCookie(c, SESSION_COOKIE) ?? "";
  const token = bearer || cookie;

  if (!token) {
    return c.json({ error: "Missing credentials" }, 401);
  }

  const developer = await developerFromToken(token);
  if (!developer) {
    return c.json({ error: "Invalid credentials" }, 401);
  }
  if (isProductionEnv() && isForbiddenProductionAccount(developer.email)) {
    return c.json({ error: "Invalid credentials" }, 401);
  }

  c.set("developer", developer);
  await next();
};
