// secretFindings is stored as a JSON string (see Deployment.secretFindings);
// every response handing deployments back to a client parses it first.
// Shared by routes/deployments.ts and routes/services.ts.
export function withParsedFindings<T extends { secretFindings: string | null }>(
  deployment: T,
) {
  return {
    ...deployment,
    secretFindings: deployment.secretFindings
      ? JSON.parse(deployment.secretFindings)
      : null,
  };
}
