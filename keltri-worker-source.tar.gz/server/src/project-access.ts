import type { Project } from "@prisma/client";
import { prisma } from "./db.js";

export type ProjectAccessVia =
  | "personal-owner"
  | "personal-team-member"
  | "org-owner"
  | "org-member";

export type ProjectAccess = {
  project: Project;
  via: ProjectAccessVia;
  isOwner: boolean;
};

// Single entry point for "can this developer touch this project, and how".
// Returns null for anything a caller must 404 on -- this codebase never
// distinguishes 403 from 404 for ownership failures (every existing check
// in projects.ts/flags.ts/domains.ts does the same), so this preserves
// that posture rather than introducing a new leak surface.
export async function resolveProjectAccess(
  developerId: string,
  projectId: string,
): Promise<ProjectAccess | null> {
  const project = await prisma.project.findFirst({
    where: {
      id: projectId,
      OR: [
        // developerId only grants access for a *personal* project -- once
        // org-owned, it's just "who created it," not a standing grant.
        { developerId, organizationId: null },
        { teamMembers: { some: { developerId } } },
        { organization: { members: { some: { developerId } } } },
      ],
    },
  });
  if (!project) return null;

  if (project.organizationId) {
    const membership = await prisma.organizationMember.findUnique({
      where: {
        organizationId_developerId: {
          organizationId: project.organizationId,
          developerId,
        },
      },
    });
    if (membership) {
      const via: ProjectAccessVia =
        membership.role === "owner" ? "org-owner" : "org-member";
      return { project, via, isOwner: via === "org-owner" };
    }
    // Reached only via a TeamMember row invited onto an org-owned project
    // -- harmless, same narrow view-only grant TeamMember has always had.
    return { project, via: "personal-team-member", isOwner: false };
  }

  if (project.developerId === developerId) {
    return { project, via: "personal-owner", isOwner: true };
  }
  return { project, via: "personal-team-member", isOwner: false };
}

// Reads and deploy-level actions: any org member, or a personal owner.
// Excludes only the legacy TeamMember view-only grant, which has always
// meant "see GET /, GET /:id," nothing else.
export function canReadOrDeploy(access: ProjectAccess) {
  return access.via !== "personal-team-member";
}

// Genuine mutations (env/flags/domains write+delete): owner only --
// personal owner, or an org member with role:"owner".
export function canMutate(access: ProjectAccess) {
  return access.isOwner;
}
