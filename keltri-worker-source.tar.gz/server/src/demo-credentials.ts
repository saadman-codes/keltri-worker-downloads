export const DEMO_EMAIL = "admin@admin.com";
export const DEMO_PASSWORD = "12345678";
export const DEMO_API_KEY = "qa_dev_seed_key";

export function isProductionEnv(nodeEnv = process.env.NODE_ENV) {
  return nodeEnv === "production";
}

export function isForbiddenProductionLogin(
  email: string,
  password: string,
) {
  return (
    email.trim().toLowerCase() === DEMO_EMAIL || password === DEMO_PASSWORD
  );
}

export function isForbiddenProductionToken(token: string) {
  return token === DEMO_API_KEY;
}

export function isForbiddenProductionAccount(email: string) {
  return email.trim().toLowerCase() === DEMO_EMAIL;
}
