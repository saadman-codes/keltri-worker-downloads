import assert from "node:assert/strict";
import test from "node:test";
import { gitReturnPath } from "./git-return.js";

test("OAuth resumes the existing project's service import", () => {
  assert.equal(gitReturnPath("/console/projects/abc-123/services/new"), "/console/projects/abc-123/services/new");
});
test("GitHub App can return to workspace settings", () => {
  assert.equal(gitReturnPath("/console/settings"), "/console/settings");
});
test("OAuth rejects external and non-import return paths", () => {
  for (const path of [undefined, "https://evil.test", "//evil.test", "/console/projects/../services/new", "/console/settings/other", "/console/projects/a/services/new?next=evil", "/console/projects/a/services/new#evil"]) {
    assert.equal(gitReturnPath(path), "/console/projects/new");
  }
});
