export type SecretFinding = {
  file: string;
  rule: string;
  line: number;
  preview: string;
};

// A small, well-known regex set -- not an ML model. Length-gated where a
// bare keyword match would false-positive on ordinary code (e.g. `const
// apiKey = "test"`).
const RULES: Array<{ name: string; pattern: RegExp }> = [
  { name: "aws-access-key-id", pattern: /AKIA[0-9A-Z]{16}/g },
  {
    name: "pem-private-key",
    pattern: /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g,
  },
  {
    name: "generic-api-key-assignment",
    pattern:
      /\b(?:api[_-]?key|secret|token)\b\s*[:=]\s*["'`][A-Za-z0-9/_+=.-]{20,}["'`]/gi,
  },
  { name: "slack-token", pattern: /xox[baprs]-[A-Za-z0-9-]{10,}/g },
  { name: "stripe-live-secret-key", pattern: /sk_live_[A-Za-z0-9]{20,}/g },
  { name: "github-token", pattern: /gh[pousr]_[A-Za-z0-9]{20,}/g },
];

const TEXT_EXTENSIONS = new Set([
  ".js", ".ts", ".jsx", ".tsx", ".json", ".env", ".yml", ".yaml", ".html",
  ".css", ".txt", ".md", ".py", ".rb", ".java", ".go", ".toml", ".ini", ".xml",
  ".pem", ".key", ".crt", ".cer",
]);

const MAX_SCANNED_BYTES = 2 * 1024 * 1024;
const MAX_FINDINGS = 50;

export function looksLikeText(filename: string) {
  const dot = filename.lastIndexOf(".");
  if (dot === -1) return true; // extensionless files (README, Dockerfile) are usually text
  return TEXT_EXTENSIONS.has(filename.slice(dot).toLowerCase());
}

function redact(match: string) {
  if (match.length <= 8) return "…";
  return `${match.slice(0, 4)}…${match.slice(-4)}`;
}

export function scanTextForSecrets(filename: string, content: string): SecretFinding[] {
  const findings: SecretFinding[] = [];
  const lines = content.split("\n");

  for (const rule of RULES) {
    for (let i = 0; i < lines.length; i++) {
      const matches = lines[i].match(rule.pattern);
      if (!matches) continue;
      for (const match of matches) {
        findings.push({
          file: filename,
          rule: rule.name,
          line: i + 1,
          preview: redact(match),
        });
      }
    }
  }
  return findings;
}

// Called once per file while it's already in memory during bundle
// extraction (see deploy.ts) -- skips binaries and anything oversized.
export function scanFile(filename: string, data: Buffer): SecretFinding[] {
  if (!looksLikeText(filename)) return [];
  if (data.byteLength > MAX_SCANNED_BYTES) return [];
  return scanTextForSecrets(filename, data.toString("utf8"));
}

export function capFindings(findings: SecretFinding[]) {
  return findings.slice(0, MAX_FINDINGS);
}
