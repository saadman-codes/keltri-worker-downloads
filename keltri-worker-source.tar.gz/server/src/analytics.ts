import { prisma } from "./db.js";

// Deliberately not awaited by the caller -- unlike fireWebhook (which is
// awaited at every call site today, just best-effort at delivery), this
// sits on the hot path for every production HTML request, so it must be
// genuinely fire-and-forget, not just wrapped in a .catch().
export function recordPageView(projectId: string) {
  const date = new Date();
  date.setUTCHours(0, 0, 0, 0);
  prisma.projectDailyStat
    .upsert({
      where: { projectId_date: { projectId, date } },
      create: { projectId, date, views: 1 },
      update: { views: { increment: 1 } },
    })
    .catch(() => {});
}
