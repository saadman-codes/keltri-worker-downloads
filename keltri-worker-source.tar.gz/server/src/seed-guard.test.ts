import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { assertSeedAllowed } from "./seed-guard.js";

describe("seed guard", () => {
  it("blocks seed when NODE_ENV is production", () => {
    assert.throws(() => assertSeedAllowed("production"), /Refusing to seed/);
  });

  it("allows seed in development", () => {
    assert.doesNotThrow(() => assertSeedAllowed("development"));
    assert.doesNotThrow(() => assertSeedAllowed(undefined));
  });
});
