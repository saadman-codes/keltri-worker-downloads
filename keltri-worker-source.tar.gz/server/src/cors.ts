export function allowedOrigins(): string[] {
  const listed = (process.env.CORS_ORIGINS ?? "")
    .split(",")
    .map((value) => value.trim())
    .filter(Boolean);

  if (listed.length > 0) return [...new Set(listed)];

  return ["http://localhost:3000", "http://localhost:3002"];
}

export function isAllowedOrigin(origin: string | undefined) {
  if (!origin) return false;
  return allowedOrigins().includes(origin);
}

export function corsOrigin(origin: string): string {
  return isAllowedOrigin(origin) ? origin : "";
}

export function publicWebOrigin() {
  return allowedOrigins()[0] ?? "http://localhost:3000";
}

// Console is served from the web app under /console (see apps/web/src/App.tsx)
// rather than its own origin now, so this is the web origin plus that prefix.
export function consoleOrigin() {
  if (process.env.CONSOLE_ORIGIN) return process.env.CONSOLE_ORIGIN.replace(/\/$/, "");
  return `${publicWebOrigin()}/console`;
}
