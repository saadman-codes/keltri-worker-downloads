import { createHash } from "node:crypto";
import { Hono, type Context } from "hono";
import { recordPageView } from "../analytics.js";
import { prisma } from "../db.js";
import { buildBootstrapperApk } from "../bootstrapper.js";
import { asBody, getObject, objectStat, publicFileUrl } from "../storage.js";

export const publicApi = new Hono();

function liveApp() {
  return {
    status: "live" as const,
    visibility: "public" as const,
  };
}

function takenDown(app: { status: string }) {
  return app.status === "unpublished";
}

function catalogApp(app: {
  slug: string;
  name: string;
  shortDescription: string | null;
  category: string | null;
  iconUrl: string | null;
  miniAppEnabled: boolean;
  hasMiniApp: boolean;
  featured: boolean;
  developer: { name: string; slug: string };
  versions: Array<{ versionName: string; installCount: number }>;
  reviews: Array<{ rating: number }>;
}) {
  const installs = app.versions.reduce((sum, v) => sum + v.installCount, 0);
  const rating =
    app.reviews.length === 0
      ? 0
      : app.reviews.reduce((sum, r) => sum + r.rating, 0) / app.reviews.length;
  return {
    slug: app.slug,
    name: app.name,
    shortDescription: app.shortDescription,
    category: app.category,
    iconUrl: app.iconUrl,
    miniAppEnabled: app.miniAppEnabled && app.hasMiniApp,
    featured: app.featured,
    developer: { name: app.developer.name, slug: app.developer.slug },
    versionName: app.versions[0]?.versionName,
    installs,
    rating: Number(rating.toFixed(1)),
    reviewCount: app.reviews.length,
  };
}

publicApi.get("/catalog", async (c) => {
  const apps = await prisma.app.findMany({
    where: liveApp(),
    include: {
      developer: { select: { name: true, slug: true } },
      versions: { orderBy: { createdAt: "desc" } },
      reviews: true,
    },
    orderBy: { createdAt: "desc" },
  });
  const items = apps.map(catalogApp);
  const featured = items.filter((app) => app.featured);
  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const recent = apps.filter((app) => app.createdAt >= weekAgo);
  const preferred = ["games", "tools", "productivity", "finance", "social"];
  const present = new Set(
    items
      .map((app) => app.category)
      .filter((value): value is string => Boolean(value)),
  );
  const categories = [
    ...preferred.filter((item) => present.has(item)),
    ...[...present].filter((item) => !preferred.includes(item)),
  ];
  return c.json({
    data: {
      featured: featured.length ? featured : items.slice(0, 3),
      newThisWeek: (recent.length ? recent : apps.slice(0, 6)).map(catalogApp),
      top: [...items].sort((a, b) => b.installs - a.installs),
      categories: items.length
        ? categories.length
          ? categories
          : preferred
        : [],
    },
  });
});

publicApi.get("/apps/:slug", async (c) => {
  const app = await prisma.app.findFirst({
    where: { slug: c.req.param("slug"), ...liveApp() },
    include: {
      developer: true,
      versions: { orderBy: { createdAt: "desc" } },
      reviews: { orderBy: { createdAt: "desc" } },
      screenshots: { orderBy: { sortOrder: "asc" } },
    },
  });
  if (!app) return c.json({ error: "App not found" }, 404);
  const live = app.versions.find((v) => v.status === "live") ?? app.versions[0];
  return c.json({
    data: {
      ...catalogApp(app),
      description: app.description,
      contentRating: app.contentRating,
      permissions: app.miniAppPermissions
        ? (JSON.parse(app.miniAppPermissions) as string[])
        : [],
      releaseNotes: live?.releaseNotes,
      screenshots: app.screenshots,
      reviews: app.reviews,
      installUrl: live?.apkKey ? publicFileUrl(live.apkKey) : null,
    },
  });
});

publicApi.get("/developers/:slug", async (c) => {
  const developer = await prisma.developer.findUnique({
    where: { slug: c.req.param("slug") },
    include: {
      apps: {
        where: liveApp(),
        include: {
          versions: true,
          reviews: true,
          developer: { select: { name: true, slug: true } },
        },
      },
    },
  });
  if (!developer) return c.json({ error: "Developer not found" }, 404);
  const apps = developer.apps.map(catalogApp);
  const installs = apps.reduce((sum, app) => sum + app.installs, 0);
  const rated = apps.filter((app) => app.reviewCount > 0);
  const rating =
    rated.length === 0
      ? 0
      : rated.reduce((sum, app) => sum + app.rating, 0) / rated.length;
  return c.json({
    data: {
      name: developer.name,
      slug: developer.slug,
      bio: developer.bio,
      website: developer.website,
      installs,
      rating: Number(rating.toFixed(1)),
      apps,
    },
  });
});

publicApi.get("/apps/:slug/bootstrapper", async (c) => {
  const app = await prisma.app.findFirst({
    where: { slug: c.req.param("slug") },
  });
  if (!app || takenDown(app)) return c.json({ error: "App not found" }, 404);
  const apk = await buildBootstrapperApk({
    appId: app.id,
    slug: app.slug,
    name: app.name,
    apiOrigin: process.env.API_ORIGIN ?? "http://localhost:4000",
  });
  return c.body(asBody(apk), 200, {
    "Content-Type": "application/vnd.android.package-archive",
    "Content-Disposition": `attachment; filename="${app.slug}-bootstrapper.apk"`,
  });
});

publicApi.get("/apps/:slug/update", async (c) => {
  const app = await prisma.app.findFirst({
    where: { slug: c.req.param("slug") },
    include: { versions: { orderBy: { createdAt: "desc" } } },
  });
  if (!app || takenDown(app)) return c.json({ error: "App not found" }, 404);
  const current = c.req.query("current") ?? "0";
  const device = c.req.query("device") ?? "anon";
  const bucket = Number.parseInt(
    createHash("sha256").update(device + app.id).digest("hex").slice(0, 8),
    16,
  ) % 100;

  const eligible = app.versions.filter((version) => {
    if (version.status === "rolled_back" || version.status === "draft") return false;
    if (version.scanStatus === "pending" || version.scanStatus === "failed") {
      return false;
    }
    if (version.status === "live") return true;
    return version.rolloutPercent > bucket;
  });
  const latest =
    eligible.sort((a, b) => b.versionCode - a.versionCode)[0] ??
    app.versions.find((v) => v.status === "live") ??
    app.versions[0];
  if (!latest) return c.json({ error: "No version" }, 404);

  return c.json({
    data: {
      current,
      upToDate: latest.versionName === current,
      versionName: latest.versionName,
      versionCode: latest.versionCode,
      sha256: latest.apkSha256,
      size: latest.apkSizeBytes,
      apkUrl: latest.apkKey ? publicFileUrl(latest.apkKey) : null,
    },
  });
});

async function serveMiniapp(c: Context, rest: string) {
  const app = await prisma.app.findFirst({
    where: { slug: c.req.param("slug"), ...liveApp() },
    include: { versions: { orderBy: { createdAt: "desc" } } },
  });
  if (!app?.hasMiniApp) return c.json({ error: "Mini-app not available" }, 404);
  const version = app.versions.find((v) => v.miniappKey) ?? app.versions[0];
  if (!version?.miniappKey) return c.json({ error: "Mini-app not available" }, 404);
  const filePath = rest.replace(/^\/+/, "") || "index.html";
  const key = `${version.miniappKey}/${filePath}`;
  try {
    const file = await getObject(key);
    const type = filePath.endsWith(".js")
      ? "text/javascript"
      : filePath.endsWith(".css")
        ? "text/css"
        : filePath.endsWith(".png")
          ? "image/png"
          : "text/html";
    return c.body(asBody(file), 200, { "Content-Type": type });
  } catch {
    return c.json({ error: "File not found" }, 404);
  }
}

publicApi.get("/apps/:slug/miniapp", (c) => serveMiniapp(c, "index.html"));
publicApi.get("/apps/:slug/miniapp/*", (c) => {
  const rest = c.req.path.split("/miniapp/")[1] || "index.html";
  return serveMiniapp(c, rest);
});

publicApi.get("/files/*", async (c) => {
  const key = c.req.path.replace(/^\/v1\/public\/files\//, "");
  try {
    const info = await objectStat(key);
    const file = await getObject(key);
    return c.body(asBody(file), 200, {
      "Content-Type": key.endsWith(".png")
        ? "image/png"
        : "application/octet-stream",
      "Content-Length": String(info.size),
    });
  } catch {
    return c.json({ error: "File not found" }, 404);
  }
});

// Serves a service's deployed static bundle. Path-based rather than
// subdomain-based (no wildcard DNS assumed) — every file was stored under
// `projects/:projectId/services/:serviceId/deployments/:deploymentId/...`
// by extractBundleToStorage. Falls back to the deployment's own
// index.html for any path Vite/React Router would otherwise 404 on, the
// same SPA-fallback behavior Vercel gives a static deploy. Page-view
// counting stays keyed by projectId (ProjectDailyStat is still a
// project-level rollup, not per-service — see its schema comment).
async function serveDeploymentFiles(
  c: Context,
  projectId: string,
  serviceId: string,
  deploymentId: string,
  rest: string,
  countView = false,
) {
  const prefix = `projects/${projectId}/services/${serviceId}/deployments/${deploymentId}`;
  const filePath = rest.replace(/^\/+/, "") || "index.html";
  const type = (name: string) =>
    name.endsWith(".js")
      ? "text/javascript"
      : name.endsWith(".css")
        ? "text/css"
        : name.endsWith(".png")
          ? "image/png"
          : name.endsWith(".svg")
            ? "image/svg+xml"
            : name.endsWith(".json")
              ? "application/json"
              : "text/html";

  try {
    const file = await getObject(`${prefix}/${filePath}`);
    const contentType = type(filePath);
    // Page views only: HTML responses, not every JS/CSS/image sub-resource
    // hit. Not awaited -- see analytics.ts.
    if (countView && contentType === "text/html") recordPageView(projectId);
    return c.body(asBody(file), 200, { "Content-Type": contentType });
  } catch {
    if (filePath === "index.html") return c.json({ error: "Not found" }, 404);
    try {
      const fallback = await getObject(`${prefix}/index.html`);
      if (countView) recordPageView(projectId);
      return c.body(asBody(fallback), 200, { "Content-Type": "text/html" });
    } catch {
      return c.json({ error: "Not found" }, 404);
    }
  }
}

publicApi.get("/deploy/d/:deploymentId", (c) =>
  handlePreviewDeployment(c, "index.html"),
);
publicApi.get("/deploy/d/:deploymentId/*", (c) => {
  const rest = c.req.path.split(`/deploy/d/${c.req.param("deploymentId")}/`)[1] || "";
  return handlePreviewDeployment(c, rest);
});

async function handlePreviewDeployment(c: Context, rest: string) {
  const deployment = await prisma.deployment.findUnique({
    where: { id: c.req.param("deploymentId") },
    include: { service: true },
  });
  if (!deployment || deployment.status !== "ready") {
    return c.json({ error: "Deployment not found" }, 404);
  }
  return serveDeploymentFiles(
    c,
    deployment.service.projectId,
    deployment.serviceId,
    deployment.id,
    rest,
  );
}

publicApi.get("/deploy/p/:projectSlug/:serviceSlug", (c) =>
  handleProductionDeployment(c, "index.html"),
);
publicApi.get("/deploy/p/:projectSlug/:serviceSlug/*", (c) => {
  const marker = `/deploy/p/${c.req.param("projectSlug")}/${c.req.param("serviceSlug")}/`;
  const rest = c.req.path.split(marker)[1] || "";
  return handleProductionDeployment(c, rest);
});

async function handleProductionDeployment(c: Context, rest: string) {
  const project = await prisma.project.findUnique({
    where: { slug: c.req.param("projectSlug") },
  });
  if (!project) return c.json({ error: "Project not found" }, 404);

  const service = await prisma.service.findFirst({
    where: { projectId: project.id, slug: c.req.param("serviceSlug") },
  });
  if (!service) return c.json({ error: "Service not found" }, 404);

  const deployment = await prisma.deployment.findFirst({
    where: { serviceId: service.id, environment: "production", status: "ready" },
    orderBy: { createdAt: "desc" },
  });
  if (!deployment) return c.json({ error: "Nothing in production yet" }, 404);

  return serveDeploymentFiles(c, project.id, service.id, deployment.id, rest, true);
}

// Public flag read for a deployed site to call. rolloutPercent only
// buckets deterministically when the caller supplies ?bucket= (a stable
// per-visitor id it computes itself) -- reuses the exact bucketing shape
// already proven for Android OTA rollout above (sha256(id + key) % 100).
// Without a bucket id, rolloutPercent < 100 falls back to `enabled` alone.
publicApi.get("/flags/:projectSlug/:serviceSlug", async (c) => {
  const project = await prisma.project.findUnique({
    where: { slug: c.req.param("projectSlug") },
  });
  if (!project) return c.json({ error: "Project not found" }, 404);

  const service = await prisma.service.findFirst({
    where: { projectId: project.id, slug: c.req.param("serviceSlug") },
  });
  if (!service) return c.json({ error: "Service not found" }, 404);

  const target = c.req.query("target") === "preview" ? "preview" : "production";
  const bucketId = c.req.query("bucket");

  const rows = await prisma.featureFlag.findMany({
    where: {
      serviceId: service.id,
      enabled: true,
      target: { in: ["all", target] },
    },
  });

  const resolved: Record<string, boolean> = {};
  for (const flag of rows) {
    if (flag.rolloutPercent >= 100) {
      resolved[flag.key] = true;
      continue;
    }
    if (!bucketId) {
      resolved[flag.key] = false;
      continue;
    }
    const bucket = Number.parseInt(
      createHash("sha256").update(bucketId + flag.key).digest("hex").slice(0, 8),
      16,
    ) % 100;
    resolved[flag.key] = bucket < flag.rolloutPercent;
  }

  return c.json({ data: resolved });
});

publicApi.post("/apps/:slug/reviews", async (c) => {
  const app = await prisma.app.findFirst({
    where: { slug: c.req.param("slug"), ...liveApp() },
  });
  if (!app) return c.json({ error: "App not found" }, 404);
  const body = await c.req.json();
  const review = await prisma.review.create({
    data: {
      appId: app.id,
      author: String(body.author ?? "Anonymous"),
      rating: Number(body.rating ?? 5),
      body: String(body.body ?? ""),
    },
  });
  return c.json({ data: review }, 201);
});
