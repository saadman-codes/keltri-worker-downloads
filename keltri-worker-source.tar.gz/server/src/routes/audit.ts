import { Hono } from "hono";
import { prisma } from "../db.js";

export const audit = new Hono();

audit.get("/", async (c) => {
  const developer = c.get("developer");
  const page = Math.max(1, Number(c.req.query("page")) || 1);
  const pageSize = Math.min(200, Math.max(1, Number(c.req.query("pageSize")) || 50));

  const [items, total] = await Promise.all([
    prisma.auditLog.findMany({
      where: { developerId: developer.id },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.auditLog.count({ where: { developerId: developer.id } }),
  ]);

  return c.json({
    data: {
      items: items.map((item) => ({
        ...item,
        metadata: item.metadata ? JSON.parse(item.metadata) : null,
      })),
      page,
      pageSize,
      total,
    },
  });
});
