import { Hono } from "hono";
import { asBody, getObject, putObject } from "../storage.js";
import { prisma } from "../db.js";

const KEY_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/;

function storageKeyFor(developerId: string, key: string) {
  return `blobs/${developerId}/${key}`;
}

export const blobs = new Hono();

blobs.get("/", async (c) => {
  const developer = c.get("developer");
  const list = await prisma.blobEntry.findMany({
    where: { developerId: developer.id },
    orderBy: { key: "asc" },
    select: {
      id: true,
      key: true,
      contentType: true,
      sizeBytes: true,
      createdAt: true,
      updatedAt: true,
    },
  });
  return c.json({ data: list });
});

blobs.put("/:key", async (c) => {
  const developer = c.get("developer");
  const key = c.req.param("key");
  if (!KEY_PATTERN.test(key)) {
    return c.json(
      { error: "Key must match ^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$" },
      400,
    );
  }

  const buffer = Buffer.from(await c.req.arrayBuffer());
  const contentType = c.req.header("Content-Type") || "application/octet-stream";
  const storageKey = storageKeyFor(developer.id, key);
  await putObject(storageKey, buffer);

  const entry = await prisma.blobEntry.upsert({
    where: { developerId_key: { developerId: developer.id, key } },
    create: {
      developerId: developer.id,
      key,
      contentType,
      sizeBytes: buffer.byteLength,
      storageKey,
    },
    update: { contentType, sizeBytes: buffer.byteLength, storageKey },
  });

  return c.json({
    data: {
      key: entry.key,
      contentType: entry.contentType,
      sizeBytes: entry.sizeBytes,
      updatedAt: entry.updatedAt,
    },
  });
});

blobs.get("/:key", async (c) => {
  const developer = c.get("developer");
  const entry = await prisma.blobEntry.findFirst({
    where: { developerId: developer.id, key: c.req.param("key") },
  });
  if (!entry) return c.json({ error: "Blob not found" }, 404);

  const bytes = await getObject(entry.storageKey);
  return c.body(asBody(bytes), 200, { "Content-Type": entry.contentType });
});

blobs.delete("/:key", async (c) => {
  const developer = c.get("developer");
  await prisma.blobEntry.deleteMany({
    where: { developerId: developer.id, key: c.req.param("key") },
  });
  return c.json({ data: { ok: true } });
});
