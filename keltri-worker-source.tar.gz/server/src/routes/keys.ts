import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { newApiKey } from "../auth.js";

const createSchema = z.object({
  name: z.string().min(1).default("CLI"),
});

export const keys = new Hono();

keys.get("/", async (c) => {
  const developer = c.get("developer");
  const list = await prisma.apiKey.findMany({
    where: { developerId: developer.id },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      name: true,
      prefix: true,
      lastUsedAt: true,
      createdAt: true,
    },
  });
  return c.json({ data: list });
});

keys.post("/", async (c) => {
  const developer = c.get("developer");
  const parsed = createSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const key = newApiKey();
  const created = await prisma.apiKey.create({
    data: {
      developerId: developer.id,
      name: parsed.data.name,
      hashedKey: key.hashedKey,
      prefix: key.prefix,
    },
  });
  await logAudit(developer.id, "apikey.created", "apikey", created.id, {
    name: created.name,
    prefix: created.prefix,
  });
  return c.json({ data: { ...created, token: key.raw } }, 201);
});

keys.delete("/:id", async (c) => {
  const developer = c.get("developer");
  const existing = await prisma.apiKey.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  await prisma.apiKey.deleteMany({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (existing) {
    await logAudit(developer.id, "apikey.revoked", "apikey", existing.id, {
      name: existing.name,
      prefix: existing.prefix,
    });
  }
  return c.json({ data: { ok: true } });
});
