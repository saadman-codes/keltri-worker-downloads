import { randomBytes } from "node:crypto";
import { Hono } from "hono";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { extractBundleToStorage } from "../deploy.js";
import { withParsedFindings } from "../deployment-utils.js";
import { canReadOrDeploy } from "../project-access.js";
import { resolveServiceAccess } from "./services.js";
import { getObject } from "../storage.js";
import { fireWebhook } from "../webhooks.js";

export const deploymentPrefix = (
  projectId: string,
  serviceId: string,
  deploymentId: string,
) => `projects/${projectId}/services/${serviceId}/deployments/${deploymentId}`;

// Shared by POST .../promote and POST .../rollback (rollback just picks
// its target automatically: the deployment with the next-most-recent
// promotedAt). promotedAt is never cleared on demotion, so it stays a
// full promotion history, not just "what's live right now".
async function promoteDeployment(
  developerId: string,
  projectId: string,
  serviceId: string,
  deploymentId: string,
) {
  const [, promoted] = await prisma.$transaction([
    prisma.deployment.updateMany({
      where: { serviceId, environment: "production" },
      data: { environment: "preview" },
    }),
    prisma.deployment.update({
      where: { id: deploymentId },
      data: { environment: "production", promotedAt: new Date() },
    }),
  ]);
  await fireWebhook(developerId, "deployment.promoted", {
    projectId,
    serviceId,
    deploymentId: promoted.id,
  });
  await logAudit(developerId, "deployment.promoted", "deployment", promoted.id, {
    projectId,
    serviceId,
  });
  return promoted;
}

export const deployments = new Hono();

// Web deployments follow the same two-step (upload-url -> PUT bytes ->
// finalize) shape as APK uploads in routes/versions.ts: create a draft
// row + token, let the browser PUT the zip straight to /v1/uploads/:token,
// then finalize extracts it into storage.
deployments.post("/:id/services/:serviceId/deployments/upload-url", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }
  const { project, service } = access;
  if (service.type !== "web") {
    return c.json({ error: "Only web services accept a build upload" }, 400);
  }

  const body = await c.req.json().catch(() => ({}));
  const token = randomBytes(18).toString("hex");
  const api = process.env.API_ORIGIN ?? "http://localhost:4000";

  const deployment = await prisma.deployment.create({
    data: {
      serviceId: service.id,
      status: "uploading",
      commitRef: typeof body.commitRef === "string" ? body.commitRef : undefined,
      uploadToken: token,
    },
  });

  return c.json({
    data: {
      deploymentId: deployment.id,
      uploadUrl: `${api}/v1/uploads/${token}`,
      uploadToken: token,
    },
  });
});

deployments.post(
  "/:id/services/:serviceId/deployments/:did/finalize",
  async (c) => {
    const developer = c.get("developer");
    const access = await resolveServiceAccess(
      developer.id,
      c.req.param("id"),
      c.req.param("serviceId"),
    );
    if (!access || !canReadOrDeploy(access)) {
      return c.json({ error: "Service not found" }, 404);
    }
    const { project, service } = access;

    const deployment = await prisma.deployment.findFirst({
      where: { id: c.req.param("did"), serviceId: service.id },
    });
    if (!deployment) return c.json({ error: "Deployment not found" }, 404);

    const prefix = deploymentPrefix(project.id, service.id, deployment.id);
    const bundleKey = `${prefix}/_bundle.zip`;
    let bundle: Buffer;
    try {
      bundle = await getObject(bundleKey);
    } catch {
      return c.json({ error: "Build not uploaded yet" }, 400);
    }

    try {
      const { fileCount, totalBytes, secretFindings } =
        await extractBundleToStorage(bundle, prefix);
      const updated = await prisma.deployment.update({
        where: { id: deployment.id },
        data: {
          status: "ready",
          fileCount,
          totalBytes,
          uploadToken: null,
          secretScanStatus: secretFindings.length > 0 ? "flagged" : "clean",
          secretFindings:
            secretFindings.length > 0 ? JSON.stringify(secretFindings) : null,
        },
      });
      await fireWebhook(developer.id, "deployment.created", {
        projectId: project.id,
        serviceId: service.id,
        deploymentId: updated.id,
        serviceType: service.type,
      });
      if (secretFindings.length > 0) {
        await fireWebhook(developer.id, "deployment.secrets_flagged", {
          projectId: project.id,
          serviceId: service.id,
          deploymentId: updated.id,
          findingCount: secretFindings.length,
        });
      }
      await logAudit(developer.id, "deployment.created", "deployment", updated.id, {
        projectId: project.id,
        serviceId: service.id,
      });
      return c.json({ data: withParsedFindings(updated) });
    } catch (err) {
      await prisma.deployment.update({
        where: { id: deployment.id },
        data: { status: "failed", uploadToken: null },
      });
      await fireWebhook(developer.id, "deployment.failed", {
        projectId: project.id,
        serviceId: service.id,
        deploymentId: deployment.id,
        error: err instanceof Error ? err.message : "Extract failed",
      });
      await logAudit(developer.id, "deployment.failed", "deployment", deployment.id, {
        projectId: project.id,
        serviceId: service.id,
      });
      return c.json(
        { error: err instanceof Error ? err.message : "Extract failed" },
        400,
      );
    }
  },
);

// Backend hosting has no build/runtime yet (see PROJECT_BLUEPRINT.md §7) —
// this records a deployment's metadata only, the same honest-stub pattern
// the malware scanner uses elsewhere in this codebase.
deployments.post("/:id/services/:serviceId/deployments", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }
  const { project, service } = access;
  if (service.type !== "backend") {
    return c.json(
      { error: "Web services deploy via upload-url + finalize" },
      400,
    );
  }

  const body = await c.req.json().catch(() => ({}));
  const deployment = await prisma.deployment.create({
    data: {
      serviceId: service.id,
      status: "stub",
      commitRef: typeof body.commitRef === "string" ? body.commitRef : undefined,
      // Never extracts a bundle, so it never sits at "pending" forever.
      secretScanStatus: "clean",
    },
  });

  await fireWebhook(developer.id, "deployment.created", {
    projectId: project.id,
    serviceId: service.id,
    deploymentId: deployment.id,
    serviceType: service.type,
  });

  return c.json({ data: deployment }, 201);
});

deployments.post(
  "/:id/services/:serviceId/deployments/:did/promote",
  async (c) => {
    const developer = c.get("developer");
    const access = await resolveServiceAccess(
      developer.id,
      c.req.param("id"),
      c.req.param("serviceId"),
    );
    if (!access || !canReadOrDeploy(access)) {
      return c.json({ error: "Service not found" }, 404);
    }
    const { project, service } = access;

    const deployment = await prisma.deployment.findFirst({
      where: { id: c.req.param("did"), serviceId: service.id },
    });
    if (!deployment) return c.json({ error: "Deployment not found" }, 404);
    if (deployment.status !== "ready" && deployment.status !== "stub") {
      return c.json({ error: "Deployment is not ready to promote" }, 400);
    }

    const promoted = await promoteDeployment(
      developer.id,
      project.id,
      service.id,
      deployment.id,
    );
    return c.json({ data: promoted });
  },
);

// One-click rollback, mirroring the Android surface's rollback UX (see
// routes/versions.ts): find what was in production just before the
// current one and promote that instead. No target is chosen by the
// caller — same "instant, no-thinking" shape Netlify/Vercel both ship.
deployments.post("/:id/services/:serviceId/rollback", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }
  const { project, service } = access;

  const history = await prisma.deployment.findMany({
    where: { serviceId: service.id, promotedAt: { not: null } },
    orderBy: { promotedAt: "desc" },
    take: 2,
  });
  const [, previous] = history;
  if (!previous) {
    return c.json({ error: "No previous deployment to roll back to" }, 400);
  }

  const restored = await promoteDeployment(
    developer.id,
    project.id,
    service.id,
    previous.id,
  );
  await logAudit(developer.id, "deployment.rolled_back", "deployment", restored.id, {
    projectId: project.id,
    serviceId: service.id,
  });
  return c.json({ data: restored });
});
