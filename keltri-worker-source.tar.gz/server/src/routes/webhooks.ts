import { randomBytes } from "node:crypto";
import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";

const createSchema = z.object({
  url: z.string().url(),
  events: z.array(z.string()).default([]),
});

export const webhooks = new Hono();

// Unlike API keys, the secret is returned on every list/get, not just at
// creation: a developer needs it persistently to verify inbound HMAC
// signatures on every delivery (see fireWebhook in ../webhooks.ts).
webhooks.get("/", async (c) => {
  const developer = c.get("developer");
  const list = await prisma.webhook.findMany({
    where: { developerId: developer.id },
    orderBy: { createdAt: "desc" },
  });
  return c.json({
    data: list.map((hook) => ({
      ...hook,
      events: JSON.parse(hook.events || "[]"),
    })),
  });
});

webhooks.post("/", async (c) => {
  const developer = c.get("developer");
  const parsed = createSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  const created = await prisma.webhook.create({
    data: {
      developerId: developer.id,
      url: parsed.data.url,
      events: JSON.stringify(parsed.data.events),
      secret: randomBytes(24).toString("hex"),
    },
  });
  await logAudit(developer.id, "webhook.created", "webhook", created.id, {
    url: created.url,
  });
  return c.json(
    { data: { ...created, events: parsed.data.events } },
    201,
  );
});

webhooks.delete("/:id", async (c) => {
  const developer = c.get("developer");
  const existing = await prisma.webhook.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  await prisma.webhook.deleteMany({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (existing) {
    await logAudit(developer.id, "webhook.deleted", "webhook", existing.id, {
      url: existing.url,
    });
  }
  return c.json({ data: { ok: true } });
});
