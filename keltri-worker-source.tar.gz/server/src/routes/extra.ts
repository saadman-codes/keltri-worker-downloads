import { Hono } from "hono";
import { prisma } from "../db.js";
import { buildBootstrapperApk, qrDataUrl } from "../bootstrapper.js";
import { fireWebhook } from "../webhooks.js";
import { publicWebOrigin } from "../cors.js";
import { asBody } from "../storage.js";

export const extra = new Hono();

extra.get("/:id/analytics", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
    include: {
      versions: { orderBy: { createdAt: "desc" } },
      dailyStats: { orderBy: { date: "asc" } },
    },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const totalInstalls = app.versions.reduce((sum, v) => sum + v.installCount, 0);
  const weightedCrash =
    totalInstalls === 0
      ? 0
      : app.versions.reduce((sum, v) => sum + v.crashRate * v.installCount, 0) /
        totalInstalls;

  return c.json({
    data: {
      totalInstalls,
      crashRate: weightedCrash,
      daily: app.dailyStats,
      versions: app.versions.map((v) => ({
        versionName: v.versionName,
        installCount: v.installCount,
        crashRate: v.crashRate,
        status: v.status,
      })),
    },
  });
});

extra.get("/:id/bootstrapper", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const web = publicWebOrigin();
  const api = process.env.API_ORIGIN ?? "http://localhost:4000";
  const shareUrl = `${web}/get/${app.slug}`;
  const downloadUrl = `${api}/v1/public/apps/${app.slug}/bootstrapper`;
  const qr = await qrDataUrl(shareUrl);

  return c.json({
    data: {
      downloadUrl,
      shareUrl,
      qrDataUrl: qr,
      sizeBytes: 820_000,
      embedHtml: `<a href="${shareUrl}">Get it on Keltri</a>`,
    },
  });
});

extra.get("/:id/bootstrapper.apk", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);
  const apk = await buildBootstrapperApk({
    appId: app.id,
    slug: app.slug,
    name: app.name,
    apiOrigin: process.env.API_ORIGIN ?? "http://localhost:4000",
  });
  return c.body(asBody(apk), 200, {
    "Content-Type": "application/vnd.android.package-archive",
    "Content-Disposition": `attachment; filename="${app.slug}-bootstrapper.apk"`,
  });
});

extra.post("/:id/preview", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const web = publicWebOrigin();
  return c.json({
    data: {
      previewUrl: `${web}/store/apps/${app.slug}`,
      appId: app.id,
    },
  });
});

extra.patch("/:id/listing", async (c) => {
  const developer = c.get("developer");
  const body = await c.req.json();
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const updated = await prisma.app.update({
    where: { id: app.id },
    data: {
      name: body.name ?? app.name,
      shortDescription: body.shortDescription ?? app.shortDescription,
      description: body.description ?? app.description,
      category: body.category ?? app.category,
      tags: body.tags ? JSON.stringify(body.tags) : app.tags,
      contentRating: body.contentRating ?? app.contentRating,
      miniAppEnabled:
        typeof body.miniAppEnabled === "boolean"
          ? body.miniAppEnabled
          : app.miniAppEnabled,
      visibility: body.visibility ?? app.visibility,
      geoInclude: body.geoInclude
        ? JSON.stringify(body.geoInclude)
        : app.geoInclude,
      geoExclude: body.geoExclude
        ? JSON.stringify(body.geoExclude)
        : app.geoExclude,
    },
  });

  return c.json({ data: updated });
});

extra.post("/:id/submit", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);
  if (!["draft", "private", "rejected", "unpublished"].includes(app.status)) {
    return c.json({ error: `Cannot submit from ${app.status}` }, 400);
  }
  const updated = await prisma.app.update({
    where: { id: app.id },
    data: { status: "in_review", reviewNote: null },
  });
  return c.json({ data: updated });
});

extra.post("/:id/review", async (c) => {
  const developer = c.get("developer");
  if (!developer.isReviewer && developer.plan !== "team") {
    return c.json({ error: "Forbidden" }, 403);
  }
  const app = await prisma.app.findFirst({ where: { id: c.req.param("id") } });
  if (!app) return c.json({ error: "App not found" }, 404);
  if (app.status !== "in_review") {
    return c.json({ error: "App is not in review" }, 400);
  }
  const body = await c.req.json<{ decision?: string; note?: string }>();
  const approved = body.decision === "approve";
  const updated = await prisma.app.update({
    where: { id: app.id },
    data: {
      status: approved ? "live" : "rejected",
      visibility: approved ? "public" : app.visibility,
      reviewNote: body.note ?? null,
    },
  });
  const event = approved ? "review.approved" : "review.rejected";
  await fireWebhook(app.developerId, event, {
    appId: app.id,
    slug: app.slug,
    note: body.note ?? null,
  });
  return c.json({ data: updated });
});

extra.post("/:id/unpublish", async (c) => {
  const developer = c.get("developer");
  if (!developer.isReviewer) return c.json({ error: "Forbidden" }, 403);
  const app = await prisma.app.findFirst({ where: { id: c.req.param("id") } });
  if (!app) return c.json({ error: "App not found" }, 404);
  if (app.status !== "live") {
    return c.json({ error: "Only live listings can be unpublished" }, 400);
  }
  const body = await c.req.json().catch(() => ({} as { note?: string }));
  const note =
    typeof body.note === "string" && body.note.trim()
      ? body.note.trim()
      : "Unpublished by reviewer.";
  const updated = await prisma.app.update({
    where: { id: app.id },
    data: {
      status: "unpublished",
      visibility: "private",
      featured: false,
      reviewNote: note,
    },
  });
  await fireWebhook(app.developerId, "listing.unpublished", {
    appId: app.id,
    slug: app.slug,
    note,
  });
  return c.json({ data: updated });
});
