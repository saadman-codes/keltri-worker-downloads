import { Hono } from "hono";
import { z } from "zod";
import { prisma } from "../db.js";

const createAppSchema = z.object({
  name: z.string().min(2),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/),
  shortDescription: z.string().optional(),
  packageName: z.string().optional(),
});

export const apps = new Hono();

apps.get("/", async (c) => {
  const developer = c.get("developer");
  const list = await prisma.app.findMany({
    where: { developerId: developer.id },
    include: {
      versions: { orderBy: { createdAt: "desc" }, take: 1 },
    },
    orderBy: { updatedAt: "desc" },
  });
  return c.json({ data: list });
});

apps.post("/", async (c) => {
  const developer = c.get("developer");
  const parsed = createAppSchema.safeParse(await c.req.json());
  if (!parsed.success) {
    return c.json({ error: parsed.error.flatten() }, 400);
  }

  const app = await prisma.app.create({
    data: {
      developerId: developer.id,
      name: parsed.data.name,
      slug: parsed.data.slug,
      shortDescription: parsed.data.shortDescription,
      packageName: parsed.data.packageName,
    },
  });

  return c.json({ data: app }, 201);
});

apps.get("/:id", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
    include: {
      versions: { orderBy: { createdAt: "desc" } },
      reviews: { orderBy: { createdAt: "desc" } },
      screenshots: { orderBy: { sortOrder: "asc" } },
      developer: true,
    },
  });

  if (!app) {
    return c.json({ error: "App not found" }, 404);
  }

  return c.json({ data: app });
});
