import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";

const createOrgSchema = z.object({ name: z.string().min(2) });
const inviteSchema = z.object({
  email: z.string().email(),
  role: z.string().default("member"),
});

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}

async function requireMembership(developerId: string, organizationId: string) {
  return prisma.organizationMember.findFirst({
    where: { organizationId, developerId },
  });
}

async function requireOwnerMembership(developerId: string, organizationId: string) {
  return prisma.organizationMember.findFirst({
    where: { organizationId, developerId, role: "owner" },
  });
}

export const organizations = new Hono();

organizations.post("/", async (c) => {
  const developer = c.get("developer");
  const parsed = createOrgSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  const base = slugify(parsed.data.name) || "org";
  let slug = base;
  let n = 1;
  while (await prisma.organization.findUnique({ where: { slug } })) {
    slug = `${base}-${n++}`;
  }

  const org = await prisma.$transaction(async (tx) => {
    const created = await tx.organization.create({
      data: { name: parsed.data.name, slug },
    });
    await tx.organizationMember.create({
      data: {
        organizationId: created.id,
        developerId: developer.id,
        role: "owner",
        invitedById: developer.id,
      },
    });
    return created;
  });

  await logAudit(developer.id, "organization.created", "organization", org.id, {
    slug: org.slug,
  });

  return c.json({ data: org }, 201);
});

organizations.get("/", async (c) => {
  const developer = c.get("developer");
  const memberships = await prisma.organizationMember.findMany({
    where: { developerId: developer.id },
    include: { organization: true },
    orderBy: { createdAt: "asc" },
  });
  return c.json({
    data: memberships.map((m) => ({
      id: m.organization.id,
      name: m.organization.name,
      slug: m.organization.slug,
      plan: m.organization.plan,
      role: m.role,
      createdAt: m.organization.createdAt,
    })),
  });
});

organizations.get("/:id", async (c) => {
  const developer = c.get("developer");
  const membership = await requireMembership(developer.id, c.req.param("id"));
  if (!membership) return c.json({ error: "Organization not found" }, 404);

  const org = await prisma.organization.findUnique({
    where: { id: c.req.param("id") },
  });
  if (!org) return c.json({ error: "Organization not found" }, 404);

  return c.json({ data: { ...org, role: membership.role } });
});

organizations.get("/:id/members", async (c) => {
  const developer = c.get("developer");
  const membership = await requireMembership(developer.id, c.req.param("id"));
  if (!membership) return c.json({ error: "Organization not found" }, 404);

  const members = await prisma.organizationMember.findMany({
    where: { organizationId: c.req.param("id") },
    orderBy: { createdAt: "asc" },
    include: {
      developer: { select: { id: true, name: true, email: true, slug: true } },
    },
  });
  return c.json({ data: members });
});

organizations.post("/:id/members", async (c) => {
  const developer = c.get("developer");
  const organizationId = c.req.param("id");
  const owner = await requireOwnerMembership(developer.id, organizationId);
  if (!owner) return c.json({ error: "Organization not found" }, 404);

  const parsed = inviteSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  const invitee = await prisma.developer.findUnique({
    where: { email: parsed.data.email },
  });
  if (!invitee) {
    return c.json(
      { error: "No registered developer with that email — they need a Keltri account first" },
      404,
    );
  }
  if (invitee.id === developer.id) {
    return c.json({ error: "You are already a member of this organization" }, 400);
  }

  try {
    const member = await prisma.organizationMember.create({
      data: {
        organizationId,
        developerId: invitee.id,
        role: parsed.data.role,
        invitedById: developer.id,
      },
      include: {
        developer: { select: { id: true, name: true, email: true, slug: true } },
      },
    });
    await logAudit(developer.id, "organization.invited", "organization", organizationId, {
      email: invitee.email,
    });
    return c.json(
      {
        data: member,
        notice:
          "Added immediately — they aren't notified. Share the organization link yourself.",
      },
      201,
    );
  } catch {
    return c.json({ error: "That developer is already a member" }, 409);
  }
});

organizations.delete("/:id/members/:memberId", async (c) => {
  const developer = c.get("developer");
  const organizationId = c.req.param("id");
  const owner = await requireOwnerMembership(developer.id, organizationId);
  if (!owner) return c.json({ error: "Organization not found" }, 404);

  const target = await prisma.organizationMember.findFirst({
    where: { id: c.req.param("memberId"), organizationId },
  });
  if (!target) return c.json({ data: { ok: true } });

  if (target.role === "owner") {
    const ownerCount = await prisma.organizationMember.count({
      where: { organizationId, role: "owner" },
    });
    if (ownerCount <= 1) {
      return c.json({ error: "Cannot remove the last owner" }, 400);
    }
  }

  await prisma.organizationMember.delete({ where: { id: target.id } });
  await logAudit(developer.id, "organization.removed", "organization", organizationId, {
    developerId: target.developerId,
  });
  return c.json({ data: { ok: true } });
});
