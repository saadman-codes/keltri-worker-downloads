import { Hono } from "hono";
import { prisma } from "../db.js";
import { putObject } from "../storage.js";

export const uploads = new Hono();

uploads.put("/:token", async (c) => {
  const token = c.req.param("token");
  const buffer = Buffer.from(await c.req.arrayBuffer());
  if (buffer.length < 16) return c.json({ error: "Empty upload" }, 400);

  const version = await prisma.appVersion.findUnique({
    where: { uploadToken: token },
  });
  if (version) {
    const key = `apps/${version.appId}/${version.id}/app.apk`;
    await putObject(key, buffer);
    await prisma.appVersion.update({
      where: { id: version.id },
      data: { apkKey: key, apkSizeBytes: buffer.length },
    });
    return c.json({ data: { ok: true, sizeBytes: buffer.length } });
  }

  const deployment = await prisma.deployment.findUnique({
    where: { uploadToken: token },
    include: { service: true },
  });
  if (deployment) {
    const key = `projects/${deployment.service.projectId}/services/${deployment.serviceId}/deployments/${deployment.id}/_bundle.zip`;
    await putObject(key, buffer);
    return c.json({ data: { ok: true, sizeBytes: buffer.length } });
  }

  return c.json({ error: "Invalid upload token" }, 404);
});
