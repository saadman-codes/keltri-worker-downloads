import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { canMutate, canReadOrDeploy } from "../project-access.js";
import { resolveServiceAccess } from "./services.js";

const domainSchema = z.object({
  hostname: z
    .string()
    .regex(
      /^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))+$/,
      "Must be a valid hostname (e.g. app.example.com)",
    ),
});

export const domains = new Hono();

domains.get("/:id/services/:serviceId/domains", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const list = await prisma.domain.findMany({
    where: { serviceId: access.service.id },
    orderBy: { createdAt: "asc" },
  });
  return c.json({ data: list });
});

domains.post("/:id/services/:serviceId/domains", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const parsed = domainSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  try {
    const domain = await prisma.domain.create({
      data: { serviceId: access.service.id, hostname: parsed.data.hostname.toLowerCase() },
    });
    await logAudit(developer.id, "domain.added", "service", access.service.id, {
      projectId: access.project.id,
      hostname: domain.hostname,
    });
    return c.json({ data: domain }, 201);
  } catch {
    return c.json({ error: "That hostname is already recorded" }, 409);
  }
});

domains.delete("/:id/services/:serviceId/domains/:domainId", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const existing = await prisma.domain.findFirst({
    where: { id: c.req.param("domainId"), serviceId: access.service.id },
  });
  await prisma.domain.deleteMany({
    where: { id: c.req.param("domainId"), serviceId: access.service.id },
  });
  if (existing) {
    await logAudit(developer.id, "domain.removed", "service", access.service.id, {
      projectId: access.project.id,
      hostname: existing.hostname,
    });
  }
  return c.json({ data: { ok: true } });
});
