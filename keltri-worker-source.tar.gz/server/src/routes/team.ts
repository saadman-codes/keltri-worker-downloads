import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";

const inviteSchema = z.object({
  email: z.string().email(),
  role: z.string().default("member"),
});

export const team = new Hono();

// Owner-only: every route here requires project.developerId === caller,
// the same strict check every mutating handler in projects.ts uses.
async function requireOwnedProject(developerId: string, projectId: string) {
  return prisma.project.findFirst({
    where: { id: projectId, developerId },
  });
}

team.get("/:id/team", async (c) => {
  const developer = c.get("developer");
  const project = await requireOwnedProject(developer.id, c.req.param("id"));
  if (!project) return c.json({ error: "Project not found" }, 404);

  const members = await prisma.teamMember.findMany({
    where: { projectId: project.id },
    orderBy: { createdAt: "asc" },
    include: { developer: { select: { id: true, name: true, email: true, slug: true } } },
  });
  return c.json({ data: members });
});

team.post("/:id/team", async (c) => {
  const developer = c.get("developer");
  const project = await requireOwnedProject(developer.id, c.req.param("id"));
  if (!project) return c.json({ error: "Project not found" }, 404);

  const parsed = inviteSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  const invitee = await prisma.developer.findUnique({
    where: { email: parsed.data.email },
  });
  if (!invitee) {
    return c.json(
      { error: "No registered developer with that email — they need a Keltri account first" },
      404,
    );
  }
  if (invitee.id === developer.id) {
    return c.json({ error: "You already own this project" }, 400);
  }

  try {
    const member = await prisma.teamMember.create({
      data: {
        projectId: project.id,
        developerId: invitee.id,
        role: parsed.data.role,
        invitedById: developer.id,
      },
      include: { developer: { select: { id: true, name: true, email: true, slug: true } } },
    });
    await logAudit(developer.id, "team.invited", "project", project.id, {
      email: invitee.email,
    });
    return c.json(
      {
        data: member,
        notice:
          "Added immediately — they aren't notified. Share the project link yourself.",
      },
      201,
    );
  } catch {
    return c.json({ error: "That developer is already a team member" }, 409);
  }
});

team.delete("/:id/team/:memberId", async (c) => {
  const developer = c.get("developer");
  const project = await requireOwnedProject(developer.id, c.req.param("id"));
  if (!project) return c.json({ error: "Project not found" }, 404);

  const existing = await prisma.teamMember.findFirst({
    where: { id: c.req.param("memberId"), projectId: project.id },
  });
  await prisma.teamMember.deleteMany({
    where: { id: c.req.param("memberId"), projectId: project.id },
  });
  if (existing) {
    await logAudit(developer.id, "team.removed", "project", project.id, {
      developerId: existing.developerId,
    });
  }
  return c.json({ data: { ok: true } });
});
