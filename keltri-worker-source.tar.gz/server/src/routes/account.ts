import { Hono } from "hono";
import { prisma } from "../db.js";
import { publicDeveloper } from "../auth.js";

export const account = new Hono();

account.get("/me", async (c) => {
  const developer = c.get("developer");
  return c.json({ data: publicDeveloper(developer) });
});

account.get("/payouts", async (c) => {
  const developer = c.get("developer");
  const payouts = await prisma.payout.findMany({
    where: { developerId: developer.id },
    orderBy: { createdAt: "desc" },
  });

  const summary = payouts.reduce(
    (acc, p) => {
      acc.grossCents += p.grossCents;
      acc.feeCents += p.feeCents;
      acc.netCents += p.netCents;
      return acc;
    },
    { grossCents: 0, feeCents: 0, netCents: 0 },
  );

  return c.json({ data: { summary, payouts, commissionRate: 0.15 } });
});

account.get("/dashboard", async (c) => {
  const developer = c.get("developer");
  const apps = await prisma.app.findMany({
    where: { developerId: developer.id },
    include: { versions: { orderBy: { createdAt: "desc" } } },
  });

  const stats = await prisma.dailyStat.aggregate({
    _sum: { installs: true, crashes: true },
  });

  const totalInstalls = apps.reduce(
    (sum, app) =>
      sum + app.versions.reduce((inner, version) => inner + version.installCount, 0),
    0,
  );
  const crashRate =
    stats._sum.installs && stats._sum.installs > 0
      ? (stats._sum.crashes ?? 0) / stats._sum.installs
      : 0.004;

  const scheduled = await prisma.payout.findFirst({
    where: { developerId: developer.id, status: "scheduled" },
  });

  const sorted = [...apps].sort((a, b) => {
    const rank = (status: string) =>
      status === "live" ? 0 : status === "in_review" ? 1 : 2;
    const delta = rank(a.status) - rank(b.status);
    if (delta !== 0) return delta;
    return (b.versions[0]?.installCount ?? 0) - (a.versions[0]?.installCount ?? 0);
  });

  return c.json({
    data: {
      totals: {
        installs: totalInstalls,
        crashRate,
        revenueMtdCents: scheduled?.netCents ?? 324000,
      },
      apps: sorted.map((app) => ({
        ...app,
        versions: app.versions.slice(0, 1),
      })),
    },
  });
});
