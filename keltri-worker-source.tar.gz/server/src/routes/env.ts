import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { canMutate, canReadOrDeploy } from "../project-access.js";
import { resolveServiceAccess } from "./services.js";

const envVarSchema = z.object({
  key: z.string().regex(/^[A-Z_][A-Z0-9_]*$/, "Use SCREAMING_SNAKE_CASE"),
  value: z.string(),
  target: z.enum(["all", "production", "preview"]).default("all"),
});

const envTargetQuery = z.enum(["production", "preview"]);

export const env = new Hono();

// Environment variables: stored and manageable. Injected into the
// generated GitHub Actions build via /env/resolved below (see
// githubActionsYaml() in service-detail.tsx) — still not injected into
// any Keltri-run backend process, since none exists yet.
env.get("/:id/services/:serviceId/env", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const vars = await prisma.envVar.findMany({
    where: { serviceId: access.service.id },
    select: { id: true, key: true, target: true },
    orderBy: [{ key: "asc" }, { target: "asc" }],
  });
  return c.json({ data: vars });
});

env.post("/:id/services/:serviceId/env", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const parsed = envVarSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  const envVar = await prisma.envVar.upsert({
    where: {
      serviceId_key_target: {
        serviceId: access.service.id,
        key: parsed.data.key,
        target: parsed.data.target,
      },
    },
    create: { serviceId: access.service.id, ...parsed.data },
    update: { value: parsed.data.value },
  });
  await logAudit(developer.id, "env.set", "service", access.service.id, {
    projectId: access.project.id,
    key: parsed.data.key,
    target: parsed.data.target,
  });

  return c.json({ data: { id: envVar.id, key: envVar.key, target: envVar.target } }, 201);
});

env.delete("/:id/services/:serviceId/env/:envId", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const envVar = await prisma.envVar.findFirst({
    where: { id: c.req.param("envId"), serviceId: access.service.id },
  });
  await prisma.envVar.deleteMany({
    where: { id: c.req.param("envId"), serviceId: access.service.id },
  });
  if (envVar) {
    await logAudit(developer.id, "env.deleted", "service", access.service.id, {
      projectId: access.project.id,
      key: envVar.key,
      target: envVar.target,
    });
  }
  return c.json({ data: { ok: true } });
});

// Resolves env vars for a build/runtime consumer: "all" rows first, then
// target-specific rows override. Called at runtime by the generated GitHub
// Actions workflow (see githubActionsYaml() in service-detail.tsx) —
// values never sit in the committed workflow source, only fetched here.
env.get("/:id/services/:serviceId/env/resolved", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const parsedTarget = envTargetQuery.safeParse(c.req.query("target"));
  if (!parsedTarget.success) {
    return c.json({ error: "target must be 'production' or 'preview'" }, 400);
  }

  const vars = await prisma.envVar.findMany({
    where: {
      serviceId: access.service.id,
      target: { in: ["all", parsedTarget.data] },
    },
  });

  const resolved: Record<string, string> = {};
  for (const envVar of vars.filter((v) => v.target === "all")) {
    resolved[envVar.key] = envVar.value;
  }
  for (const envVar of vars.filter((v) => v.target !== "all")) {
    resolved[envVar.key] = envVar.value;
  }

  return c.json({ data: resolved });
});
