import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { withParsedFindings } from "../deployment-utils.js";
import { GitHubApp, githubConfig, GitHubError } from "../github-app.js";
import { connectedRepository } from "../github-scope.js";
import { automaticBuildsEnabled, enqueueBuild } from "../build-queue.js";
import { safeRelativePath } from "../build-policy.js";
import { randomUUID } from "node:crypto";
import {
  canMutate,
  canReadOrDeploy,
  resolveProjectAccess,
  type ProjectAccess,
} from "../project-access.js";

// Only "web"/"backend" are functional today -- the rest exist so the
// type picker is honest about where this is going. zod accepts all 5 so
// a clear validation error names the field, but the handler below still
// rejects anything except web/backend with its own 400: never trust a
// disabled client-side picker alone.
const createServiceSchema = z.object({
  slug: z
    .string()
    .min(2)
    .regex(/^[a-z0-9-]+$/),
  name: z.string().min(2),
  type: z.enum(["web", "backend", "android", "worker", "desktop"]),
  buildCommand: z.string().optional(),
  startCommand: z.string().optional(),
  outputDir: z.string().refine(safeRelativePath, "Use a relative directory without ..").optional(),
  rootDir: z.string().refine(safeRelativePath, "Use a relative directory without ..").default("."),
});

export type ServiceAccess = ProjectAccess & {
  service: NonNullable<Awaited<ReturnType<typeof findService>>>;
};

function findService(projectId: string, serviceId: string) {
  return prisma.service.findFirst({ where: { id: serviceId, projectId } });
}

// Reused by every other service-scoped route file (deployments.ts, env.ts,
// flags.ts, domains.ts) -- project-level access stays the single source
// of truth (resolveProjectAccess), this just adds "and does the given
// service actually belong to that project" as a second, separate check.
export async function resolveServiceAccess(
  developerId: string,
  projectId: string,
  serviceId: string,
): Promise<ServiceAccess | null> {
  const access = await resolveProjectAccess(developerId, projectId);
  if (!access) return null;
  const service = await findService(access.project.id, serviceId);
  if (!service) return null;
  return { ...access, service };
}

export const services = new Hono();

services.get("/:id/services", async (c) => {
  const developer = c.get("developer");
  const access = await resolveProjectAccess(developer.id, c.req.param("id"));
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Project not found" }, 404);
  }
  const list = await prisma.service.findMany({
    where: { projectId: access.project.id },
    include: { deployments: { orderBy: { createdAt: "desc" }, take: 1 } },
    orderBy: { createdAt: "asc" },
  });
  return c.json({
    data: list.map((service) => ({
      ...service,
      latestDeployment: service.deployments[0]
        ? withParsedFindings(service.deployments[0])
        : null,
      deployments: undefined,
    })),
  });
});

services.post("/:id/services", async (c) => {
  const developer = c.get("developer");
  const access = await resolveProjectAccess(developer.id, c.req.param("id"));
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Project not found" }, 404);
  }

  const parsed = createServiceSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);
  if (parsed.data.type !== "web" && parsed.data.type !== "backend") {
    return c.json(
      { error: `Service type "${parsed.data.type}" is not available yet` },
      400,
    );
  }

  try {
    const service = await prisma.service.create({
      data: { projectId: access.project.id, ...parsed.data },
    });
    await logAudit(developer.id, "service.created", "service", service.id, {
      projectId: access.project.id,
      slug: service.slug,
      type: service.type,
    });
    return c.json({ data: service }, 201);
  } catch {
    return c.json({ error: "That slug is already used in this project" }, 409);
  }
});

services.get("/:id/services/:serviceId", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }
  const [envCount, domainCount, deployments, gitLink] = await Promise.all([
    prisma.envVar.count({ where: { serviceId: access.service.id } }),
    prisma.domain.count({ where: { serviceId: access.service.id } }),
    prisma.deployment.findMany({
      where: { serviceId: access.service.id },
      orderBy: { createdAt: "desc" },
    }),
    prisma.serviceGitLink.findUnique({ where: { serviceId: access.service.id } }),
  ]);
  return c.json({
    data: {
      ...access.service,
      isOwner: access.isOwner,
      envCount,
      domainCount,
      deployments: deployments.map(withParsedFindings),
      gitLink,
      automaticBuildsEnabled: automaticBuildsEnabled(),
      project: {
        id: access.project.id,
        slug: access.project.slug,
        name: access.project.name,
      },
    },
  });
});

const gitLinkSchema = z.object({
  repoFullName: z.string().min(3),
  defaultBranch: z.string().min(1),
  installationId: z.string().min(1),
  repositoryId: z.string().regex(/^[1-9][0-9]*$/),
});

// Verify repository access before linking and queuing the initial build.
services.post("/:id/services/:serviceId/git-link", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const parsed = gitLinkSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  try {
    const scopeKey = access.project.organizationId ? `organization:${access.project.organizationId}` : `developer:${access.project.developerId}`;
    const connection = await connectedRepository(prisma, scopeKey, parsed.data.installationId, parsed.data.repositoryId);
    const repo = await new GitHubApp(githubConfig()).repository(connection.installationId, parsed.data.repositoryId);
    const data = { repoFullName: repo.full_name, defaultBranch: repo.default_branch,
      githubInstallationId: connection.id, githubRepositoryId: String(repo.id) };
    const link = await prisma.serviceGitLink.upsert({
      where: { serviceId: access.service.id },
      create: { serviceId: access.service.id, ...data },
      update: data,
    });
    if (automaticBuildsEnabled() && access.service.type === "web") {
      const sha = await new GitHubApp(githubConfig()).branchCommit(connection.installationId, String(repo.id), repo.default_branch);
      await enqueueBuild(prisma, access.service.id, sha, repo.default_branch, `import:${sha}`);
    }
    return c.json({ data: link }, 201);
  } catch (err) {
    return c.json({ error: err instanceof GitHubError ? err.message : "Could not verify the GitHub repository." }, 400);
  }
});

services.post("/:id/services/:serviceId/builds", async c => {
  const access = await resolveServiceAccess(c.get("developer").id, c.req.param("id"), c.req.param("serviceId"));
  if (!access || !canMutate(access)) return c.json({ error: "Service not found" }, 404);
  if (!automaticBuildsEnabled()) return c.json({ error: "Automatic builds are not enabled on this server." }, 503);
  const link = await prisma.serviceGitLink.findUnique({ where: { serviceId: access.service.id } });
  if (!link?.githubInstallationId || !link.githubRepositoryId || access.service.type !== "web") return c.json({ error: "Connect a web service repository first." }, 400);
  try {
    const scope = access.project.organizationId ? `organization:${access.project.organizationId}` : `developer:${access.project.developerId}`;
    const connection = await connectedRepository(prisma, scope, link.githubInstallationId, link.githubRepositoryId);
    const sha = await new GitHubApp(githubConfig()).branchCommit(connection.installationId, link.githubRepositoryId, link.defaultBranch);
    const job = await enqueueBuild(prisma, access.service.id, sha, link.defaultBranch, `manual:${randomUUID()}`);
    if (!job) return c.json({ error: "Repository access changed. Reconnect GitHub and retry." }, 409);
    return c.json({ data: { deploymentId: job.deploymentId } }, 202);
  } catch { return c.json({ error: "Could not queue the build. Check GitHub access and try again." }, 502); }
});

services.get("/:id/services/:serviceId/builds/:deploymentId", async c => {
  const access = await resolveServiceAccess(c.get("developer").id, c.req.param("id"), c.req.param("serviceId"));
  if (!access || !canReadOrDeploy(access)) return c.json({ error: "Service not found" }, 404);
  const job = await prisma.buildJob.findFirst({ where: { deploymentId: c.req.param("deploymentId"), deployment: { serviceId: access.service.id } },
    select: { status: true, logs: true, branch: true, commitSha: true, startedAt: true, finishedAt: true } });
  return c.json({ data: job });
});
