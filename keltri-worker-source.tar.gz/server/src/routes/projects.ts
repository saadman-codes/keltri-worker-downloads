import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { withParsedFindings } from "../deployment-utils.js";
import { canReadOrDeploy, resolveProjectAccess } from "../project-access.js";

const createProjectSchema = z.object({
  name: z.string().min(2),
  slug: z
    .string()
    .min(2)
    .regex(/^[a-z0-9-]+$/),
  organizationId: z.string().optional(),
});

export const projects = new Hono();

// GET / and GET /:id grant visibility to personal-project TeamMember
// shares AND org membership (any role) -- every mutating handler on a
// project's services (see routes/services.ts and friends) requires
// resolveServiceAccess() + canMutate() (owner only, personal or org).
// Deploy-level actions require only canReadOrDeploy() (any org member,
// or the personal owner).
async function ownerOrgIds(developerId: string) {
  const owned = await prisma.organizationMember.findMany({
    where: { developerId, role: "owner" },
    select: { organizationId: true },
  });
  return new Set(owned.map((m) => m.organizationId));
}

const servicesInclude = {
  services: {
    include: { deployments: { orderBy: { createdAt: "desc" as const }, take: 1 } },
    orderBy: { createdAt: "asc" as const },
  },
};

function withServiceSummary<
  T extends {
    services: Array<{
      deployments: Array<{ secretFindings: string | null }>;
      id: string;
      [key: string]: unknown;
    }>;
  },
>(project: T, production: Map<string, unknown>) {
  return {
    ...project,
    services: project.services.map((service) => ({
      ...service,
      productionDeployment: production.get(service.id) ?? null,
      latestDeployment: service.deployments[0]
        ? withParsedFindings(service.deployments[0])
        : null,
      deployments: undefined,
    })),
  };
}

async function productionFor(serviceIds: string[]) {
  const deployments = await prisma.deployment.findMany({
    where: { serviceId: { in: serviceIds }, environment: "production", status: "ready" },
  });
  return new Map(deployments.map(d => [d.serviceId, withParsedFindings(d)]));
}

projects.get("/", async (c) => {
  const developer = c.get("developer");
  const [list, ownerOrgs] = await Promise.all([
    prisma.project.findMany({
      where: {
        OR: [
          // developerId only grants access for a *personal* project --
          // once org-owned, developerId is just "who created it," not a
          // standing access grant (a creator removed from the org must
          // lose access, matching resolveProjectAccess's own logic).
          { developerId: developer.id, organizationId: null },
          { teamMembers: { some: { developerId: developer.id } } },
          { organization: { members: { some: { developerId: developer.id } } } },
        ],
      },
      include: servicesInclude,
      orderBy: { updatedAt: "desc" },
    }),
    ownerOrgIds(developer.id),
  ]);
  const production = await productionFor(list.flatMap(p => p.services.map(s => s.id)));
  return c.json({
    data: list.map((project) => ({
      ...withServiceSummary(project, production),
      // For an org-owned project, developerId is just "who created it" --
      // ownership is decided solely by org role, never by that field (a
      // member who created the project is still just a member).
      isOwner: project.organizationId
        ? ownerOrgs.has(project.organizationId)
        : project.developerId === developer.id,
    })),
  });
});

projects.post("/", async (c) => {
  const developer = c.get("developer");
  const parsed = createProjectSchema.safeParse(await c.req.json());
  if (!parsed.success) {
    return c.json({ error: parsed.error.flatten() }, 400);
  }

  // Any org member (any role) can create a project under the org --
  // matches "any member can deploy," mirrors real Vercel/GitHub org UX.
  if (parsed.data.organizationId) {
    const membership = await prisma.organizationMember.findFirst({
      where: { organizationId: parsed.data.organizationId, developerId: developer.id },
    });
    if (!membership) return c.json({ error: "Organization not found" }, 404);
  }

  const project = await prisma.project.create({
    data: { developerId: developer.id, ...parsed.data },
  });
  await logAudit(developer.id, "project.created", "project", project.id, {
    slug: project.slug,
    organizationId: project.organizationId,
  });

  return c.json({ data: project }, 201);
});

projects.get("/:id", async (c) => {
  const developer = c.get("developer");
  const project = await prisma.project.findFirst({
    where: {
      id: c.req.param("id"),
      OR: [
        { developerId: developer.id, organizationId: null },
        { teamMembers: { some: { developerId: developer.id } } },
        { organization: { members: { some: { developerId: developer.id } } } },
      ],
    },
    include: servicesInclude,
  });
  if (!project) return c.json({ error: "Project not found" }, 404);

  // Same rule as GET /: for an org-owned project, developerId is only
  // "who created it" -- ownership is decided solely by org role.
  let isOwner: boolean;
  if (project.organizationId) {
    const membership = await prisma.organizationMember.findUnique({
      where: {
        organizationId_developerId: {
          organizationId: project.organizationId,
          developerId: developer.id,
        },
      },
    });
    isOwner = membership?.role === "owner";
  } else {
    isOwner = project.developerId === developer.id;
  }

  const production = await productionFor(project.services.map(s => s.id));
  return c.json({ data: { ...withServiceSummary(project, production), isOwner } });
});

// Page views on production HTML responses only, day-bucketed. Stays
// project-level (not per-service) — a deliberate simplification, not an
// oversight: see ProjectDailyStat's schema comment. See analytics.ts's
// recordPageView(), which increments the counter without blocking the
// request that triggered it.
projects.get("/:id/analytics", async (c) => {
  const developer = c.get("developer");
  const access = await resolveProjectAccess(developer.id, c.req.param("id"));
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Project not found" }, 404);
  }
  const project = access.project;

  const series = await prisma.projectDailyStat.findMany({
    where: { projectId: project.id },
    orderBy: { date: "asc" },
    take: 30,
  });
  const totalViews = series.reduce((sum, day) => sum + day.views, 0);

  return c.json({ data: { series, totalViews } });
});
