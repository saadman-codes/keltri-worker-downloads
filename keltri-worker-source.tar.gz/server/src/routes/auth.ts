import { Hono } from "hono";
import { z } from "zod";
import { prisma } from "../db.js";
import { hashPassword, verifyPassword } from "../password.js";
import { getCookie } from "hono/cookie";
import {
  attachSessionCookie,
  clearSessionCookie,
  createSession,
  hashKey,
  publicDeveloper,
  SESSION_COOKIE,
} from "../auth.js";
import { consoleOrigin } from "../cors.js";
import {
  isForbiddenProductionLogin,
  isProductionEnv,
} from "../demo-credentials.js";

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  name: z.string().min(2),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 40);
}

export const auth = new Hono();

auth.post("/register", async (c) => {
  const parsed = registerSchema.safeParse(await c.req.json());
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  const exists = await prisma.developer.findUnique({
    where: { email: parsed.data.email.toLowerCase() },
  });
  if (exists) return c.json({ error: "Email already registered" }, 409);
  if (
    isProductionEnv() &&
    isForbiddenProductionLogin(parsed.data.email, parsed.data.password)
  ) {
    return c.json({ error: "Choose a different email or a stronger password" }, 400);
  }

  const base = slugify(parsed.data.name) || "dev";
  let slug = base;
  let n = 1;
  while (await prisma.developer.findUnique({ where: { slug } })) {
    slug = `${base}-${n++}`;
  }

  const developer = await prisma.developer.create({
    data: {
      email: parsed.data.email.toLowerCase(),
      name: parsed.data.name,
      slug,
      passwordHash: hashPassword(parsed.data.password),
    },
  });

  const session = await createSession(developer.id);
  attachSessionCookie(c, session.token, session.expiresAt);
  return c.json(
    { data: { token: session.token, developer: publicDeveloper(developer) } },
    201,
  );
});

auth.post("/login", async (c) => {
  const parsed = loginSchema.safeParse(await c.req.json());
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  if (
    isProductionEnv() &&
    isForbiddenProductionLogin(parsed.data.email, parsed.data.password)
  ) {
    return c.json({ error: "Invalid email or password" }, 401);
  }

  const developer = await prisma.developer.findUnique({
    where: { email: parsed.data.email.toLowerCase() },
  });
  if (!developer?.passwordHash) {
    return c.json({ error: "Invalid email or password" }, 401);
  }
  if (!verifyPassword(parsed.data.password, developer.passwordHash)) {
    return c.json({ error: "Invalid email or password" }, 401);
  }

  const session = await createSession(developer.id);
  attachSessionCookie(c, session.token, session.expiresAt);
  return c.json({
    data: { token: session.token, developer: publicDeveloper(developer) },
  });
});

auth.post("/logout", async (c) => {
  const header = c.req.header("authorization") ?? "";
  const bearer = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const cookie = getCookie(c, SESSION_COOKIE) ?? "";
  const token = bearer || cookie;
  if (token.startsWith("qa_sess_")) {
    await prisma.session.deleteMany({ where: { tokenHash: hashKey(token) } });
  }
  clearSessionCookie(c);
  return c.json({ data: { ok: true } });
});

auth.get("/github", async (c) => {
  const clientId = process.env.GITHUB_CLIENT_ID;
  const consoleUrl = consoleOrigin();
  if (!clientId) {
    return c.json(
      { error: "GitHub OAuth is not configured. Set GITHUB_CLIENT_ID." },
      501,
    );
  }
  const redirect = `${process.env.API_ORIGIN ?? "http://localhost:4000"}/v1/auth/github/callback`;
  const url = new URL("https://github.com/login/oauth/authorize");
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", redirect);
  url.searchParams.set("scope", "read:user user:email");
  url.searchParams.set("state", consoleUrl);
  return c.redirect(url.toString());
});

auth.get("/github/callback", async (c) => {
  const code = c.req.query("code");
  const consoleUrl = c.req.query("state") ?? consoleOrigin();
  const clientId = process.env.GITHUB_CLIENT_ID;
  const secret = process.env.GITHUB_CLIENT_SECRET;
  if (!code || !clientId || !secret) {
    return c.redirect(`${consoleUrl}/login?error=github`);
  }

  const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { Accept: "application/json", "Content-Type": "application/json" },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: secret,
      code,
    }),
  });
  const tokenJson = (await tokenRes.json()) as { access_token?: string };
  if (!tokenJson.access_token) {
    return c.redirect(`${consoleUrl}/login?error=github`);
  }

  const userRes = await fetch("https://api.github.com/user", {
    headers: { Authorization: `Bearer ${tokenJson.access_token}` },
  });
  const user = (await userRes.json()) as {
    id: number;
    login: string;
    name: string | null;
    email: string | null;
  };

  let email = user.email;
  if (!email) {
    const emailsRes = await fetch("https://api.github.com/user/emails", {
      headers: { Authorization: `Bearer ${tokenJson.access_token}` },
    });
    const emails = (await emailsRes.json()) as Array<{
      email: string;
      primary: boolean;
    }>;
    email = emails.find((item) => item.primary)?.email ?? emails[0]?.email;
  }
  if (!email) return c.redirect(`${consoleUrl}/login?error=github-email`);

  const githubId = String(user.id);
  let developer = await prisma.developer.findFirst({
    where: { OR: [{ githubId }, { email: email.toLowerCase() }] },
  });
  if (!developer) {
    const base = slugify(user.login) || "github";
    let slug = base;
    let n = 1;
    while (await prisma.developer.findUnique({ where: { slug } })) {
      slug = `${base}-${n++}`;
    }
    developer = await prisma.developer.create({
      data: {
        email: email.toLowerCase(),
        name: user.name || user.login,
        slug,
        githubId,
      },
    });
  } else if (!developer.githubId) {
    developer = await prisma.developer.update({
      where: { id: developer.id },
      data: { githubId },
    });
  }

  const session = await createSession(developer.id);
  attachSessionCookie(c, session.token, session.expiresAt);
  return c.redirect(`${consoleUrl}/auth/callback?token=${session.token}`);
});
