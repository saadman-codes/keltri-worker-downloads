import { createHash, randomBytes } from "node:crypto";
import { Hono, type Context } from "hono";
import { deleteCookie, getCookie, setCookie } from "hono/cookie";
import { bodyLimit } from "hono/body-limit";
import type { GitHubConnectAttempt, PrismaClient } from "@prisma/client";
import { z } from "zod";
import { prisma } from "../db.js";
import { consoleOrigin } from "../cors.js";
import { gitReturnPath } from "../git-return.js";
import { GitHubApp, GitHubError, githubConfig, githubConfigured, hashState, validGitHubId, verifyGitHubSignature } from "../github-app.js";
import { connectedRepository, githubScope } from "../github-scope.js";
import { detectFromPackageJson } from "../github-framework.js";
import { automaticBuildsEnabled, enqueuePush } from "../build-queue.js";

const targetSchema = z.object({ projectId: z.string().min(1).optional(), organizationId: z.string().min(1).optional() });
const startSchema = targetSchema.extend({ returnTo: z.string().optional(), clientProof: z.string().min(32).max(128), installationId: z.string().optional(), mode: z.enum(["connect", "install"]).default("connect") });
const finishSchema = z.object({ flowId: z.string(), code: z.string().min(32).max(128), clientProof: z.string().min(32).max(128), installationId: z.string().optional() });
const random = () => randomBytes(32).toString("base64url");
const cookieName = (id: string) => `qa_github_${id}`;
type Verified = { installationId: string; githubUserId: string; accountLogin: string; accountType: string; repositoryIds: string[] };

export function createGitRouters(deps: {
  db?: PrismaClient; github?: () => GitHubApp; configured?: () => boolean;
  consoleUrl?: () => string; webhookSecret?: () => string;
} = {}) {
  const db = deps.db ?? prisma;
  const provider = deps.github ?? (() => new GitHubApp(githubConfig()));
  const configured = deps.configured ?? githubConfigured;
  const frontend = deps.consoleUrl ?? consoleOrigin;
  const git = new Hono();
  const publicGit = new Hono();
  const fail = (c: Context, reason = "failed", returnTo?: string) => c.redirect(`${frontend()}/git/callback?${new URLSearchParams({ error: reason, returnTo: gitReturnPath(returnTo) })}`);
  git.onError((err, c) => c.json({ error: err instanceof GitHubError ? err.message : "Could not complete the GitHub request. Please try again." }, (err instanceof GitHubError ? err.status : 502) as 400));
  publicGit.onError((_err, c) => c.req.path.endsWith("/webhook") ? c.json({ error: "Could not process webhook" }, 500) : fail(c));

  async function consume(state: string | undefined, phase: string, c?: Context) {
    if (!state || state.length > 128) return null;
    const attempt = await db.gitHubConnectAttempt.findUnique({ where: { stateHash: hashState(state) } });
    if (!attempt || attempt.phase !== phase || attempt.expiresAt <= new Date()) return null;
    if (c && hashState(getCookie(c, cookieName(attempt.id)) ?? "") !== attempt.browserHash) return null;
    const removed = await db.gitHubConnectAttempt.deleteMany({ where: { id: attempt.id, stateHash: attempt.stateHash, phase, expiresAt: { gt: new Date() } } });
    return removed.count === 1 ? attempt : null;
  }
  async function resume(attempt: GitHubConnectAttempt, patch: Partial<GitHubConnectAttempt>) {
    const state = random();
    await db.gitHubConnectAttempt.create({ data: {
      id: attempt.id, stateHash: hashState(state), browserHash: attempt.browserHash, clientHash: attempt.clientHash,
      developerId: attempt.developerId, organizationId: attempt.organizationId, scopeKey: attempt.scopeKey,
      returnTo: attempt.returnTo, phase: patch.phase ?? attempt.phase, expiresAt: attempt.expiresAt,
      installationId: patch.installationId ?? attempt.installationId, verifier: patch.verifier ?? attempt.verifier,
      ...(patch.result ? { result: patch.result } : {}),
    } });
    return state;
  }

  // Authenticated fetch first; a top-level API visit sets the browser cookie.
  // This works when the dashboard/API are on separate *.vercel.app sites.
  git.post("/connect", async c => {
    const parsed = startSchema.safeParse(await c.req.json().catch(() => ({})));
    if (!parsed.success) return c.json({ error: "Invalid GitHub connection request." }, 400);
    const developerId = c.get("developer").id;
    const scope = await githubScope(db, developerId, parsed.data, true);
    const app = provider();
    // Both connect and install must be able to finish authorization before
    // sending users away. Opening installation settings alone is not success.
    await app.checkConnectionConfiguration();
    let installationId: string | null = null;
    if (parsed.data.installationId) {
      const linked = await db.gitHubInstallation.findFirst({ where: { id: parsed.data.installationId, scopeKey: scope.scopeKey } });
      if (!linked) return c.json({ error: "Installation not found." }, 404);
      installationId = linked.installationId;
    }
    await db.gitHubConnectAttempt.deleteMany({ where: { expiresAt: { lt: new Date() } } });
    const state = random();
    const attempt = await db.gitHubConnectAttempt.create({ data: {
      stateHash: hashState(state), browserHash: "", clientHash: hashState(parsed.data.clientProof), developerId,
      organizationId: scope.organizationId, scopeKey: scope.scopeKey,
      returnTo: gitReturnPath(parsed.data.returnTo), phase: "start", installationId,
      result: { mode: parsed.data.mode },
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    } });
    return c.json({ data: { flowId: attempt.id, url: `${app.config.apiOrigin}/v1/git/connect/start?ticket=${state}` } });
  });

  publicGit.get("/connect/start", async c => {
    const attempt = await consume(c.req.query("ticket"), "start");
    if (!attempt) return fail(c, "expired");
    const browserProof = random();
    attempt.browserHash = hashState(browserProof);
    setCookie(c, cookieName(attempt.id), browserProof, { httpOnly: true, sameSite: "Lax", path: "/v1/git", maxAge: 900, secure: process.env.NODE_ENV === "production" });
    const app = provider();
    if ((attempt.result as { mode?: string } | null)?.mode !== "install") {
      const verifier = random();
      const state = await resume(attempt, { phase: "authorize", verifier });
      return c.redirect(app.authorizationUrl(state, verifier));
    }
    const state = await resume(attempt, { phase: "install" });
    return c.redirect(app.installationUrl(state));
  });

  async function finishInstallation(c: Context, attempt: GitHubConnectAttempt) {
    if (c.req.query("setup_action") === "request") return fail(c, "approval_pending", attempt.returnTo);
    if (c.req.query("error")) return fail(c, "cancelled", attempt.returnTo);
    const installationId = c.req.query("installation_id");
    const discoverAfterAuthorization = !installationId && c.req.path.endsWith("/connect/callback") && !!c.req.query("code");
    if (!validGitHubId(installationId) && !discoverAfterAuthorization) return fail(c, "installation", attempt.returnTo);
    const verifier = random();
    const state = await resume(attempt, { phase: "authorize", installationId, verifier });
    return c.redirect(provider().authorizationUrl(state, verifier));
  }
  publicGit.get("/setup", async c => {
    const attempt = await consume(c.req.query("state"), "install", c);
    if (!attempt) return fail(c, "expired");
    return finishInstallation(c, attempt);
  });

  publicGit.get("/connect/callback", async c => {
    const attempt = await consume(c.req.query("state"), "authorize", c);
    if (!attempt) {
      // GitHub uses the callback instead of Setup URL when authorization
      // during installation is enabled. Start our own PKCE verification.
      const installing = await consume(c.req.query("state"), "install", c);
      return installing ? finishInstallation(c, installing) : fail(c, "expired");
    }
    if (c.req.query("error") || !c.req.query("code")) return fail(c, "cancelled", attempt.returnTo);
    if (!attempt.verifier) return fail(c, "installation", attempt.returnTo);
    let stage = "configuration";
    try {
      const app = provider();
      stage = "token_exchange";
      const userToken = await app.exchangeCode(c.req.query("code")!, attempt.verifier);
      // The user token is used only for this verification; never written to DB.
      stage = "installation_discovery";
      const ids = attempt.installationId ? [attempt.installationId] : (await app.userInstallations(userToken)).map(i => String(i.id));
      if (!ids.length) {
        stage = "connection_storage";
        const state = await resume(attempt, { phase: "install" });
        return c.redirect(app.installationUrl(state));
      }
      const result: Verified[] = [];
      stage = "installation_verification";
      for (const installationId of ids) {
        const verified = await app.verifyInstallation(installationId, userToken);
        result.push({ installationId, githubUserId: verified.userId,
          accountLogin: verified.installation.account.login, accountType: verified.installation.account.type,
          repositoryIds: verified.repositoryIds });
      }
      deleteCookie(c, cookieName(attempt.id), { path: "/v1/git" });
      stage = "connection_storage";
      const code = await resume(attempt, { phase: "complete", result });
      return c.redirect(`${frontend()}/git/callback?flow=${encodeURIComponent(attempt.id)}&code=${code}`);
    } catch (error) {
      const reason = error instanceof GitHubError && error.reason !== "verification" ? error.reason : stage;
      // Never log raw errors: fetch/Prisma errors may contain credentials or URLs.
      console.error("GitHub connection failed", { stage, reason, upstreamStatus: error instanceof GitHubError ? error.upstreamStatus : undefined });
      return fail(c, reason, attempt.returnTo);
    }
  });

  git.post("/complete", async c => {
    const parsed = finishSchema.safeParse(await c.req.json().catch(() => ({})));
    if (!parsed.success) return c.json({ error: "Invalid connection completion." }, 400);
    const input = parsed.data;
    const attempt = await db.gitHubConnectAttempt.findUnique({ where: { stateHash: hashState(input.code) } });
    const developerId = c.get("developer").id;
    if (!attempt || attempt.id !== input.flowId || attempt.phase !== "complete" || attempt.expiresAt <= new Date() ||
      attempt.developerId !== developerId || attempt.clientHash !== hashState(input.clientProof) || !attempt.result) {
      return c.json({ error: "This connection expired or was started in another browser or account. Start again from the dashboard." }, 403);
    }
    const scope = await githubScope(db, developerId, { organizationId: attempt.organizationId ?? undefined }, true);
    if (scope.scopeKey !== attempt.scopeKey) return c.json({ error: "Workspace access changed." }, 403);
    const candidates = (Array.isArray(attempt.result) ? attempt.result : [attempt.result]) as unknown as Verified[];
    if (!input.installationId && candidates.length > 1) {
      return c.json({ data: { installations: candidates.map(i => ({ installationId: i.installationId, accountLogin: i.accountLogin, accountType: i.accountType })), returnTo: attempt.returnTo, organizationId: attempt.organizationId } });
    }
    const verified = input.installationId ? candidates.find(i => i.installationId === input.installationId) : candidates[0];
    if (!verified) return c.json({ error: "Choose a verified GitHub account." }, 403);
    // Confirm the installation remains active before final linking.
    await provider().installationToken(verified.installationId);
    await db.$transaction(async tx => {
      const removed = await tx.gitHubConnectAttempt.deleteMany({ where: { id: attempt.id, stateHash: attempt.stateHash, phase: "complete", expiresAt: { gt: new Date() } } });
      if (removed.count !== 1) throw new GitHubError("Connection already completed or expired.", 409);
      const existing = await tx.gitHubInstallation.findUnique({ where: { installationId: verified.installationId } });
      if (existing && existing.scopeKey !== scope.scopeKey) throw new GitHubError("This GitHub installation is already linked to another workspace. Disconnect it there first.", 409);
      const data = { ...verified, developerId, organizationId: scope.organizationId, scopeKey: scope.scopeKey, suspended: false };
      if (existing) await tx.gitHubInstallation.update({ where: { id: existing.id }, data });
      else await tx.gitHubInstallation.create({ data });
    });
    return c.json({ data: { returnTo: attempt.returnTo, organizationId: attempt.organizationId } });
  });

  git.get("/status", async c => {
    const scope = await githubScope(db, c.get("developer").id, c.req.query());
    const installations = await db.gitHubInstallation.findMany({ where: { scopeKey: scope.scopeKey }, orderBy: { createdAt: "asc" } });
    // Owners can self-verify the deployed GitHub App config without exposing
    // secrets: clientId/appId/slug/apiOrigin are already non-secret (the
    // clientId rides in cleartext OAuth redirect URLs), and the secret/key
    // fingerprints are one-way SHA-256 prefixes, useful only for comparing
    // "is this the value I think it is" against a locally-hashed copy.
    let diagnostics: Record<string, unknown> | undefined;
    if (scope.canManage) {
      try {
        const config = githubConfig();
        const fingerprint = (value: string) => createHash("sha256").update(value).digest("hex").slice(0, 12);
        diagnostics = {
          appId: config.appId, clientId: config.clientId, slug: config.slug, apiOrigin: config.apiOrigin,
          callbackUrl: `${config.apiOrigin}/v1/git/connect/callback`,
          clientSecretLength: config.clientSecret.length, clientSecretFingerprint: fingerprint(config.clientSecret),
          privateKeyFingerprint: fingerprint(config.privateKey),
        };
      } catch { /* leave diagnostics undefined when unconfigured */ }
    }
    return c.json({ data: { configured: configured(), canManage: scope.canManage, diagnostics, installations: installations.map(i => ({
      id: i.id, accountLogin: i.accountLogin, accountType: i.accountType, suspended: i.suspended, repositoryCount: i.repositoryIds.length,
      manageUrl: i.accountType === "Organization" ? `https://github.com/organizations/${encodeURIComponent(i.accountLogin)}/settings/installations/${i.installationId}` : `https://github.com/settings/installations/${i.installationId}`,
    })) } });
  });

  git.post("/disconnect", async c => {
    const parsed = targetSchema.extend({ installationId: z.string().min(1) }).safeParse(await c.req.json().catch(() => ({})));
    if (!parsed.success) return c.json({ error: "Specify the installation to disconnect." }, 400);
    const scope = await githubScope(db, c.get("developer").id, parsed.data, true);
    await db.gitHubInstallation.deleteMany({ where: { id: parsed.data.installationId, scopeKey: scope.scopeKey } });
    return c.json({ data: { ok: true } });
  });

  git.get("/repos", async c => {
    const scope = await githubScope(db, c.get("developer").id, c.req.query());
    const installations = await db.gitHubInstallation.findMany({ where: { scopeKey: scope.scopeKey, suspended: false } });
    if (!installations.length) return c.json({ error: "Connect a GitHub installation to this workspace first." }, 409);
    const app = provider();
    const lists = await Promise.all(installations.map(async i => (await app.repositories(i.installationId, i.repositoryIds)).map(repo => ({
      id: repo.id, name: repo.name, fullName: repo.full_name, defaultBranch: repo.default_branch,
      private: repo.private, updatedAt: repo.updated_at, installationId: i.id,
    }))));
    return c.json({ data: lists.flat().sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)) });
  });

  git.get("/installations/:connectionId/repositories/:repositoryId/detect", async c => {
    const scope = await githubScope(db, c.get("developer").id, c.req.query());
    const { connectionId, repositoryId } = c.req.param();
    if (!validGitHubId(repositoryId)) return c.json({ error: "Invalid repository ID." }, 400);
    const connection = await connectedRepository(db, scope.scopeKey, connectionId, repositoryId);
    const app = provider();
    const repo = await app.repository(connection.installationId, repositoryId);
    const pkg = await app.packageJson(connection.installationId, repositoryId, repo);
    return c.json({ data: { defaultBranch: repo.default_branch, ...detectFromPackageJson(pkg) } });
  });

  publicGit.use("/webhook", bodyLimit({ maxSize: 1024 * 1024 }));
  publicGit.post("/webhook", async c => {
    const body = new Uint8Array(await c.req.arrayBuffer());
    if (!verifyGitHubSignature(body, c.req.header("x-hub-signature-256"), deps.webhookSecret?.() ?? process.env.GITHUB_APP_WEBHOOK_SECRET ?? "")) return c.json({ error: "Invalid webhook signature." }, 401);
    let payload: { action?: string; installation?: { id?: number }; sender?: { id?: number } };
    try { payload = JSON.parse(new TextDecoder().decode(body)); } catch { return c.json({ error: "Invalid JSON." }, 400); }
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) return c.json({ error: "Invalid webhook payload." }, 400);
    const event = c.req.header("x-github-event");
    if (event === "push" && automaticBuildsEnabled()) {
      const delivery = c.req.header("x-github-delivery");
      if (!delivery || !/^[a-zA-Z0-9-]{1,100}$/.test(delivery)) return c.json({ error: "Missing delivery ID." }, 400);
      await enqueuePush(db, payload, delivery);
    }
    const installationId = String(payload.installation?.id ?? "");
    if (event === "installation" && validGitHubId(installationId)) {
      if (payload.action === "deleted") await db.gitHubInstallation.deleteMany({ where: { installationId } });
      if (payload.action === "suspend") await db.gitHubInstallation.updateMany({ where: { installationId }, data: { suspended: true } });
      // Unsuspension/repository additions require an explicit verified refresh.
    }
    if (event === "github_app_authorization" && payload.action === "revoked" && payload.sender?.id) {
      await db.gitHubInstallation.deleteMany({ where: { githubUserId: String(payload.sender.id) } });
    }
    return c.json({ data: { ok: true } });
  });
  return { git, publicGit };
}

export const { git, publicGit } = createGitRouters();
