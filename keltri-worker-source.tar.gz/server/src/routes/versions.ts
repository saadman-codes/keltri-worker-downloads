import { randomBytes } from "node:crypto";
import { Hono } from "hono";
import { z } from "zod";
import { prisma } from "../db.js";
import { parseApk } from "../apk.js";
import { putObject, publicFileUrl } from "../storage.js";
import { fireWebhook } from "../webhooks.js";

const rolloutSchema = z.object({
  rolloutPercent: z.number().int().min(0).max(100),
  status: z.string().optional(),
});

const finalizeSchema = z.object({
  versionName: z.string().min(1).optional(),
  versionCode: z.number().int().positive().optional(),
  releaseNotes: z.string().optional(),
});

export const versions = new Hono();

versions.get("/:id/versions", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const list = await prisma.appVersion.findMany({
    where: { appId: app.id },
    orderBy: { createdAt: "desc" },
  });
  return c.json({ data: list });
});

versions.post("/:id/versions/upload-url", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const body = await c.req.json().catch(() => ({}));
  const versionName =
    typeof body.versionName === "string" && body.versionName.length > 0
      ? body.versionName
      : `${Date.now()}`;
  const versionCode =
    typeof body.versionCode === "number" ? body.versionCode : Date.now() % 1_000_000;
  const token = randomBytes(18).toString("hex");
  const api = process.env.API_ORIGIN ?? "http://localhost:4000";

  const version = await prisma.appVersion.create({
    data: {
      appId: app.id,
      versionName,
      versionCode,
      releaseNotes: body.releaseNotes,
      status: "draft",
      scanStatus: "pending",
      uploadToken: token,
    },
  });

  return c.json({
    data: {
      versionId: version.id,
      uploadUrl: `${api}/v1/uploads/${token}`,
      uploadToken: token,
    },
  });
});

versions.post("/:id/versions/:vid/finalize", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const version = await prisma.appVersion.findFirst({
    where: { id: c.req.param("vid"), appId: app.id },
  });
  if (!version) return c.json({ error: "Version not found" }, 404);
  if (!version.apkKey) return c.json({ error: "APK not uploaded" }, 400);

  const parsed = finalizeSchema.safeParse(await c.req.json().catch(() => ({})));
  const { getObject } = await import("../storage.js");
  const buffer = await getObject(version.apkKey);
  const info = await parseApk(buffer, `apps/${app.id}/${version.id}`);
  await putObject(version.apkKey, buffer);

  const nextName =
    (parsed.success && parsed.data.versionName) ||
    info.versionName ||
    version.versionName;
  const clash = await prisma.appVersion.findFirst({
    where: {
      appId: app.id,
      versionName: nextName,
      NOT: { id: version.id },
    },
  });

  const updated = await prisma.appVersion.update({
    where: { id: version.id },
    data: {
      versionName: clash ? version.versionName : nextName,
      versionCode:
        (parsed.success && parsed.data.versionCode) ||
        info.versionCode ||
        version.versionCode,
      releaseNotes:
        parsed.success && parsed.data.releaseNotes
          ? parsed.data.releaseNotes
          : version.releaseNotes,
      apkSha256: info.sha256,
      apkSizeBytes: info.sizeBytes,
      iconKey: info.iconKey,
      miniappKey: info.miniappKey,
      scanStatus: "scanning",
      status: "rolling_out",
      rolloutPercent: 10,
      uploadToken: null,
    },
  });

  await prisma.app.update({
    where: { id: app.id },
    data: {
      hasMiniApp: info.hasMiniApp || app.hasMiniApp,
      miniAppPermissions: info.permissions.length
        ? JSON.stringify(info.permissions)
        : app.miniAppPermissions,
      iconUrl: info.iconKey ? publicFileUrl(info.iconKey) : app.iconUrl,
      packageName: info.packageName ?? app.packageName,
    },
  });

  setTimeout(() => {
    prisma.appVersion
      .update({
        where: { id: version.id },
        data: { scanStatus: "ready" },
      })
      .then(() =>
        fireWebhook(developer.id, "version.published", {
          appId: app.id,
          versionId: version.id,
        }),
      )
      .catch(() => undefined);
  }, 800);

  return c.json({ data: updated });
});

versions.patch("/:id/versions/:vid", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const parsed = rolloutSchema.safeParse(await c.req.json());
  if (!parsed.success) {
    return c.json({ error: parsed.error.flatten() }, 400);
  }

  const version = await prisma.appVersion.update({
    where: { id: c.req.param("vid") },
    data: {
      rolloutPercent: parsed.data.rolloutPercent,
      status:
        parsed.data.status ??
        (parsed.data.rolloutPercent === 100 ? "live" : "rolling_out"),
    },
  });

  return c.json({ data: version });
});

versions.post("/:id/rollback", async (c) => {
  const developer = c.get("developer");
  const app = await prisma.app.findFirst({
    where: { id: c.req.param("id"), developerId: developer.id },
    include: { versions: { orderBy: { createdAt: "desc" } } },
  });
  if (!app) return c.json({ error: "App not found" }, 404);

  const [current, previous] = app.versions;
  if (!current || !previous) {
    return c.json({ error: "No previous version to roll back to" }, 400);
  }

  await prisma.appVersion.update({
    where: { id: current.id },
    data: { status: "rolled_back", rolloutPercent: 0 },
  });

  const restored = await prisma.appVersion.update({
    where: { id: previous.id },
    data: { status: "live", rolloutPercent: 100 },
  });

  await fireWebhook(developer.id, "version.rolled_back", {
    appId: app.id,
    versionId: restored.id,
  });

  return c.json({ data: restored });
});
