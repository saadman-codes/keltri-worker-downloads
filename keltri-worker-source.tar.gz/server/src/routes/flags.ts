import { Hono } from "hono";
import { z } from "zod";
import { logAudit } from "../audit.js";
import { prisma } from "../db.js";
import { canMutate, canReadOrDeploy } from "../project-access.js";
import { resolveServiceAccess } from "./services.js";

const flagSchema = z.object({
  key: z.string().regex(/^[A-Za-z0-9_.-]+$/, "Alphanumeric, dot, dash, underscore only"),
  enabled: z.boolean().default(false),
  rolloutPercent: z.number().int().min(0).max(100).default(100),
  target: z.enum(["all", "production", "preview"]).default("all"),
});

export const flags = new Hono();

flags.get("/:id/services/:serviceId/flags", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canReadOrDeploy(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const list = await prisma.featureFlag.findMany({
    where: { serviceId: access.service.id },
    orderBy: [{ key: "asc" }, { target: "asc" }],
  });
  return c.json({ data: list });
});

flags.post("/:id/services/:serviceId/flags", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  const parsed = flagSchema.safeParse(await c.req.json().catch(() => ({})));
  if (!parsed.success) return c.json({ error: parsed.error.flatten() }, 400);

  const flag = await prisma.featureFlag.upsert({
    where: {
      serviceId_key_target: {
        serviceId: access.service.id,
        key: parsed.data.key,
        target: parsed.data.target,
      },
    },
    create: { serviceId: access.service.id, ...parsed.data },
    update: {
      enabled: parsed.data.enabled,
      rolloutPercent: parsed.data.rolloutPercent,
    },
  });
  await logAudit(developer.id, "flag.set", "service", access.service.id, {
    projectId: access.project.id,
    key: parsed.data.key,
    target: parsed.data.target,
  });

  return c.json({ data: flag }, 201);
});

flags.delete("/:id/services/:serviceId/flags/:flagId", async (c) => {
  const developer = c.get("developer");
  const access = await resolveServiceAccess(
    developer.id,
    c.req.param("id"),
    c.req.param("serviceId"),
  );
  if (!access || !canMutate(access)) {
    return c.json({ error: "Service not found" }, 404);
  }

  await prisma.featureFlag.deleteMany({
    where: { id: c.req.param("flagId"), serviceId: access.service.id },
  });
  return c.json({ data: { ok: true } });
});
