import { Hono } from "hono";
import { prisma } from "../db.js";

export const review = new Hono();

review.get("/live", async (c) => {
  const developer = c.get("developer");
  if (!developer.isReviewer) return c.json({ error: "Forbidden" }, 403);
  const apps = await prisma.app.findMany({
    where: { status: "live", visibility: "public" },
    include: { developer: { select: { name: true, email: true } } },
    orderBy: { updatedAt: "desc" },
    take: 100,
  });
  return c.json({ data: apps });
});

review.get("/", async (c) => {
  const developer = c.get("developer");
  if (!developer.isReviewer) return c.json({ error: "Forbidden" }, 403);
  const apps = await prisma.app.findMany({
    where: { status: "in_review" },
    include: { developer: true },
    orderBy: { updatedAt: "asc" },
  });
  return c.json({ data: apps });
});
