import type { PrismaClient } from "@prisma/client";
import { GitHubError } from "./github-app.js";

export type GitScope = { scopeKey: string; organizationId: string | null; canManage: boolean };
export async function githubScope(db: PrismaClient, developerId: string, target: { projectId?: string; organizationId?: string }, manage = false): Promise<GitScope> {
  let organizationId = target.organizationId || null;
  if (target.projectId) {
    const project = await db.project.findUnique({ where: { id: target.projectId }, select: { organizationId: true, developerId: true } });
    if (!project || !project.organizationId && project.developerId !== developerId) throw new GitHubError("Project not found.", 404);
    if (target.organizationId && target.organizationId !== project.organizationId) throw new GitHubError("Workspace does not match project.", 400);
    organizationId = project.organizationId;
  }
  if (!organizationId) return { scopeKey: `developer:${developerId}`, organizationId: null, canManage: true };
  const membership = await db.organizationMember.findUnique({ where: { organizationId_developerId: { organizationId, developerId } } });
  if (!membership || manage && membership.role !== "owner") throw new GitHubError("A workspace owner must manage its GitHub connection.", 403);
  return { scopeKey: `organization:${organizationId}`, organizationId, canManage: membership.role === "owner" };
}

export async function connectedRepository(db: PrismaClient, scopeKey: string, connectionId: string, repositoryId: string) {
  const connection = await db.gitHubInstallation.findFirst({ where: { id: connectionId, scopeKey, suspended: false } });
  if (!connection || !connection.repositoryIds.includes(repositoryId)) throw new GitHubError("Repository is not connected to this workspace. Refresh GitHub access first.", 403);
  return connection;
}
