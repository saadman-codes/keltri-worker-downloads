/** Only console import screens may be used as OAuth return destinations. */
export function gitReturnPath(value: string | undefined) {
  if (value === "/console/settings") return value;
  return value && /^\/console\/projects\/[a-zA-Z0-9_-]+\/services\/new$/.test(value)
    ? value
    : "/console/projects/new";
}
