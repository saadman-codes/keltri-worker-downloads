import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { mkdir, readFile, writeFile, stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import {
  GetObjectCommand,
  HeadObjectCommand,
  PutObjectCommand,
  S3Client,
} from "@aws-sdk/client-s3";

export type ObjectInfo = { size: number };
export type StorageDriver = "local" | "cloudflare" | "s3" | "cloudinary";

const root = path.resolve(
  process.env.STORAGE_DIR ?? path.join(process.cwd(), "storage"),
);

function isLocal(nodeEnv = process.env.NODE_ENV) {
  return nodeEnv !== "production";
}

export function resolveStorageDriver(
  nodeEnv = process.env.NODE_ENV,
  storageDriver = process.env.STORAGE_DRIVER,
): StorageDriver {
  if (isLocal(nodeEnv)) return "local";

  const value = (storageDriver ?? "cloudflare").toLowerCase();
  if (value === "cloudflare" || value === "r2") return "cloudflare";
  if (value === "s3") return "s3";
  if (value === "cloudinary") return "cloudinary";
  throw new Error(
    `Unknown STORAGE_DRIVER: ${value}. In production use cloudflare, s3, or cloudinary.`,
  );
}

function driver(): StorageDriver {
  return resolveStorageDriver();
}

export function storageDriver() {
  return driver();
}

export function publicFileUrl(key: string) {
  const current = driver();
  if (current === "cloudinary") return cloudinaryUrl(key);
  if (current === "cloudflare" && process.env.CLOUDFLARE_R2_PUBLIC_BASE_URL) {
    return `${process.env.CLOUDFLARE_R2_PUBLIC_BASE_URL.replace(/\/$/, "")}/${key}`;
  }
  if (current === "s3" && process.env.S3_PUBLIC_BASE_URL) {
    return `${process.env.S3_PUBLIC_BASE_URL.replace(/\/$/, "")}/${key}`;
  }
  const api = process.env.API_ORIGIN ?? "http://localhost:4000";
  return `${api}/v1/public/files/${key}`;
}

export async function putObject(key: string, body: Buffer | Uint8Array) {
  const bytes = Buffer.from(body);
  const current = driver();
  if (current === "s3" || current === "cloudflare") return putS3(key, bytes);
  if (current === "cloudinary") return putCloudinary(key, bytes);
  return putLocal(key, bytes);
}

export async function getObject(key: string) {
  const current = driver();
  if (current === "s3" || current === "cloudflare") return getS3(key);
  if (current === "cloudinary") return getCloudinary(key);
  return readFile(path.join(root, key));
}

export function getObjectStream(key: string) {
  return Readable.toWeb(createReadStream(path.join(root, key)));
}

export async function objectStat(key: string): Promise<ObjectInfo> {
  const current = driver();
  if (current === "s3" || current === "cloudflare") return headS3(key);
  if (current === "cloudinary") return headCloudinary(key);
  const info = await stat(path.join(root, key));
  return { size: info.size };
}

export function localPath(key: string) {
  return path.join(root, key);
}

export function asBody(buffer: Buffer) {
  const copy = new Uint8Array(buffer.byteLength);
  copy.set(buffer);
  return copy;
}

function contentType(key: string) {
  if (key.endsWith(".png")) return "image/png";
  if (key.endsWith(".html")) return "text/html";
  if (key.endsWith(".js")) return "text/javascript";
  if (key.endsWith(".css")) return "text/css";
  if (key.endsWith(".apk")) return "application/vnd.android.package-archive";
  return "application/octet-stream";
}

async function putLocal(key: string, body: Buffer) {
  const dest = path.join(root, key);
  await mkdir(path.dirname(dest), { recursive: true });
  await writeFile(dest, body);
  return key;
}

function s3() {
  const current = driver();
  if (current === "cloudflare") {
    const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
    const bucket = process.env.CLOUDFLARE_R2_BUCKET;
    const accessKeyId = process.env.CLOUDFLARE_R2_ACCESS_KEY_ID;
    const secretAccessKey = process.env.CLOUDFLARE_R2_SECRET_ACCESS_KEY;
    if (!accountId || !bucket || !accessKeyId || !secretAccessKey) {
      throw new Error(
        "Cloudflare R2 needs CLOUDFLARE_ACCOUNT_ID, CLOUDFLARE_R2_BUCKET, CLOUDFLARE_R2_ACCESS_KEY_ID, and CLOUDFLARE_R2_SECRET_ACCESS_KEY",
      );
    }
    return {
      bucket,
      client: new S3Client({
        region: "auto",
        endpoint: `https://${accountId}.r2.cloudflarestorage.com`,
        forcePathStyle: true,
        credentials: { accessKeyId, secretAccessKey },
      }),
    };
  }

  const endpoint = process.env.S3_ENDPOINT;
  const bucket = process.env.S3_BUCKET;
  const accessKeyId = process.env.S3_ACCESS_KEY_ID;
  const secretAccessKey = process.env.S3_SECRET_ACCESS_KEY;
  if (!endpoint || !bucket || !accessKeyId || !secretAccessKey) {
    throw new Error(
      "S3 storage needs S3_ENDPOINT, S3_BUCKET, S3_ACCESS_KEY_ID, and S3_SECRET_ACCESS_KEY",
    );
  }
  return {
    bucket,
    client: new S3Client({
      region: process.env.S3_REGION ?? "us-east-1",
      endpoint,
      forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
      credentials: { accessKeyId, secretAccessKey },
    }),
  };
}

async function putS3(key: string, body: Buffer) {
  const { client, bucket } = s3();
  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: body,
      ContentType: contentType(key),
    }),
  );
  return key;
}

async function getS3(key: string) {
  const { client, bucket } = s3();
  const response = await client.send(
    new GetObjectCommand({ Bucket: bucket, Key: key }),
  );
  const bytes = await response.Body?.transformToByteArray();
  if (!bytes) throw new Error(`Missing object: ${key}`);
  return Buffer.from(bytes);
}

async function headS3(key: string): Promise<ObjectInfo> {
  const { client, bucket } = s3();
  const response = await client.send(
    new HeadObjectCommand({ Bucket: bucket, Key: key }),
  );
  return { size: response.ContentLength ?? 0 };
}

function cloudinaryConfig() {
  const cloud = process.env.CLOUDINARY_CLOUD_NAME;
  const apiKey = process.env.CLOUDINARY_API_KEY;
  const apiSecret = process.env.CLOUDINARY_API_SECRET;
  if (!cloud || !apiKey || !apiSecret) {
    throw new Error(
      "Cloudinary storage needs CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, and CLOUDINARY_API_SECRET",
    );
  }
  return { cloud, apiKey, apiSecret };
}

function cloudinaryPublicId(key: string) {
  return key.replace(/\.[^.]+$/, "");
}

function cloudinaryFormat(key: string) {
  const ext = path.extname(key).replace(".", "");
  return ext || "bin";
}

function cloudinaryUrl(key: string) {
  const { cloud } = cloudinaryConfig();
  const id = cloudinaryPublicId(key)
    .split("/")
    .map(encodeURIComponent)
    .join("/");
  const format = cloudinaryFormat(key);
  const kind = key.endsWith(".png") || key.endsWith(".jpg") ? "image" : "raw";
  return `https://res.cloudinary.com/${cloud}/${kind}/upload/${id}.${format}`;
}

function signCloudinary(params: Record<string, string>, secret: string) {
  const toSign = Object.keys(params)
    .sort()
    .map((name) => `${name}=${params[name]}`)
    .join("&");
  return createHash("sha1").update(`${toSign}${secret}`).digest("hex");
}

async function putCloudinary(key: string, body: Buffer) {
  const { cloud, apiKey, apiSecret } = cloudinaryConfig();
  const timestamp = String(Math.floor(Date.now() / 1000));
  const publicId = cloudinaryPublicId(key);
  const resourceType =
    key.endsWith(".png") || key.endsWith(".jpg") ? "image" : "raw";
  const signed = { public_id: publicId, timestamp };
  const signature = signCloudinary(signed, apiSecret);

  const form = new FormData();
  form.set("file", new Blob([new Uint8Array(body)]), path.basename(key));
  form.set("api_key", apiKey);
  form.set("timestamp", timestamp);
  form.set("public_id", publicId);
  form.set("signature", signature);

  const response = await fetch(
    `https://api.cloudinary.com/v1_1/${cloud}/${resourceType}/upload`,
    { method: "POST", body: form },
  );
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Cloudinary upload failed: ${response.status} ${detail}`);
  }
  return key;
}

async function getCloudinary(key: string) {
  const response = await fetch(cloudinaryUrl(key));
  if (!response.ok) throw new Error(`Missing object: ${key}`);
  return Buffer.from(await response.arrayBuffer());
}

async function headCloudinary(key: string): Promise<ObjectInfo> {
  const response = await fetch(cloudinaryUrl(key), { method: "HEAD" });
  if (!response.ok) throw new Error(`Missing object: ${key}`);
  const length = Number(response.headers.get("content-length") ?? 0);
  return { size: length };
}
