import type { PrismaClient } from "@prisma/client";
import { pushBuild } from "./build-policy.js";

export const automaticBuildsEnabled = () => process.env.GIT_BUILDS_ENABLED === "true";

export async function enqueueBuild(db: PrismaClient, serviceId: string, commitSha: string, branch: string, key: string) {
  const link = await db.serviceGitLink.findUnique({ where: { serviceId }, include: { service: true, githubInstallation: true } });
  const connection = link?.githubInstallation;
  if (!link || link.service.type !== "web" || !connection || connection.suspended || !link.githubRepositoryId || !connection.repositoryIds.includes(link.githubRepositoryId)) return null;
  const target = branch === link.defaultBranch ? "production" : "preview";
  return db.buildJob.upsert({
    where: { dedupeKey: `${serviceId}:${key}` }, update: {},
    create: {
      dedupeKey: `${serviceId}:${key}`, repositoryId: link.githubRepositoryId, connectionId: connection.id,
      commitSha, branch, target, rootDir: link.service.rootDir,
      buildCommand: link.service.buildCommand || "npm run build", outputDir: link.service.outputDir || "dist",
      deployment: { create: { serviceId, status: "queued", commitRef: `${branch}@${commitSha.slice(0, 8)}` } },
    },
  });
}

export async function enqueuePush(db: PrismaClient, payload: unknown, delivery: string) {
  const push = pushBuild(payload);
  if (!push) return;
  const links = await db.serviceGitLink.findMany({ where: {
    githubRepositoryId: push.repositoryId,
    githubInstallation: { installationId: push.installationId, suspended: false },
  }, select: { serviceId: true } });
  for (const link of links) await enqueueBuild(db, link.serviceId, push.commitSha, push.branch, `push:${delivery}`);
}
