import { Hono } from "hono";
import { cors } from "hono/cors";
import type { Developer } from "@prisma/client";
import { requireDeveloper } from "./auth.js";
import { corsOrigin } from "./cors.js";
import { prisma } from "./db.js";
import { storageDriver } from "./storage.js";
import { apps } from "./routes/apps.js";
import { projects } from "./routes/projects.js";
import { versions } from "./routes/versions.js";
import { extra } from "./routes/extra.js";
import { account } from "./routes/account.js";
import { audit } from "./routes/audit.js";
import { blobs } from "./routes/blobs.js";
import { domains } from "./routes/domains.js";
import { flags } from "./routes/flags.js";
import { services } from "./routes/services.js";
import { deployments } from "./routes/deployments.js";
import { env } from "./routes/env.js";
import { git, publicGit } from "./routes/git.js";
import { auth } from "./routes/auth.js";
import { keys } from "./routes/keys.js";
import { organizations } from "./routes/organizations.js";
import { publicApi } from "./routes/public.js";
import { review } from "./routes/review.js";
import { team } from "./routes/team.js";
import { uploads } from "./routes/uploads.js";
import { webhooks } from "./routes/webhooks.js";

declare module "hono" {
  interface ContextVariableMap {
    developer: Developer;
  }
}

export const app = new Hono();

app.use(
  "*",
  cors({
    origin: corsOrigin,
    allowHeaders: ["Authorization", "Content-Type"],
    allowMethods: ["GET", "POST", "PATCH", "PUT", "DELETE", "OPTIONS"],
    credentials: true,
  }),
);

app.get("/v1/health", async (c) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return c.json({
      ok: true,
      service: "keltri-api",
      db: "up",
      storage: storageDriver(),
      time: new Date().toISOString(),
    });
  } catch {
    return c.json(
      {
        ok: false,
        service: "keltri-api",
        db: "down",
        storage: storageDriver(),
        time: new Date().toISOString(),
      },
      503,
    );
  }
});

app.route("/v1/auth", auth);
app.route("/v1/public", publicApi);
app.route("/v1/uploads", uploads);
app.route("/v1/git", publicGit);

const v1 = new Hono();
v1.use("*", requireDeveloper);
v1.route("/", account);
v1.route("/api-keys", keys);
v1.route("/review", review);
v1.route("/apps", apps);
v1.route("/apps", versions);
v1.route("/apps", extra);
v1.route("/projects", projects);
v1.route("/projects", services);
v1.route("/projects", deployments);
v1.route("/projects", env);
v1.route("/projects", team);
v1.route("/projects", flags);
v1.route("/projects", domains);
v1.route("/webhooks", webhooks);
v1.route("/blobs", blobs);
v1.route("/audit-log", audit);
v1.route("/organizations", organizations);
v1.route("/git", git);

app.route("/v1", v1);
