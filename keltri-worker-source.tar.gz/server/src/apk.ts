import { createHash } from "node:crypto";
import JSZip from "jszip";
import { putObject } from "./storage.js";

export type ParsedApk = {
  sha256: string;
  sizeBytes: number;
  hasMiniApp: boolean;
  permissions: string[];
  packageName?: string;
  versionName?: string;
  versionCode?: number;
  iconKey?: string;
  miniappKey?: string;
};

const PERMISSIONS = [
  "camera",
  "geolocation",
  "payments",
  "notifications",
  "storage",
  "share",
  "biometric",
] as const;

function printableStrings(buffer: Buffer) {
  const out: string[] = [];
  let current = "";
  for (const byte of buffer) {
    if (byte >= 32 && byte <= 126) {
      current += String.fromCharCode(byte);
    } else if (current.length >= 3) {
      out.push(current);
      current = "";
    } else {
      current = "";
    }
  }
  if (current.length >= 3) out.push(current);
  return out;
}

function inferFromStrings(strings: string[]) {
  const packageName = strings.find((value) =>
    /^(com|dev|org|net|io)\.[a-zA-Z0-9_.]+$/.test(value),
  );
  const versionName = strings.find((value) => /^\d+\.\d+(\.\d+)?$/.test(value));
  const versionCode = strings
    .map((value) => Number(value))
    .find((value) => Number.isInteger(value) && value > 0 && value < 1_000_000_000);
  return { packageName, versionName, versionCode };
}

export async function parseApk(
  buffer: Buffer,
  prefix: string,
): Promise<ParsedApk> {
  const sha256 = createHash("sha256").update(buffer).digest("hex");
  const zip = await JSZip.loadAsync(buffer).catch(() => null);
  let hasMiniApp = false;
  const permissions: string[] = [];
  let iconKey: string | undefined;
  let miniappKey: string | undefined;
  let packageName: string | undefined;
  let versionName: string | undefined;
  let versionCode: number | undefined;

  if (zip) {
    const configFile =
      zip.file("assets/config.json") ?? zip.file("config.json");
    if (configFile) {
      try {
        const config = JSON.parse(await configFile.async("string")) as {
          packageName?: string;
          versionName?: string;
          versionCode?: number;
        };
        packageName = config.packageName;
        versionName = config.versionName;
        versionCode = config.versionCode;
      } catch {
        // Ignore malformed config.
      }
    }

    const miniIndex =
      zip.file("miniapp/index.html") ?? zip.file("assets/miniapp/index.html");
    if (miniIndex) {
      hasMiniApp = true;
      miniappKey = `${prefix}/miniapp`;
      const files = Object.values(zip.files).filter(
        (file) =>
          !file.dir &&
          (file.name.startsWith("miniapp/") ||
            file.name.startsWith("assets/miniapp/")),
      );
      for (const file of files) {
        const data = await file.async("nodebuffer");
        const relative = file.name
          .replace(/^assets\/miniapp\//, "")
          .replace(/^miniapp\//, "");
        await putObject(`${miniappKey}/${relative}`, data);
      }
    }

    const icon =
      zip.file("res/mipmap-xxxhdpi-v4/ic_launcher.png") ??
      zip.file("res/mipmap-xxhdpi-v4/ic_launcher.png") ??
      zip.file("icon.png");
    if (icon) {
      iconKey = `${prefix}/icon.png`;
      await putObject(iconKey, await icon.async("nodebuffer"));
    }

    const manifest = zip.file("AndroidManifest.xml");
    if (manifest) {
      const raw = await manifest.async("nodebuffer");
      const text = raw.toString("utf8");
      const lower = text.toLowerCase();
      for (const name of PERMISSIONS) {
        if (lower.includes(name)) permissions.push(name);
      }
      const pkg = text.match(/package="([^"]+)"/);
      if (pkg) packageName = packageName ?? pkg[1];
      const vn = text.match(/android:versionName="([^"]+)"/);
      if (vn) versionName = versionName ?? vn[1];
      const vc = text.match(/android:versionCode="([^"]+)"/);
      if (vc) versionCode = versionCode ?? Number(vc[1]);
      const inferred = inferFromStrings(printableStrings(raw));
      packageName = packageName ?? inferred.packageName;
      versionName = versionName ?? inferred.versionName;
      versionCode = versionCode ?? inferred.versionCode;
    }
  }

  return {
    sha256,
    sizeBytes: buffer.length,
    hasMiniApp,
    permissions,
    packageName,
    versionName,
    versionCode,
    iconKey,
    miniappKey,
  };
}
