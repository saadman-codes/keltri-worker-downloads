type DetectResult = {
  defaultBranch: string;
  detectedFramework: string;
  buildCommand: string | null;
  outputDir: string | null;
  startCommand: string | null;
};

// Read-only heuristic from package.json alone -- never executes anything,
// never trusted silently by the frontend (the config screen that consumes
// this always shows the values as editable, pre-filled fields). Limited
// on purpose: a custom vite.config.*/next.config.* `outDir` override
// would require executing config code to discover, which is out of scope
// for an honest static heuristic -- falls back to a framework default or
// blank for manual entry instead of guessing wrong.
export function detectFromPackageJson(pkg: {
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  scripts?: Record<string, string>;
}): Omit<DetectResult, "defaultBranch"> {
  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  const scripts = pkg.scripts ?? {};
  const startCommand = scripts.start ? "npm start" : null;

  if (deps.next) {
    return {
      detectedFramework: "Next.js",
      buildCommand: "npm run build",
      outputDir: "out",
      startCommand,
    };
  }
  if (deps.vite) {
    return {
      detectedFramework: "Vite",
      buildCommand: "npm run build",
      outputDir: "dist",
      startCommand,
    };
  }
  if (deps["react-scripts"]) {
    return {
      detectedFramework: "Create React App",
      buildCommand: "npm run build",
      outputDir: "build",
      startCommand,
    };
  }
  if (deps["@sveltejs/kit"]) {
    return {
      detectedFramework: "SvelteKit",
      buildCommand: "npm run build",
      outputDir: "build",
      startCommand,
    };
  }
  if (scripts.build) {
    return {
      detectedFramework: "Node (generic)",
      buildCommand: "npm run build",
      outputDir: null,
      startCommand,
    };
  }
  return {
    detectedFramework: "unknown",
    buildCommand: null,
    outputDir: null,
    startCommand,
  };
}
