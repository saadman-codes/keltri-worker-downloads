export function safeRelativePath(value: string) {
  return value.length > 0 && value.length <= 200 && !value.startsWith("/") &&
    !/[\\\x00-\x1f:]/.test(value) && !value.split("/").includes("..");
}

export function pushBuild(payload: unknown) {
  if (!payload || typeof payload !== "object") return null;
  const p = payload as { deleted?: unknown; ref?: unknown; after?: unknown; repository?: { id?: unknown }; installation?: { id?: unknown } };
  if (p.deleted || typeof p.ref !== "string" || !p.ref.startsWith("refs/heads/") ||
      p.ref.length <= 11 || p.ref.length > 1024 || typeof p.after !== "string" || !/^[a-f0-9]{40}$/.test(p.after) || /^0+$/.test(p.after)) return null;
  if (!Number.isSafeInteger(p.repository?.id) || Number(p.repository?.id) <= 0 ||
      !Number.isSafeInteger(p.installation?.id) || Number(p.installation?.id) <= 0) return null;
  return { branch: p.ref.slice(11), commitSha: p.after, repositoryId: String(p.repository!.id), installationId: String(p.installation!.id) };
}

export function redactBuildLogs(value: string, secrets: string[]) {
  let result = value;
  for (const secret of [...secrets].filter(Boolean).sort((a, b) => b.length - a.length)) {
    result = result.split(secret).join("[REDACTED]");
  }
  return result.replace(/\x1b\[[0-9;]*[A-Za-z]/g, "").slice(-64_000);
}
