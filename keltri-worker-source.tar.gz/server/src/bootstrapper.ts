import JSZip from "jszip";
import QRCode from "qrcode";

export async function buildBootstrapperApk(input: {
  appId: string;
  slug: string;
  name: string;
  apiOrigin: string;
}) {
  const zip = new JSZip();
  zip.file(
    "assets/config.json",
    JSON.stringify(
      {
        appId: input.appId,
        slug: input.slug,
        name: input.name,
        updateUrl: `${input.apiOrigin}/v1/public/apps/${input.slug}/update`,
        catalogUrl: `${input.apiOrigin}/v1/public/apps/${input.slug}`,
      },
      null,
      2,
    ),
  );
  zip.file(
    "AndroidManifest.xml",
    `<?xml version="1.0" encoding="utf-8"?>
<manifest package="dev.quantumapps.bootstrap.${input.slug.replace(/-/g, "")}">
  <application android:label="${input.name} Bootstrapper" />
</manifest>
`,
  );
  zip.file(
    "META-INF/QUANTUM.SF",
    `Template bootstrapper for ${input.slug}. Production builds replace this zip with a signed APK from mobile/bootstrapper.\n`,
  );
  return zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
}

export async function qrDataUrl(text: string) {
  return QRCode.toDataURL(text, { margin: 1, width: 240 });
}
