export function buildResources(env: NodeJS.ProcessEnv = process.env) {
  function number(key: string, fallback: number, min: number, max: number) {
    const value = Number(env[key] ?? fallback);
    if (!Number.isFinite(value) || value < min || value > max) throw new Error(`Invalid ${key}`);
    return value;
  }
  return {
    memoryMb: number("BUILD_MEMORY_MB", 2048, 256, 32768),
    cpus: number("BUILD_CPUS", 2, 0.1, 32),
    tmpMb: number("BUILD_TMP_MB", 256, 32, 2048),
    network: env.BUILD_CONTAINER_NETWORK || "keltri-build",
  };
}
