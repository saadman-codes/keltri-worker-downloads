import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { resolveStorageDriver } from "./storage.js";

describe("storage driver", () => {
  it("always uses local disk outside production", () => {
    assert.equal(resolveStorageDriver("development", "s3"), "local");
    assert.equal(resolveStorageDriver("development", "cloudflare"), "local");
    assert.equal(resolveStorageDriver(undefined, "cloudinary"), "local");
  });

  it("defaults production to Cloudflare R2", () => {
    assert.equal(resolveStorageDriver("production"), "cloudflare");
    assert.equal(resolveStorageDriver("production", "r2"), "cloudflare");
  });

  it("accepts s3 and cloudinary in production", () => {
    assert.equal(resolveStorageDriver("production", "s3"), "s3");
    assert.equal(resolveStorageDriver("production", "cloudinary"), "cloudinary");
  });

  it("rejects unknown production drivers", () => {
    assert.throws(
      () => resolveStorageDriver("production", "gcs"),
      /Unknown STORAGE_DRIVER/,
    );
  });
});
